"""生成程序图标：等距草地方块。"""
from __future__ import annotations

import random
from pathlib import Path

from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parent.parent / "assets"
OUT.mkdir(parents=True, exist_ok=True)
S = 1024

A = (512, 120)   # 顶面上
B = (896, 344)   # 顶面右
C = (512, 568)   # 顶面下
D = (128, 344)   # 顶面左
H = 330          # 立方体高度

GRASS_TOP = (124, 190, 92, 255)
GRASS_TOP_DARK = (104, 168, 74, 255)
GRASS_SIDE_L = (96, 154, 66, 255)
GRASS_SIDE_R = (110, 172, 76, 255)
DIRT_L = (124, 86, 54, 255)
DIRT_R = (146, 104, 68, 255)
DIRT_DARK_L = (104, 70, 42, 255)
DIRT_DARK_R = (124, 86, 56, 255)


def para(a, b, c, d, u, v):
    """平行四边形参数化：u 沿 a->b，v 沿 a->d。"""
    x = a[0] * (1 - u) * (1 - v) + b[0] * u * (1 - v) + d[0] * (1 - u) * v + c[0] * u * v
    y = a[1] * (1 - u) * (1 - v) + b[1] * u * (1 - v) + d[1] * (1 - u) * v + c[1] * u * v
    return x, y


def draw_icon(size: int = S) -> Image.Image:
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    k = size / S

    def pts(*points):
        return [(x * k, y * k) for x, y in points]

    top = [A, B, C, D]
    grass_l = [D, C, (C[0], C[1] + 58), (D[0], D[1] + 58)]
    grass_r = [B, C, (C[0], C[1] + 58), (B[0], B[1] + 58)]
    dirt_l = [(D[0], D[1] + 58), (C[0], C[1] + 58), (C[0], C[1] + H), (D[0], D[1] + H)]
    dirt_r = [(B[0], B[1] + 58), (C[0], C[1] + 58), (C[0], C[1] + H), (B[0], B[1] + H)]

    d.polygon(pts(*dirt_l), fill=DIRT_L)
    d.polygon(pts(*dirt_r), fill=DIRT_R)
    d.polygon(pts(*grass_l), fill=GRASS_SIDE_L)
    d.polygon(pts(*grass_r), fill=GRASS_SIDE_R)
    d.polygon(pts(*top), fill=GRASS_TOP)

    rnd = random.Random(20240501)
    # 顶面草纹理
    for _ in range(240):
        u, v = rnd.random(), rnd.random()
        x, y = para(A, B, C, D, u, v)
        r = rnd.uniform(2.5, 8.0) * k
        d.ellipse([(x - r) * k / k, (y - r) * k / k, (x + r) * k / k, (y + r) * k / k],
                  fill=GRASS_TOP_DARK if rnd.random() < 0.55 else GRASS_TOP)
    # 泥土颗粒（左面）
    for _ in range(140):
        u, v = rnd.random(), rnd.random()
        x, y = para(dirt_l[0], dirt_l[1], dirt_l[2], dirt_l[3], u, v)
        r = rnd.uniform(2, 7) * k
        d.ellipse([(x - r) * k, (y - r) * k, (x + r) * k, (y + r) * k], fill=DIRT_DARK_L)
    # 泥土颗粒（右面）
    for _ in range(120):
        u, v = rnd.random(), rnd.random()
        x, y = para(dirt_r[0], dirt_r[1], dirt_r[2], dirt_r[3], u, v)
        r = rnd.uniform(2, 7) * k
        d.ellipse([(x - r) * k, (y - r) * k, (x + r) * k, (y + r) * k], fill=DIRT_DARK_R)

    # 高光边
    for face in (top, grass_l, grass_r, dirt_l, dirt_r):
        d.line(pts(*(face + [face[0]])), fill=(255, 255, 255, 26), width=max(1, int(2 * k)))

    return img


def main() -> None:
    big = draw_icon(1024)
    big.resize((256, 256), Image.LANCZOS).save(OUT / "icon.png")
    big.resize((64, 64), Image.LANCZOS).save(OUT / "icon-64.png")
    big.save(OUT / "icon.ico", sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    print("saved:", OUT / "icon.png")


if __name__ == "__main__":
    main()
