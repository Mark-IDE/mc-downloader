"""演示并验证：通过界面真实下载一个版本，中途与完成时各截一张图。"""
from __future__ import annotations

import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PIL import ImageGrab  # noqa: E402

from mc_downloader.config import Config  # noqa: E402
from mc_downloader.ui.app import App  # noqa: E402

OUT = Path(__file__).resolve().parent.parent / "docs"
OUT.mkdir(parents=True, exist_ok=True)
TARGET = Path(r"E:\dsh\_probe\demo_mc")
VERSION = "1.5.2"


def pump(app, seconds):
    end = time.time() + seconds
    while time.time() < end:
        app.update()
        time.sleep(0.02)


def snap(app, name):
    x, y = app.winfo_rootx(), app.winfo_rooty()
    img = ImageGrab.grab(bbox=(x, y, x + app.winfo_width(), y + app.winfo_height()), all_screens=True)
    path = OUT / f"{name}.png"
    img.save(path)
    print("saved", path)


def main():
    shutil.rmtree(TARGET, ignore_errors=True)
    app = App(Config())
    app.geometry("1200x820+110+70")
    app.attributes("-topmost", True)
    app.lift()
    app.focus_force()
    pump(app, 3.5)

    page = app._pages["java"]
    page.dir_var.set(str(TARGET))
    page.tree.selection_set(VERSION)
    page.tree.see(VERSION)
    pump(app, 0.8)

    print("selected:", page.tree.selection())
    page._start(True)  # 仅核心
    pump(app, 4.0)
    snap(app, "ui-downloading")

    deadline = time.time() + 240
    while app.busy and time.time() < deadline:
        pump(app, 0.5)
    pump(app, 1.0)
    snap(app, "ui-done")

    files = list(TARGET.rglob("*"))
    print("busy:", app.busy, "files:", len(files),
          "jar:", (TARGET / "versions" / VERSION / f"{VERSION}.jar").exists())
    app.destroy()


if __name__ == "__main__":
    main()
