
"""验证取消下载：启动后 1.5 秒取消，界面应回到空闲并提示已取消。"""
import sys, time
from pathlib import Path
sys.path.insert(0, r"E:\dsh\mc-downloader")
from mc_downloader.config import Config
from mc_downloader.ui.app import App

app = App(Config())
app.attributes("-topmost", True)
app.update()
def pump(s):
    end = time.time() + s
    while time.time() < end:
        app.update(); time.sleep(0.02)
pump(2.5)
page = app._pages["java"]
target = Path(r"E:\dsh\_probe\canceltest")
page.dir_var.set(str(target))
ver = "1.7.10"
page.tree.selection_set(ver)
pump(0.5)
page._start(False)
pump(2.0)
print("busy after start:", app.busy, "| status:", app.dock.status_label.cget("text"))
app.cancel_job()
pump(4.0)
print("busy after cancel:", app.busy, "| status:", app.dock.status_label.cget("text"))
print("log tail:", app.dock.log_text.get("end-6l", "end").strip().replace("\n", " | "))
app.destroy()
