"""生成文档用截图（需要本机可显示界面）。"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PIL import ImageGrab  # noqa: E402

from mc_downloader.config import Config  # noqa: E402
from mc_downloader.ui.app import App  # noqa: E402

OUT = Path(__file__).resolve().parent.parent / "docs"
OUT.mkdir(parents=True, exist_ok=True)
INDEX = "http://127.0.0.1:8765/index2.json"
MOD_ROOT = r"E:\dsh\_probe\modtest"


def pump(app, seconds=1.0):
    end = time.time() + seconds
    while time.time() < end:
        app.update()
        time.sleep(0.02)


def snap(app, name):
    x, y = app.winfo_rootx(), app.winfo_rooty()
    img = ImageGrab.grab(bbox=(x, y, x + app.winfo_width(), y + app.winfo_height()), all_screens=True)
    img.save(OUT / f"{name}.png")
    print("saved", name)


def main():
    cfg = Config()
    cfg["java_dir"] = MOD_ROOT
    app = App(cfg)
    app.protocol("WM_DELETE_WINDOW", lambda: None)  # 忽略外部关闭请求
    app.geometry("1200x820+110+70")
    app.attributes("-topmost", True)
    app.lift()
    pump(app, 3.0)

    # 1) Java 版
    app._select_page("java")
    pump(app, 2.5)
    snap(app, "ui-java")

    # 2) 模组：加载器 / Mod 市场 / 已装
    app._select_page("mods")
    pump(app, 6.0)
    page = app._pages["mods"]
    snap(app, "ui-mods-loader")

    page.notebook.select(1)
    pump(app, 0.5)
    page.query_var.set("sodium")
    page._search_mods()
    pump(app, 4.0)
    if page._hits:
        page.mod_tree.selection_set("0")
        page._on_mod_select()
        pump(app, 3.0)
    snap(app, "ui-mods-market")

    page.notebook.select(2)
    page._refresh_manage_versions()
    pump(app, 1.5)
    snap(app, "ui-mods-manage")

    # 3) 安卓基岩版（演示用自建 JSON 清单源）
    cfg["apk_index_url"] = INDEX
    app._select_page("android")
    android = app._pages["android"]
    android.source_var.set("自定义 JSON 清单")
    android._on_source_change()
    pump(app, 2.5)
    snap(app, "ui-android")

    android.source_var.set("直接粘贴链接")
    android._on_source_change()
    android.url_var.set("https://example.com/Minecraft-1.21.50.apk")
    pump(app, 1.2)
    snap(app, "ui-android-direct")

    # 4) 安卓启动器
    app._select_page("launcher")
    pump(app, 3.0)
    snap(app, "ui-launcher")

    # 5) 设置 / 关于
    app._select_page("settings")
    pump(app, 1.2)
    snap(app, "ui-settings")
    app._select_page("about")
    pump(app, 1.0)
    snap(app, "ui-about")

    cfg["apk_index_url"] = ""
    cfg["apk_source"] = "archive"
    cfg["java_dir"] = str(Path.home() / "MCDownloader" / "minecraft")
    cfg.save()
    app.protocol("WM_DELETE_WINDOW", app._on_close)
    app.destroy()


if __name__ == "__main__":
    main()
