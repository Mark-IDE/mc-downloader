"""在同一个进程里渲染界面并截图（用于文档/自检）。"""
from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from PIL import ImageGrab  # noqa: E402

from mc_downloader.config import Config  # noqa: E402
from mc_downloader.ui.app import App  # noqa: E402

OUT = Path(__file__).resolve().parent.parent / "docs"
OUT.mkdir(parents=True, exist_ok=True)


def pump(app, seconds=1.0):
    end = time.time() + seconds
    while time.time() < end:
        app.update()
        time.sleep(0.02)


def main(names):
    extra = float(sys.argv[1]) if sys.argv[1].replace(".", "").isdigit() else 2.2
    pages = [n for n in sys.argv[1:] if not n.replace(".", "").isdigit()]
    app = App(Config())
    app.geometry("1200x820+110+70")
    app.attributes("-topmost", True)
    app.lift()
    app.focus_force()
    pump(app, 1.2)
    for name in pages:
        app._select_page(name)
        pump(app, extra)
        x, y = app.winfo_rootx(), app.winfo_rooty()
        w, h = app.winfo_width(), app.winfo_height()
        img = ImageGrab.grab(bbox=(x, y, x + w, y + h), all_screens=True)
        path = OUT / f"ui-{name}.png"
        img.save(path)
        print(f"saved {path} {img.size}")
    app.destroy()


if __name__ == "__main__":
    main(sys.argv[1:] or ["java"])
