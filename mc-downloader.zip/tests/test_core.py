"""离线单元测试（不联网）：python tests/test_core.py"""

from __future__ import annotations

import json
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from mc_downloader import bedrock, javadl, modloaders, modrinth, mods  # noqa: E402
from mc_downloader.net import Progress, human_size, sha1_file  # noqa: E402

PASSED = 0
FAILED = 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASSED, FAILED
    if cond:
        PASSED += 1
        print(f"  ok   {name}")
    else:
        FAILED += 1
        print(f"  FAIL {name} {detail}")


def eq(name: str, got, want) -> None:
    check(name, got == want, f"\n        got={got!r}\n        want={want!r}")


# ------------------------------------------------------------------ 规则
def test_rules() -> None:
    print("rules")
    eq("无规则默认允许", javadl.rules_allow(None), True)
    win_only = [{"action": "allow", "os": {"name": "windows"}}]
    eq("windows 允许", javadl.rules_allow(win_only), True)
    eq("linux 被拒", javadl.rules_allow(win_only, os_name="linux"), False)
    arch64 = [{"action": "allow", "os": {"name": "windows", "arch": "arm64"}}]
    eq("arm64 规则在 x64 上不生效", javadl.rules_allow(arch64, arch="x64"), False)
    eq("arm64 规则在 arm64 上生效", javadl.rules_allow(arch64, arch="arm64"), True)
    mixed = [{"action": "allow"}, {"action": "disallow", "os": {"name": "osx"}}]
    eq("混合规则 osx 拒绝", javadl.rules_allow(mixed, os_name="osx"), False)
    eq("混合规则 windows 允许", javadl.rules_allow(mixed), True)


def test_arch_filter() -> None:
    print("arch filter")
    eq("arm64 包在 x64 上被过滤", javadl.arch_compatible("org.lwjgl:lwjgl:3.3:natives-windows-arm64", "x64"), False)
    eq("普通 natives 在 x64 保留", javadl.arch_compatible("org.lwjgl:lwjgl:3.3:natives-windows", "x64"), True)
    eq("普通库不受影响", javadl.arch_compatible("com.google.code.gson:gson:2.10", "x64"), True)
    eq("arm64 上保留 arm64 包", javadl.arch_compatible("com.mojang:jtracy:1:natives-windows-arm64", "arm64"), True)


def test_maven() -> None:
    print("maven path")
    eq("普通路径", javadl._maven_path("org.lwjgl:lwjgl:3.3.1"), "org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1.jar")
    eq("带 classifier", javadl._maven_path("org.lwjgl:lwjgl:3.3.1", "natives-windows"),
       "org/lwjgl/lwjgl/3.3.1/lwjgl-3.3.1-natives-windows.jar")
    eq("带扩展名", javadl._maven_path("com.example:demo:1.0@zip"), "com/example/demo/1.0/demo-1.0.zip")


def test_mirror_map() -> None:
    print("mirror map")
    base = "https://bmclapi2.bangbang93.com"
    eq("资源文件", javadl.map_to_base("https://resources.download.minecraft.net/ab/abcdef", base),
       f"{base}/assets/ab/abcdef")
    eq("依赖库", javadl.map_to_base("https://libraries.minecraft.net/org/lwjgl/x.jar", base),
       f"{base}/maven/org/lwjgl/x.jar")
    eq("版本 JSON", javadl.map_to_base("https://piston-meta.mojang.com/v1/packages/aa/1.20.json", base),
       f"{base}/v1/packages/aa/1.20.json")
    eq("forge maven 不重复", javadl.map_to_base("https://files.minecraftforge.net/maven/net/x.jar", base),
       f"{base}/maven/net/x.jar")


# ------------------------------------------------------------------ 资源
def test_assets_dedupe() -> None:
    print("assets")
    root = Path(r"E:\_test_root")
    index = {
        "objects": {
            "a.txt": {"hash": "aa" + "0" * 38, "size": 10},
            "b.txt": {"hash": "aa" + "0" * 38, "size": 10},  # 同一个 hash
            "c.txt": {"hash": "bb" + "1" * 38, "size": 20},
        }
    }
    sources = [javadl.JavaSource("official", "官方源", javadl.MANIFEST_URL, None)]
    tasks = javadl.assets_tasks(index, root, sources)
    eq("按 hash 去重", len(tasks), 2)
    eq("目标路径", tasks[0].dest.relative_to(root).as_posix(),
       f"assets/objects/aa/{'aa' + '0' * 38}")


def test_plan_dedupe() -> None:
    print("plan")
    vj = {
        "id": "1.0",
        "downloads": {"client": {"url": "https://x/y.jar", "size": 5, "sha1": "a" * 40}},
        "libraries": [
            {"name": "a:b:1", "downloads": {"artifact": {"url": "https://x/a.jar", "size": 1, "sha1": "b" * 40}}},
            {"name": "a:b:1", "downloads": {"artifact": {"url": "https://x/a.jar", "size": 1, "sha1": "b" * 40}}},
            {"name": "org.lwjgl:lwjgl:1:natives-windows-arm64",
             "downloads": {"artifact": {"url": "https://x/arm.jar", "size": 1, "sha1": "c" * 40}}},
        ],
    }
    sources = [javadl.JavaSource("official", "官方源", javadl.MANIFEST_URL, None)]
    plan = javadl.build_plan(vj, Path(r"E:\_root"), sources, with_assets=False, with_logging=False)
    names = [t.label for t in plan.tasks]
    eq("重复库只下一次", names.count("a:b:1"), 1)
    check("arm64 natives 未进入任务", all("arm64" not in n for n in names), str(names))


def test_extract_natives() -> None:
    print("natives")
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        jar = tmp_path / "n.jar"
        with zipfile.ZipFile(jar, "w") as zf:
            zf.writestr("META-INF/MANIFEST.MF", "x")
            zf.writestr("a.dll", b"1234")
            zf.writestr("sub/b.dll", b"5678")
        out = tmp_path / "natives"
        count = javadl.extract_natives(jar, out, ["META-INF/"])
        eq("解压文件数", count, 2)
        check("META-INF 被跳过", not (out / "META-INF").exists())
        check("子目录保留", (out / "sub" / "b.dll").read_bytes() == b"5678")


# ------------------------------------------------------------------ APK 源
class FakeNet:
    def __init__(self, payload):
        self.payload = payload

    def fetch_json(self, url, cancel=None, retries=None):
        return self.payload


def test_json_source() -> None:
    print("json source")
    payload = [
        {"version": "1.2.0", "url": "https://x/a.apk", "size": 10, "sha1": "a" * 40},
        {"version": "1.10.0", "url": "https://x/b.apk", "channel": "beta"},
    ]
    src = bedrock.JsonIndexSource("https://x/index.json")
    versions = src.list_versions(FakeNet(payload))
    eq("解析数量", len(versions), 2)
    eq("按版本排序", versions[0].version, "1.10.0")
    eq("通道解析", versions[0].channel, "beta")
    eq("缺省文件名", versions[0].filename, "b.apk")


def test_archive_source() -> None:
    print("archive source")
    old_cache = bedrock.CACHE_DIR
    with tempfile.TemporaryDirectory() as tmp:
        bedrock.CACHE_DIR = Path(tmp)
        payload = {
            "files": [
                {"name": "MCPE-(v1.0.7.0-ICS).apk", "size": "2000000", "sha1": "AA" * 20},
                {"name": "MCPE-(0.12.1.b2).apk", "size": "3000000", "sha1": "BB" * 20},
                {"name": "MCPE-(1.21.0).apk", "size": "100", "sha1": "CC" * 20},  # 太小忽略
                {"name": "readme.txt", "size": "10"},
            ]
        }
        src = bedrock.ArchiveOrgSource()
        versions = src.list_versions(FakeNet(payload))
        eq("过滤非 apk / 过小文件", len(versions), 2)
        eq("版本号解析", versions[0].version, "1.0.7.0-ICS")
        check("直链包含确认字符", "%28" in versions[0].url or "(" in versions[0].url, versions[0].url)
        eq("sha1 小写", versions[1].sha1, "bb" * 20)
    bedrock.CACHE_DIR = old_cache


def test_version_filter() -> None:
    print("version filter")
    manifest = {
        "versions": [
            {"id": "1.20.1", "type": "release", "releaseTime": "2023-06-12T12:00:00+00:00"},
            {"id": "23w31a", "type": "snapshot", "releaseTime": "2023-08-02T00:00:00+00:00"},
            {"id": "b1.7.3", "type": "old_beta", "releaseTime": "2011-07-08T00:00:00+00:00"},
        ]
    }
    eq("仅正式版", len(javadl.search_versions(manifest, "", "release")), 1)
    eq("远古版", len(javadl.search_versions(manifest, "", "old")), 1)
    eq("搜索关键字", len(javadl.search_versions(manifest, "23w", "all")), 1)
    eq("日期格式化", javadl.release_time_text(manifest["versions"][0]), "2023-06-12")


def test_progress() -> None:
    print("progress")
    p = Progress()
    p.add_totals(4, 1000)
    p.add_bytes(250)
    snap = p.snapshot()
    eq("百分比", round(snap["percent"], 1), 25.0)
    p.skip_file(500)
    eq("跳过文件计入字节", p.snapshot()["done_bytes"], 750)
    eq("human_size", human_size(1536), "1.50 KB")


def test_sha1() -> None:
    print("sha1")
    with tempfile.TemporaryDirectory() as tmp:
        f = Path(tmp) / "a.bin"
        f.write_bytes(b"hello")
        eq("sha1 计算", sha1_file(f), "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d")


def test_neoforge_prefix() -> None:
    print("neoforge")
    eq("1.21.1 前缀", modloaders.mc_prefix("1.21.1"), "21.1.")
    eq("1.20.2 前缀", modloaders.mc_prefix("1.20.2"), "20.2.")
    eq("1.21 前缀", modloaders.mc_prefix("1.21"), "21.0.")
    eq("异常输入", modloaders.mc_prefix("26.3-snapshot"), "")


def test_installer_urls() -> None:
    print("installer urls")
    forge = modloaders.installer_urls("forge", "1.20.1", "47.4.28")
    check("forge 安装器走镜像优先", forge[0].startswith("https://bmclapi2.bangbang93.com/maven/"), forge[0])
    check("forge 安装器兜底官方", "maven.minecraftforge.net" in forge[1], forge[1])
    check("forge 文件名", forge[0].endswith("forge-1.20.1-47.4.28-installer.jar"), forge[0])
    neo = modloaders.installer_urls("neoforge", "1.21.1", "21.1.80")
    check("neoforge 文件名", neo[0].endswith("neoforge-21.1.80-installer.jar"), neo[0])
    neo1201 = modloaders.installer_urls("neoforge", "1.20.1", "1.20.1-47.1.106")
    check("neoforge 1.20.1 特殊路径", "net/neoforged/forge" in neo1201[0], neo1201[0])


def test_mods_local() -> None:
    print("mods local")
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        d = root / "mods"
        d.mkdir()
        (d / "a.jar").write_bytes(b"x" * 100)
        (d / "b.jar.disabled").write_bytes(b"y" * 200)
        (d / "readme.txt").write_text("ignore")
        entries = mods.list_mods(d)
        eq("只统计 jar", len(entries), 2)
        eq("启用状态解析", [e.enabled for e in entries], [True, False])
        eq("去掉 .disabled 后缀", entries[1].name, "b.jar")
        mods.set_enabled(entries[0], False)
        mods.set_enabled(entries[1], True)
        names = sorted(p.name for p in d.iterdir() if p.is_file())
        check("切换后文件名", "a.jar.disabled" in names and "b.jar" in names, str(names))
        entries = mods.list_mods(d)
        mods.delete_entry(entries[0])
        eq("删除后数量", len(mods.list_mods(d)), 1)
        (root / "versions" / "1.20.1" / "mods").mkdir(parents=True)
        eq("版本隔离优先", mods.resolve_mods_dir(root, "1.20.1").name, "mods")
        eq("隔离路径在版本目录下",
           mods.resolve_mods_dir(root, "1.20.1").as_posix().endswith("versions/1.20.1/mods"), True)


def test_modrinth_helpers() -> None:
    print("modrinth")
    def mk(ver, channel="release", mc=("1.20.1",), loader=("fabric",)):
        return modrinth.ModFile(project_id="p", version_id="v-" + ver, name=ver,
                                version_number=ver, filename=f"{ver}.jar", url="https://x",
                                size=10, loaders=list(loader), game_versions=list(mc),
                                version_type=channel)
    files = [mk("1.0", "beta"), mk("2.0", "release"), mk("3.0", "alpha", loader=("forge",))]
    eq("优先正式版/匹配加载器", modrinth.pick_file(files, "1.20.1", "fabric").version_number, "2.0")
    eq("无匹配时兜底", modrinth.pick_file([mk("9.0", mc=("1.16.5",))], "1.20.1", "fabric") is not None, True)
    eq("空列表", modrinth.pick_file([], "1.20.1", "fabric"), None)

    captured = {}

    class CaptureNet:
        def fetch_json(self, url, cancel=None, retries=None):
            captured["url"] = url
            return {"hits": [{"project_id": "AANobbMI", "slug": "sodium", "title": "Sodium",
                              "description": "d", "author": "a", "downloads": 123,
                              "icon_url": "", "categories": ["fabric"], "versions": ["1.20.1"]}]}

    hits = modrinth.search(CaptureNet(), "sodium", mc="1.20.1", loader="fabric", limit=5)
    eq("搜索结果解析", hits[0].slug, "sodium")
    check("facets 带版本与加载器",
          "versions%3A1.20.1" in captured["url"] and "categories%3Afabric" in captured["url"],
          captured["url"])
    eq("下载量格式化", hits[0].download_text, "123")


def main() -> int:
    test_rules()
    test_arch_filter()
    test_maven()
    test_mirror_map()
    test_assets_dedupe()
    test_plan_dedupe()
    test_extract_natives()
    test_json_source()
    test_archive_source()
    test_version_filter()
    test_progress()
    test_sha1()
    test_neoforge_prefix()
    test_installer_urls()
    test_mods_local()
    test_modrinth_helpers()
    print("-" * 46)
    print(f"通过 {PASSED} 项，失败 {FAILED} 项")
    return 0 if FAILED == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
