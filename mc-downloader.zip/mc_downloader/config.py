"""配置与路径管理。

配置文件直接放在程序目录（绿色便携），不写注册表。
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict


def app_dir() -> Path:
    """程序所在目录（打包成 exe 后为 exe 所在目录）。"""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


APP_DIR = app_dir()
CONFIG_PATH = APP_DIR / "config.json"
CACHE_DIR = APP_DIR / "cache"
LOG_DIR = APP_DIR / "logs"
ICON_PATH = APP_DIR / "assets" / "icon.png"

DEFAULT_CONFIG: Dict[str, Any] = {
    # 下载
    "source": "auto",              # auto | official | bmcl | custom
    "custom_base": "",             # 自定义镜像根地址，如 https://bmclapi2.bangbang93.com
    "threads": 16,
    "retries": 3,
    "timeout": 20,
    "verify_sha1": True,
    "allow_insecure_tls": True,    # 镜像证书链不完整时允许降级重试
    "fallback_official": True,     # 镜像失败后回退官方源
    # 目录
    "java_dir": str(Path.home() / "MCDownloader" / "minecraft"),
    "apk_dir": str(Path.home() / "MCDownloader" / "apk"),
    # 安装选项
    "download_assets": True,
    "download_libraries": True,
    "download_logging": True,
    # 安卓
    "apk_source": "archive",
    "apk_index_url": "",
    # 界面
    "window_size": "1200x820",
    "log_visible": True,
}


class Config:
    """极简配置对象：字典 + 磁盘持久化。"""

    def __init__(self, path: Path = CONFIG_PATH):
        self.path = path
        self.data: Dict[str, Any] = dict(DEFAULT_CONFIG)
        self.load()

    def load(self) -> None:
        try:
            if self.path.exists():
                raw = json.loads(self.path.read_text("utf-8"))
                if isinstance(raw, dict):
                    for k, v in raw.items():
                        self.data[k] = v
        except Exception:
            pass

    def save(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), "utf-8")
            os.replace(tmp, self.path)
        except Exception:
            pass

    def __getitem__(self, key: str) -> Any:
        return self.data.get(key, DEFAULT_CONFIG.get(key))

    def __setitem__(self, key: str, value: Any) -> None:
        self.data[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, DEFAULT_CONFIG.get(key, default))

    def update(self, **kwargs: Any) -> None:
        self.data.update(kwargs)
