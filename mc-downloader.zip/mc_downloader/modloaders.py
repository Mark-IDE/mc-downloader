"""模组加载器：Fabric / Quilt / Forge / NeoForge 的版本查询与安装。

Fabric、Quilt 是纯 JSON 方案：官方 meta 给出 profile.json，按 libraries 全部下载即可。
Forge、NeoForge 需要跑官方安装器（Java），所以这里还要负责找 Java。
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from .javadl import DownloadTask, JavaInstaller, _maven_path, make_sources
from .net import Cancelled, DownloadError, NetClient, Progress, human_size

FABRIC_META = "https://meta.fabricmc.net/v2"
QUILT_META = "https://meta.quiltmc.org/v3"
BMCL = "https://bmclapi2.bangbang93.com"
FORGE_MAVEN = "https://maven.minecraftforge.net"
NEOFORGE_MAVEN = "https://maven.neoforged.net/releases"
FORGE_PROMOS = "https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json"

LOADERS: Dict[str, Dict[str, str]] = {
    "fabric": {"label": "Fabric", "note": "轻量、更新快，优化与辅助 Mod 首选"},
    "quilt": {"label": "Quilt", "note": "Fabric 分支，兼容大部分 Fabric Mod"},
    "forge": {"label": "Forge", "note": "老牌加载器，整合包生态最大（需要 Java）"},
    "neoforge": {"label": "NeoForge", "note": "1.20.2 之后的 Forge 分支（需要 Java）"},
}

LOADER_KEYS = list(LOADERS.keys())


def loader_label(key: str) -> str:
    return LOADERS.get(key, {}).get("label", key)


def needs_java(key: str) -> bool:
    return key in ("forge", "neoforge")


# --------------------------------------------------------------------- 版本查询
def _ver_key(text: str) -> Tuple:
    nums = [int(n) for n in re.findall(r"\d+", text or "")[:6]]
    return tuple(nums) + (0,) * (6 - len(nums))


def fabric_versions(net: NetClient, mc: str, cancel=None) -> List[Tuple[str, str]]:
    data = net.fetch_json(f"{FABRIC_META}/versions/loader/{mc}", cancel=cancel)
    out = []
    for item in data or []:
        loader = item.get("loader") or {}
        ver = loader.get("version")
        if ver:
            out.append((ver, "稳定" if loader.get("stable") else "测试"))
    out.sort(key=lambda x: _ver_key(x[0]), reverse=True)
    return out


def quilt_versions(net: NetClient, mc: str, cancel=None) -> List[Tuple[str, str]]:
    data = net.fetch_json(f"{QUILT_META}/versions/loader/{mc}", cancel=cancel)
    out = []
    for item in data or []:
        loader = item.get("loader") or {}
        ver = loader.get("version")
        if ver:
            out.append((ver, "稳定" if "beta" not in ver and "alpha" not in ver else "测试"))
    out.sort(key=lambda x: _ver_key(x[0]), reverse=True)
    return out


def forge_versions(net: NetClient, mc: str, cancel=None) -> List[Tuple[str, str]]:
    promos: Dict[str, str] = {}
    try:
        promos = (net.fetch_json(FORGE_PROMOS, cancel=cancel) or {}).get("promos", {})
    except Exception:  # noqa: BLE001
        promos = {}
    recommended = promos.get(mc)
    latest = promos.get(f"{mc}-latest")

    builds: List[str] = []
    for url in (f"{BMCL}/forge/minecraft/{mc}",
                f"https://files.minecraftforge.net/net/minecraftforge/forge/maven-metadata.json"):
        try:
            data = net.fetch_json(url, cancel=cancel)
            if isinstance(data, list):
                builds = [str(item.get("version")) for item in data if item.get("version")]
            elif isinstance(data, dict):
                builds = [str(v) for v in (data.get(mc) or [])]
            if builds:
                break
        except Exception:  # noqa: BLE001
            continue
    builds = list(dict.fromkeys(builds))
    builds.sort(key=_ver_key, reverse=True)
    out: List[Tuple[str, str]] = []
    for ver in builds:
        tag = "推荐" if ver == recommended else ("最新" if ver == latest else "")
        out.append((ver, tag))
    if not out and recommended:
        out.append((recommended, "推荐"))
    return out


def mc_prefix(mc: str) -> str:
    """1.21.1 -> 21.1.  1.20.2 -> 20.2.  1.21 -> 21.0."""
    m = re.match(r"^\d+\.(\d+)(?:\.(\d+))?$", mc or "")
    if not m:
        return ""
    minor = m.group(1)
    patch = m.group(2) or "0"
    return f"{int(minor)}.{int(patch)}."


def neoforge_versions(net: NetClient, mc: str, cancel=None) -> List[Tuple[str, str]]:
    """NeoForge 从 maven-metadata.xml 里按 MC 版本前缀筛选。"""
    if mc == "1.20.1":
        # 1.20.1 时代还在 net.neoforged:forge 下
        urls = [f"{BMCL}/maven/net/neoforged/forge/maven-metadata.xml",
                f"{NEOFORGE_MAVEN}/net/neoforged/forge/maven-metadata.xml"]
    else:
        urls = [f"{BMCL}/maven/net/neoforged/neoforge/maven-metadata.xml",
                f"{NEOFORGE_MAVEN}/net/neoforged/neoforge/maven-metadata.xml"]
    xml = ""
    for url in urls:
        try:
            xml = net.fetch_bytes(url, cancel=cancel, retries=1).decode("utf-8", "ignore")
            if "<version>" in xml:
                break
        except Exception:  # noqa: BLE001
            continue
    versions = re.findall(r"<version>([^<]+)</version>", xml)
    if mc == "1.20.1":
        picked = [v for v in versions if v.startswith("1.20.1-")]
    else:
        prefix = mc_prefix(mc)
        picked = [v for v in versions if prefix and v.startswith(prefix)]
    picked = sorted(set(picked), key=_ver_key, reverse=True)
    return [(v, "最新" if i == 0 else "") for i, v in enumerate(picked)]


def loader_versions(net: NetClient, key: str, mc: str, cancel=None) -> List[Tuple[str, str]]:
    if key == "fabric":
        return fabric_versions(net, mc, cancel)
    if key == "quilt":
        return quilt_versions(net, mc, cancel)
    if key == "forge":
        return forge_versions(net, mc, cancel)
    if key == "neoforge":
        return neoforge_versions(net, mc, cancel)
    raise DownloadError(f"未知加载器：{key}")


# --------------------------------------------------------------------- 安装：Fabric / Quilt
def profile_url(key: str, mc: str, loader_ver: str) -> str:
    base = FABRIC_META if key == "fabric" else QUILT_META
    return f"{base}/versions/loader/{mc}/{loader_ver}/profile/json"


def install_fabric_like(
    net: NetClient,
    cfg: Dict[str, Any],
    root: Path,
    key: str,
    mc: str,
    loader_ver: str,
    log: Callable[[str, str], None],
    progress: Progress,
    cancel=None,
    install_parent: bool = True,
) -> Dict[str, Any]:
    started = time.time()
    root = Path(root)
    log(f"获取 {loader_label(key)} {loader_ver} 的 profile（MC {mc}）…")
    profile = net.fetch_json(profile_url(key, mc, loader_ver), cancel=cancel)
    vid = profile.get("id") or f"{key}-loader-{loader_ver}-{mc}"
    profile["id"] = vid
    profile.setdefault("inheritsFrom", mc)

    # 原版必须先存在（加载器只是叠加）
    parent_jar = root / "versions" / mc / f"{mc}.jar"
    if not parent_jar.exists():
        if not install_parent:
            log(f"提醒：原版 {mc} 还没安装，启动器可能会报错。", "warn")
        else:
            log(f"原版 {mc} 还没下载，先安装原版…", "warn")
            installer = JavaInstaller(net, cfg, log, progress, cancel)
            installer.install(mc, root, make_sources(cfg))

    vdir = root / "versions" / vid
    vdir.mkdir(parents=True, exist_ok=True)
    (vdir / f"{vid}.json").write_text(json.dumps(profile, ensure_ascii=False, indent=2), "utf-8")

    tasks: List[DownloadTask] = []
    for lib in profile.get("libraries") or []:
        name = lib.get("name") or ""
        if not name:
            continue
        rel = _maven_path(name)
        base = (lib.get("url") or ("https://maven.quiltmc.org/repository/release/"
                                  if key == "quilt" else "https://maven.fabricmc.net/")).rstrip("/")
        url = f"{base}/{rel}"
        artifact = (lib.get("downloads") or {}).get("artifact") or {}
        sha1 = lib.get("sha1") or artifact.get("sha1")
        size = artifact.get("size")
        tasks.append(DownloadTask("loader", name, root / "libraries" / rel, [url], size, sha1))

    progress.add_totals(len(tasks), sum(t.total for t in tasks))
    log(f"{loader_label(key)}：{len(tasks)} 个依赖库，"
        f"{human_size(sum(t.total for t in tasks))}", "info")

    def work(task: DownloadTask) -> None:
        net.download(task.urls, task.dest, task.size, task.sha1,
                     progress=progress, cancel=cancel, label=task.label)

    failures = net.run_tasks(tasks, work, cancel)
    if cancel is not None and cancel.is_set():
        raise Cancelled()
    if failures:
        for task, err in failures[:5]:
            log(f"  × {task.label}: {err}", "error")
        raise DownloadError(f"{len(failures)} 个依赖库下载失败")

    log(f"安装完成：{vdir}", "ok")
    return {
        "version_id": vid,
        "dir": str(vdir),
        "loader": key,
        "loader_version": loader_ver,
        "mc": mc,
        "elapsed": time.time() - started,
        "files": len(tasks),
    }


# --------------------------------------------------------------------- 安装：Forge / NeoForge
def installer_urls(key: str, mc: str, ver: str) -> List[str]:
    if key == "forge":
        rel = f"net/minecraftforge/forge/{mc}-{ver}/forge-{mc}-{ver}-installer.jar"
        return [f"{BMCL}/maven/{rel}", f"{FORGE_MAVEN}/{rel}"]
    if mc == "1.20.1":
        rel = f"net/neoforged/forge/{ver}/forge-{ver}-installer.jar"
    else:
        rel = f"net/neoforged/neoforge/{ver}/neoforge-{ver}-installer.jar"
    return [f"{BMCL}/maven/{rel}", f"{NEOFORGE_MAVEN}/{rel}"]


JAVA_GLOBS = [
    r"C:\Program Files\Java\*\bin\java.exe",
    r"C:\Program Files\Eclipse Adoptium\*\bin\java.exe",
    r"C:\Program Files\Microsoft\jdk-*\bin\java.exe",
    r"C:\Program Files\BellSoft\*\bin\java.exe",
    r"C:\Program Files\Zulu\*\bin\java.exe",
    r"C:\Program Files\Amazon Corretto\*\bin\java.exe",
    r"C:\Program Files (x86)\Java\*\bin\java.exe",
    r"%LOCALAPPDATA%\Programs\Eclipse Adoptium\*\bin\java.exe",
    r"%APPDATA%\.minecraft\runtime\**\bin\java.exe",
    r"%USERPROFILE%\MCDownloader\jre\**\bin\java.exe",
]


def find_java(cfg: Optional[Dict[str, Any]] = None) -> Optional[str]:
    """依次尝试：设置里的 java_path → JAVA_HOME → PATH → 常见安装目录。"""
    cfg = cfg or {}
    configured = str(cfg.get("java_path") or "").strip().strip('"')
    if configured and Path(configured).exists():
        return configured

    java_home = os.environ.get("JAVA_HOME", "").strip()
    if java_home:
        cand = Path(java_home) / "bin" / "java.exe"
        if cand.exists():
            return str(cand)

    which = shutil.which("java") or shutil.which("java.exe")
    if which:
        return which

    import glob as globmod

    hits: List[str] = []
    for pattern in JAVA_GLOBS:
        expanded = os.path.expandvars(pattern)
        if "%" in expanded:
            continue
        try:
            hits.extend(globmod.glob(expanded, recursive=True))
        except Exception:  # noqa: BLE001
            continue
    if hits:
        hits.sort(reverse=True)
        return hits[0]
    return None


def _run_installer(java: str, jar: Path, root: Path, log: Callable[[str, str], None],
                   cancel=None) -> int:
    cmd = [java, "-jar", str(jar), "--installClient", str(root)]
    log("运行安装器：" + " ".join(cmd))
    creationflags = 0
    if os.name == "nt":
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    proc = subprocess.Popen(
        cmd,
        cwd=str(root),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        creationflags=creationflags,
    )
    assert proc.stdout is not None
    for line in proc.stdout:
        line = line.rstrip()
        if line:
            log("  " + line, "debug")
        if cancel is not None and cancel.is_set():
            proc.terminate()
            raise Cancelled()
    return proc.wait()


def install_with_installer(
    net: NetClient,
    cfg: Dict[str, Any],
    root: Path,
    key: str,
    mc: str,
    ver: str,
    log: Callable[[str, str], None],
    progress: Progress,
    cancel=None,
) -> Dict[str, Any]:
    started = time.time()
    root = Path(root)
    fname = (f"forge-{mc}-{ver}-installer.jar" if key == "forge"
             else (f"forge-{ver}-installer.jar" if mc == "1.20.1" else f"neoforge-{ver}-installer.jar"))
    dest = root / ".mcdl" / "installers" / fname
    dest.parent.mkdir(parents=True, exist_ok=True)
    progress.add_totals(1, 0)
    log(f"下载 {loader_label(key)} 安装器 {fname} …")
    net.download(installer_urls(key, mc, ver), dest, progress=progress, cancel=cancel, label=fname)

    java = find_java(cfg)
    if not java:
        raise DownloadError(
            f"安装器已下载到 {dest}，但本机没有找到 Java。\n"
            "请安装 Java 17+ 或在「设置」里指定 java.exe 路径，然后重新点安装。"
        )
    log(f"使用 Java：{java}", "info")
    code = _run_installer(java, dest, root, log, cancel)
    if code != 0:
        raise DownloadError(f"安装器返回错误码 {code}，请看日志")

    wanted = None
    versions_dir = root / "versions"
    if versions_dir.exists():
        for p in versions_dir.iterdir():
            if p.is_dir() and f"{key}-{ver}" in p.name and (p / f"{p.name}.json").exists():
                wanted = p
                break
    if wanted is None:
        raise DownloadError("安装器执行完毕，但没有找到生成的版本目录，请检查日志")

    log(f"安装完成：{wanted}", "ok")
    return {
        "version_id": wanted.name,
        "dir": str(wanted),
        "loader": key,
        "loader_version": ver,
        "mc": mc,
        "elapsed": time.time() - started,
        "files": 0,
    }


def install_loader(
    net: NetClient,
    cfg: Dict[str, Any],
    root: Path,
    key: str,
    mc: str,
    ver: str,
    log: Callable[[str, str], None],
    progress: Progress,
    cancel=None,
) -> Dict[str, Any]:
    if key in ("fabric", "quilt"):
        return install_fabric_like(net, cfg, root, key, mc, ver, log, progress, cancel)
    if key in ("forge", "neoforge"):
        return install_with_installer(net, cfg, root, key, mc, ver, log, progress, cancel)
    raise DownloadError(f"未知加载器：{key}")


def installed_loader_versions(root: Path, key: str) -> List[str]:
    base = Path(root) / "versions"
    if not base.exists():
        return []
    out = []
    for p in base.iterdir():
        if p.is_dir() and key in p.name.lower():
            out.append(p.name)
    return sorted(out)
