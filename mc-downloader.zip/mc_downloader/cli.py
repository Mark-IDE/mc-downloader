"""命令行模式：方便脚本化下载，也用于自检。"""

from __future__ import annotations

import argparse
import os
import shutil
import sys
import threading
import time
from pathlib import Path
from typing import Any, List, Optional

from . import __version__, bedrock, javadl, modloaders, modrinth, mods, pojav
from .config import CACHE_DIR, CONFIG_PATH, Config
from .net import Cancelled, DownloadError, NetClient, Progress, fmt_eta, human_size, human_speed

SOURCE_CHOICES = ("auto", "official", "bmcl", "custom")
SOURCE_TEXT = {"auto": "自动", "official": "官方源", "bmcl": "BangBang 镜像", "custom": "自定义镜像"}


def _setup_console() -> None:
    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.kernel32.SetConsoleOutputCP(65001)
        except Exception:  # noqa: BLE001
            pass
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            pass


def _out(text: str = "") -> None:
    print(text, flush=True)


class ConsoleProgress:
    """在终端里画一条实时进度。"""

    def __init__(self, progress: Progress) -> None:
        self.progress = progress
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def __enter__(self) -> "ConsoleProgress":
        self._thread.start()
        return self

    def __exit__(self, *_exc: Any) -> None:
        self._stop.set()
        self._thread.join(timeout=1.0)
        snap = self.progress.snapshot()
        _out("\r" + " " * 96 + "\r", )
        _out(f"  完成 {snap['done_files']}/{snap['total_files']} 个文件，"
             f"{human_size(snap['done_bytes'])}")

    def _run(self) -> None:
        while not self._stop.is_set():
            snap = self.progress.snapshot()
            width = 24
            filled = int(width * snap["percent"] / 100)
            bar = "=" * filled + "-" * (width - filled)
            line = (f"  [{bar}] {snap['percent']:5.1f}%  "
                    f"{human_size(snap['done_bytes'])}/{human_size(snap['total_bytes'])}  "
                    f"{human_speed(snap['speed'])}  剩余 {fmt_eta(snap['eta'])}  "
                    f"{snap['done_files']}/{snap['total_files']}")
            print("\r" + line[:110].ljust(110), end="", flush=True)
            time.sleep(0.5)


def _make_net(cfg: Config, verbose: bool = True) -> NetClient:
    def log(msg: str, level: str = "info") -> None:
        if verbose and level in ("warn", "error", "ok"):
            _out(f"  · {msg}")

    return NetClient(
        threads=int(cfg.get("threads") or 16),
        retries=int(cfg.get("retries") or 3),
        timeout=int(cfg.get("timeout") or 20),
        verify_sha1=bool(cfg.get("verify_sha1")),
        allow_insecure_tls=bool(cfg.get("allow_insecure_tls")),
        log=log,
    )


# ------------------------------------------------------------------ 命令
def cmd_list(args, cfg: Config) -> int:
    cfg["source"] = args.source or cfg.get("source")
    net = _make_net(cfg)
    sources = javadl.make_sources(cfg)
    manifest = javadl.load_manifest(net, sources)
    versions = javadl.search_versions(manifest, args.search or "", args.type or "all")
    _out(f"共 {len(versions)} 个版本（源：{SOURCE_TEXT.get(cfg.get('source'), '自动')}），"
         f"最新正式版 {manifest.get('latest', {}).get('release')}")
    _out(f"{'版本':<24}{'类型':<12}{'发布时间':<12}")
    _out("-" * 50)
    limit = len(versions) if args.all else min(len(versions), args.limit)
    for item in versions[:limit]:
        _out(f"{item.get('id', ''):<24}"
             f"{javadl.VERSION_TYPE_LABEL.get(item.get('type'), item.get('type', '')):<12}"
             f"{javadl.release_time_text(item):<12}")
    if limit < len(versions):
        _out(f"... 还有 {len(versions) - limit} 个（用 --all 查看全部）")
    return 0


def cmd_install(args, cfg: Config) -> int:
    if args.source:
        cfg["source"] = args.source
    if args.threads:
        cfg["threads"] = args.threads
    if args.dir:
        cfg["java_dir"] = args.dir
    cfg["download_assets"] = not args.no_assets
    cfg["download_libraries"] = not args.no_libs
    root = Path(cfg.get("java_dir"))
    net = _make_net(cfg)
    sources = javadl.make_sources(cfg)
    progress = Progress()
    _out(f"安装 {args.version} → {root}")
    installer = javadl.JavaInstaller(net, cfg, lambda m, l="info": _out(f"  [{l}] {m}"), progress, None)
    with ConsoleProgress(progress):
        result = installer.install(args.version, root, sources)
    _out(f"完成：{result['dir']}（{result['files']} 个文件，{human_size(result['bytes'])}，"
         f"{result['elapsed']:.1f} 秒）")
    return 0


def _apk_source(args, cfg: Config) -> bedrock.ApkSource:
    if args.source:
        cfg["apk_source"] = args.source
    if getattr(args, "index", None):
        cfg["apk_index_url"] = args.index
    return bedrock.make_apk_source(cfg)


def cmd_apk_list(args, cfg: Config) -> int:
    source = _apk_source(args, cfg)
    if source.key == "direct":
        _out("「直接链接」模式不提供列表，请用：apk get --url <链接>")
        return 0
    net = _make_net(cfg)
    versions = source.list_versions(net)
    _out(f"{source.label}：{len(versions)} 个 APK")
    _out(f"{'版本':<16}{'通道':<10}{'大小':<12}文件")
    _out("-" * 72)
    limit = len(versions) if args.all else min(len(versions), args.limit)
    for apk in versions[:limit]:
        _out(f"{apk.version:<16}{apk.channel:<10}{apk.size_text:<12}{apk.filename}")
    if limit < len(versions):
        _out(f"... 还有 {len(versions) - limit} 个（用 --all 查看全部）")
    return 0


def cmd_apk_get(args, cfg: Config) -> int:
    source = _apk_source(args, cfg)
    dest_dir = Path(args.dir or cfg.get("apk_dir"))
    apk: Optional[bedrock.ApkVersion] = None
    if args.url:
        apk = bedrock.DirectSource().from_url(args.url, size=args.size or 0, sha1=args.sha1 or "")
    else:
        if not args.version:
            _out("请指定版本号，或用 --url 直接下载")
            return 2
        net = _make_net(cfg)
        versions = source.list_versions(net)
        for item in versions:
            if item.version == args.version:
                apk = item
                break
        if apk is None:
            candidates = [v.version for v in versions if v.version.startswith(args.version)]
            if candidates:
                _out(f"没有精确匹配 {args.version}，相近版本：{', '.join(candidates[:8])}")
            else:
                _out(f"没有找到版本 {args.version}")
            return 2
    net = _make_net(cfg)
    progress = Progress()
    with ConsoleProgress(progress):
        path = bedrock.download_apk(net, apk, dest_dir, progress, None, lambda m, l="info": _out(f"  · {m}"))
    _out(f"已保存：{path}")
    return 0


def cmd_launcher_list(args, cfg: Config) -> int:
    net = _make_net(cfg)
    assets = pojav.list_assets(net, args.repo, args.limit)
    _out(f"{pojav.REPOS[args.repo]['label']}：{len(assets)} 个文件")
    for asset in assets:
        _out(f"{asset.release:<16}{asset.date:<12}{asset.size_text:<12}{asset.name}")
    return 0


def cmd_launcher_get(args, cfg: Config) -> int:
    net = _make_net(cfg)
    assets = pojav.list_assets(net, args.repo, 20)
    target = None
    for asset in assets:
        if args.name.lower() in asset.name.lower():
            target = asset
            break
    if target is None:
        _out(f"没有找到匹配 {args.name} 的文件；可用：")
        for asset in assets[:12]:
            _out("  " + asset.name)
        return 2
    dest_dir = Path(args.dir or cfg.get("apk_dir"))
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / target.name
    progress = Progress()
    progress.add_totals(1, target.size)
    with ConsoleProgress(progress):
        net.download([target.url], dest, size=target.size or None, progress=progress, label=target.name)
    _out(f"已保存：{dest}")
    return 0


def cmd_loader_list(args, cfg: Config) -> int:
    net = _make_net(cfg)
    versions = modloaders.loader_versions(net, args.type, args.mc)
    _out(f"{modloaders.loader_label(args.type)} 可用版本（MC {args.mc}）：{len(versions)} 个")
    limit = len(versions) if args.all else min(len(versions), args.limit)
    for ver, tag in versions[:limit]:
        _out(f"  {ver:<18}{tag}")
    if limit < len(versions):
        _out(f"  ... 还有 {len(versions) - limit} 个（--all 查看全部）")
    return 0


def cmd_loader_install(args, cfg: Config) -> int:
    net = _make_net(cfg)
    mc = args.mc
    key = args.type
    ver = args.loader_version
    if not ver:
        versions = modloaders.loader_versions(net, key, mc)
        if not versions:
            _out(f"没有找到 {mc} 的 {key} 版本")
            return 2
        ver = versions[0][0]
        _out(f"自动选择最新版本：{ver}")
    root = Path(args.dir or cfg.get("java_dir"))
    if args.java:
        cfg["java_path"] = args.java
    progress = Progress()
    _out(f"安装 {modloaders.loader_label(key)} {ver} → {root}")
    with ConsoleProgress(progress):
        result = modloaders.install_loader(net, dict(cfg.data), root, key, mc, ver,
                                           lambda m, l="info": _out(f"  [{l}] {m}"), progress, None)
    _out(f"完成：{result['dir']}（{result['elapsed']:.1f} 秒）")
    return 0


def cmd_mod_search(args, cfg: Config) -> int:
    net = _make_net(cfg)
    hits = modrinth.search(net, " ".join(args.query), args.mc, args.loader, limit=args.limit)
    _out(f"Modrinth 搜索「{' '.join(args.query)}」：{len(hits)} 条（MC {args.mc or '不限'}，"
         f"{args.loader or '不限'}）")
    for hit in hits:
        _out(f"  {hit.title:<28}{hit.author:<16}{hit.download_text:>10}  {hit.slug}")
    return 0


def cmd_mod_install(args, cfg: Config) -> int:
    net = _make_net(cfg)
    hits = modrinth.search(net, args.slug, args.mc, args.loader, limit=10)
    exact = next((h for h in hits if h.slug.lower() == args.slug.lower()), None)
    project = exact or (hits[0] if hits else None)
    if project is None:
        _out(f"没有找到 {args.slug}")
        return 2
    files = modrinth.project_versions(net, project.project_id, args.mc, args.loader)
    chosen = modrinth.pick_file(files, args.mc, args.loader)
    if chosen is None:
        _out(f"{project.title} 没有匹配 {args.mc} / {args.loader} 的文件")
        return 2
    root = Path(args.dir or cfg.get("java_dir"))
    dest_dir = mods.resolve_mods_dir(root, args.version or "")
    _out(f"{project.title}：{chosen.filename}（{chosen.size_text}）→ {dest_dir}")
    progress = Progress()
    with ConsoleProgress(progress):
        batch = ([chosen] if args.no_deps
                 else modrinth.resolve_with_dependencies(net, chosen, args.mc, args.loader))
        for item in batch:
            path = modrinth.download_file(net, item, dest_dir, progress, None,
                                          lambda m, l="info": _out(f"  · {m}"))
            _out(f"  保存 {path.name}")
    if len(batch) > 1:
        _out(f"连同前置共 {len(batch)} 个文件")
    return 0


def cmd_mod_list(args, cfg: Config) -> int:
    root = Path(args.dir or cfg.get("java_dir"))
    directory = mods.resolve_mods_dir(root, args.version or "")
    entries = mods.list_mods(directory)
    _out(f"{directory}：{len(entries)} 个 Mod 文件")
    for entry in entries:
        _out(f"  [{entry.status}] {entry.name:<46}{entry.size_text:>10}")
    return 0


def cmd_mod_toggle(args, cfg: Config) -> int:
    root = Path(args.dir or cfg.get("java_dir"))
    directory = mods.resolve_mods_dir(root, args.version or "")
    entries = {e.name: e for e in mods.list_mods(directory)}
    entry = entries.get(args.name)
    if entry is None:
        _out(f"没有找到 {args.name}；可用：{', '.join(list(entries)[:10])}")
        return 2
    if args.delete:
        mods.delete_entry(entry)
        _out(f"已删除 {entry.name}")
        return 0
    new_path = mods.set_enabled(entry, not entry.enabled)
    _out(f"{entry.name} → {'已启用' if not entry.enabled else '已禁用'}（{new_path.name}）")
    return 0


def cmd_selftest(args, cfg: Config) -> int:
    ok = True
    _out(f"MC 下载器 v{__version__} 自检")
    _out("-" * 46)

    try:
        import tkinter  # noqa: F401

        _out("· 图形界面（tkinter）    OK")
    except Exception as exc:  # noqa: BLE001
        ok = False
        _out(f"· 图形界面（tkinter）    失败：{exc}")

    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        probe = CACHE_DIR / ".write_test"
        probe.write_text("ok", "utf-8")
        probe.unlink()
        _out(f"· 缓存目录 {CACHE_DIR} 可写")
    except Exception as exc:  # noqa: BLE001
        ok = False
        _out(f"· 缓存目录不可写：{exc}")

    try:
        usage = shutil.disk_usage(str(Path.home()))
        _out(f"· 磁盘剩余 {human_size(usage.free)}")
    except Exception:  # noqa: BLE001
        pass

    net = _make_net(cfg)
    for key, src in (("官方源", javadl.JavaSource("official", "官方源", javadl.MANIFEST_URL, None)),
                     ("BangBang 镜像", javadl.JavaSource("bmcl", "BangBang 镜像",
                                                         f"{javadl.BMCL_BASE}/mc/game/version_manifest_v2.json",
                                                         javadl.BMCL_BASE))):
        started = time.time()
        try:
            data = net.fetch_json(src.manifest)
            _out(f"· {key}            OK（{len(data.get('versions', []))} 个版本，"
                 f"{time.time() - started:.1f}s）")
        except Exception as exc:  # noqa: BLE001
            _out(f"· {key}            失败：{exc}")

    for key in ("pojav", "jre"):
        try:
            assets = pojav.list_assets(net, key, 1)
            _out(f"· GitHub {key:<10} OK（{len(assets)} 个文件）")
        except Exception as exc:  # noqa: BLE001
            _out(f"· GitHub {key:<10} 失败：{exc}")

    try:
        hits = modrinth.search(net, "sodium", "1.20.1", "fabric", limit=1)
        _out(f"· Modrinth         OK（搜索到 {hits[0].title if hits else '0'}）")
    except Exception as exc:  # noqa: BLE001
        _out(f"· Modrinth         失败：{exc}")

    try:
        fver = modloaders.fabric_versions(net, "1.20.1")
        _out(f"· Fabric meta      OK（{len(fver)} 个加载器版本）")
    except Exception as exc:  # noqa: BLE001
        _out(f"· Fabric meta      失败：{exc}")

    try:
        nver = modloaders.forge_versions(net, "1.20.1")
        _out(f"· Forge 版本        OK（{len(nver)} 个版本）")
    except Exception as exc:  # noqa: BLE001
        _out(f"· Forge 版本        失败：{exc}")

    java = modloaders.find_java(dict(cfg.data))
    _out(f"· Java            {'OK：' + java if java else '未找到（Forge / NeoForge 需要）'}")

    _out("-" * 46)
    _out("自检完成" if ok else "自检发现问题")
    return 0 if ok else 1


# ------------------------------------------------------------------ 入口
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="main.py",
        description="MC 下载器 —— Minecraft Java 版 / 安卓基岩版下载工具",
        epilog="不带参数运行会打开图形界面；加 --gui 可强制打开界面。",
    )
    parser.add_argument("--version", action="version", version=f"MC 下载器 {__version__}")
    sub = parser.add_subparsers(dest="command")

    p_list = sub.add_parser("list", help="列出所有可下载的 Java 版")
    p_list.add_argument("--type", choices=["all", "release", "snapshot", "old", "april"], default="all")
    p_list.add_argument("--search", default="")
    p_list.add_argument("--source", choices=SOURCE_CHOICES)
    p_list.add_argument("--limit", type=int, default=40)
    p_list.add_argument("--all", action="store_true", help="显示全部版本")
    p_list.set_defaults(func=cmd_list)

    p_install = sub.add_parser("install", help="下载并安装指定 Java 版")
    p_install.add_argument("version")
    p_install.add_argument("--dir", help="安装目录")
    p_install.add_argument("--source", choices=SOURCE_CHOICES)
    p_install.add_argument("--threads", type=int)
    p_install.add_argument("--no-assets", action="store_true", help="不下载资源文件")
    p_install.add_argument("--no-libs", action="store_true", help="不下载依赖库")
    p_install.set_defaults(func=cmd_install)

    p_apk = sub.add_parser("apk", help="安卓基岩版 APK")
    apk_sub = p_apk.add_subparsers(dest="apk_command")
    p_apk_list = apk_sub.add_parser("list", help="列出 APK 版本")
    p_apk_list.add_argument("--source", choices=["archive", "json", "direct"])
    p_apk_list.add_argument("--index", help="自定义 JSON 清单地址")
    p_apk_list.add_argument("--limit", type=int, default=30)
    p_apk_list.add_argument("--all", action="store_true")
    p_apk_list.set_defaults(func=cmd_apk_list)

    p_apk_get = apk_sub.add_parser("get", help="下载 APK")
    p_apk_get.add_argument("version", nargs="?")
    p_apk_get.add_argument("--url")
    p_apk_get.add_argument("--size", type=int, default=0)
    p_apk_get.add_argument("--sha1", default="")
    p_apk_get.add_argument("--source", choices=["archive", "json", "direct"])
    p_apk_get.add_argument("--index")
    p_apk_get.add_argument("--dir")
    p_apk_get.set_defaults(func=cmd_apk_get)

    p_launcher = sub.add_parser("launcher", help="安卓 Java 启动器（PojavLauncher / JRE）")
    launcher_sub = p_launcher.add_subparsers(dest="launcher_command")
    p_ls = launcher_sub.add_parser("list", help="列出可下载文件")
    p_ls.add_argument("--repo", choices=list(pojav.REPOS), default="pojav")
    p_ls.add_argument("--limit", type=int, default=12)
    p_ls.set_defaults(func=cmd_launcher_list)
    p_lg = launcher_sub.add_parser("get", help="下载指定文件")
    p_lg.add_argument("name", help="文件名关键字，如 PojavLauncher.apk")
    p_lg.add_argument("--repo", choices=list(pojav.REPOS), default="pojav")
    p_lg.add_argument("--dir")
    p_lg.set_defaults(func=cmd_launcher_get)

    p_loader = sub.add_parser("loader", help="模组加载器（Fabric / Quilt / Forge / NeoForge）")
    loader_sub = p_loader.add_subparsers(dest="loader_command")
    p_ll = loader_sub.add_parser("list", help="列出某版本可用的加载器版本")
    p_ll.add_argument("--mc", required=True, help="Minecraft 版本，如 1.20.1")
    p_ll.add_argument("--type", choices=modloaders.LOADER_KEYS, default="fabric")
    p_ll.add_argument("--limit", type=int, default=15)
    p_ll.add_argument("--all", action="store_true")
    p_ll.set_defaults(func=cmd_loader_list)

    p_li = loader_sub.add_parser("install", help="安装加载器")
    p_li.add_argument("--mc", required=True)
    p_li.add_argument("--type", choices=modloaders.LOADER_KEYS, default="fabric")
    p_li.add_argument("--loader-version", help="不填则用最新")
    p_li.add_argument("--dir", help=".minecraft 目录")
    p_li.add_argument("--java", help="java.exe 路径（Forge / NeoForge 用）")
    p_li.set_defaults(func=cmd_loader_install)

    p_mod = sub.add_parser("mod", help="Modrinth 上的 Mod 搜索 / 下载 / 管理")
    mod_sub = p_mod.add_subparsers(dest="mod_command")
    p_ms = mod_sub.add_parser("search", help="搜索 Mod")
    p_ms.add_argument("query", nargs="+")
    p_ms.add_argument("--mc", default="")
    p_ms.add_argument("--loader", default="fabric", choices=["", "fabric", "quilt", "forge", "neoforge"])
    p_ms.add_argument("--limit", type=int, default=15)
    p_ms.set_defaults(func=cmd_mod_search)

    p_mi = mod_sub.add_parser("install", help="下载 Mod 到 mods 目录")
    p_mi.add_argument("slug", help="Modrinth 项目 slug，如 sodium")
    p_mi.add_argument("--mc", default="")
    p_mi.add_argument("--loader", default="fabric")
    p_mi.add_argument("--dir", help=".minecraft 目录")
    p_mi.add_argument("--version", help="版本 id（用于版本隔离的 mods 目录）")
    p_mi.add_argument("--no-deps", action="store_true", help="不下载前置 Mod")
    p_mi.set_defaults(func=cmd_mod_install)

    p_ml = mod_sub.add_parser("list", help="列出已安装的 Mod")
    p_ml.add_argument("--dir")
    p_ml.add_argument("--version")
    p_ml.set_defaults(func=cmd_mod_list)

    p_mt = mod_sub.add_parser("toggle", help="启用 / 禁用 / 删除某个 Mod")
    p_mt.add_argument("name", help="文件名（见 mod list）")
    p_mt.add_argument("--dir")
    p_mt.add_argument("--version")
    p_mt.add_argument("--delete", action="store_true", help="直接删除")
    p_mt.set_defaults(func=cmd_mod_toggle)

    p_self = sub.add_parser("selftest", help="环境与网络自检")
    p_self.set_defaults(func=cmd_selftest)
    return parser


def run_cli(argv: List[str]) -> int:
    _setup_console()
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 0
    cfg = Config()
    try:
        return int(args.func(args, cfg) or 0)
    except DownloadError as exc:
        _out(f"错误：{exc}")
        return 1
    except Cancelled:
        _out("已取消")
        return 130
    except KeyboardInterrupt:
        _out("已中断")
        return 130
