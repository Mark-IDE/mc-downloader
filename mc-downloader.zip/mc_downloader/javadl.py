"""Minecraft Java 版下载安装核心。

流程与 PCL 一致：
1. 拉取 version_manifest_v2.json，列出全部版本
2. 取版本 JSON，写入 .minecraft/versions/<id>/<id>.json
3. 下载 client.jar、libraries（含 natives 解压）、assets（含 legacy 虚拟化）、logging 配置
4. 生成 launcher_profiles.json 等启动器兼容文件
"""

from __future__ import annotations

import json
import os
import re
import time
import urllib.parse
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

from .config import CACHE_DIR
from .net import Cancelled, DownloadError, NetClient, Progress, human_size, short_url

MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
BMCL_BASE = "https://bmclapi2.bangbang93.com"

# 官方域名 → BMCLAPI 镜像路径
BMCL_HOST_MAP: Dict[str, str] = {
    "launchermeta.mojang.com": "",
    "piston-meta.mojang.com": "",
    "piston-data.mojang.com": "",
    "launcher.mojang.com": "",
    "resources.download.minecraft.net": "/assets",
    "libraries.minecraft.net": "/maven",
    "files.minecraftforge.net": "/maven",
    "maven.minecraftforge.net": "/maven",
}

VERSION_TYPE_LABEL = {
    "release": "正式版",
    "snapshot": "快照",
    "old_beta": "远古 Beta",
    "old_alpha": "远古 Alpha",
    "april_fools": "愚人节",
}

OS_NAME = "windows"


def host_arch() -> str:
    """当前系统架构：x64 / x86 / arm64。"""
    import platform

    machine = (platform.machine() or "").lower()
    if machine in ("arm64", "aarch64"):
        return "arm64"
    if machine in ("x86", "i386", "i686", "i86pc"):
        return "x86"
    return "x64"


OS_ARCH = host_arch()


def arch_compatible(name: str, arch: str = "") -> bool:
    """按本机架构过滤 natives 包（Mojang 的 json 只区分系统、不区分架构）。"""
    arch = arch or OS_ARCH
    low = (name or "").lower()
    if "natives" not in low:
        return True
    is_arm = "arm64" in low or "aarch64" in low or "arm32" in low
    is_x86 = bool(re.search(r"natives-[a-z0-9]+-x86(?!_?64)", low))
    if arch == "arm64":
        return is_arm
    if arch == "x86":
        return is_x86 or not (is_arm or is_x86)
    # x64：排除 arm64 与 32 位 x86 专用包
    return not is_arm and not is_x86


@dataclass
class JavaSource:
    key: str
    label: str
    manifest: str
    base: Optional[str] = None  # None = 官方

    def map(self, url: str) -> str:
        if not url:
            return url
        if self.base is None:
            return url
        return map_to_base(url, self.base)


def map_to_base(url: str, base: str) -> str:
    """把官方 URL 映射到镜像根地址。"""
    base = base.rstrip("/")
    parts = urllib.parse.urlsplit(url)
    host = (parts.hostname or "").lower()
    if host == "resources.download.minecraft.net":
        return f"{base}/assets{parts.path}"
    if host in ("libraries.minecraft.net", "files.minecraftforge.net", "maven.minecraftforge.net"):
        if parts.path.startswith("/maven"):
            return f"{base}{parts.path}"
        return f"{base}/maven{parts.path}"
    return f"{base}{parts.path}"


def map_to_bmcl(url: str) -> str:
    parts = urllib.parse.urlsplit(url)
    host = (parts.hostname or "").lower()
    if host in BMCL_HOST_MAP:
        return f"{BMCL_BASE}{BMCL_HOST_MAP[host]}{parts.path}"
    return url


def make_sources(cfg) -> List[JavaSource]:
    """按配置生成有序的下载源列表（第一个优先，其余用于回退）。"""
    official = JavaSource("official", "官方源", MANIFEST_URL, None)
    bmcl = JavaSource("bmcl", "Bang Bang 镜像", f"{BMCL_BASE}/mc/game/version_manifest_v2.json", BMCL_BASE)
    custom_base = (cfg.get("custom_base") or "").strip().rstrip("/")
    custom = None
    if custom_base:
        custom = JavaSource("custom", "自定义镜像", f"{custom_base}/mc/game/version_manifest_v2.json", custom_base)

    want = cfg.get("source", "auto")
    if want == "official":
        return [official]
    if want == "bmcl":
        return [bmcl] + ([official] if cfg.get("fallback_official") else [])
    if want == "custom" and custom:
        return [custom] + ([official] if cfg.get("fallback_official") else [])
    # auto：镜像优先，官方兜底
    if custom:
        return [custom, official]
    return [bmcl, official] if cfg.get("fallback_official") else [bmcl]


# --------------------------------------------------------------------- manifest
def manifest_cache_path(source_key: str) -> Path:
    return CACHE_DIR / f"manifest_{source_key}.json"


def load_manifest(net: NetClient, sources: Sequence[JavaSource], ttl: int = 1800) -> Dict[str, Any]:
    errors: List[str] = []
    for src in sources:
        cache = manifest_cache_path(src.key)
        try:
            if cache.exists() and time.time() - cache.stat().st_mtime < ttl:
                return json.loads(cache.read_text("utf-8"))
        except Exception:  # noqa: BLE001
            pass
        try:
            data = net.fetch_json(src.manifest)
            if not isinstance(data, dict) or "versions" not in data:
                raise DownloadError("版本清单格式异常", src.manifest)
            try:
                cache.parent.mkdir(parents=True, exist_ok=True)
                cache.write_text(json.dumps(data, ensure_ascii=False), "utf-8")
            except OSError:
                pass
            return data
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{src.label}: {exc}")
    raise DownloadError("；".join(errors) or "无法获取版本清单")


def version_by_id(manifest: Dict[str, Any], version_id: str) -> Dict[str, Any]:
    for item in manifest.get("versions", []):
        if item.get("id") == version_id:
            return item
    raise DownloadError(f"版本清单中没有 {version_id}")


# --------------------------------------------------------------------- rules
def _os_matches(rule_os: Dict[str, Any], os_name: str, arch: str) -> bool:
    if not rule_os:
        return True
    name = rule_os.get("name")
    if name and name != os_name:
        return False
    rule_arch = rule_os.get("arch")
    if rule_arch:
        norm = {"x86_64": "x64", "amd64": "x64", "x86": "x86", "arm64": "arm64", "aarch64": "arm64"}
        if norm.get(rule_arch, rule_arch) != norm.get(arch, arch):
            return False
    return True


def rules_allow(rules: Optional[List[Dict[str, Any]]], os_name: str = OS_NAME, arch: str = OS_ARCH,
                features: Optional[Dict[str, bool]] = None) -> bool:
    """Mojang 规则求值：默认不允许，按顺序覆盖。"""
    if not rules:
        return True
    features = features or {}
    allowed = False
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        ok = _os_matches(rule.get("os") or {}, os_name, arch)
        if ok:
            for key, val in (rule.get("features") or {}).items():
                if bool(features.get(key)) != bool(val):
                    ok = False
                    break
        if ok:
            allowed = rule.get("action", "allow") == "allow"
    return allowed


# --------------------------------------------------------------------- plan
@dataclass
class DownloadTask:
    kind: str
    label: str
    dest: Path
    urls: List[str]
    size: Optional[int] = None
    sha1: Optional[str] = None

    @property
    def total(self) -> int:
        return int(self.size or 0)


@dataclass
class NativesJob:
    jar: Path
    dest_dir: Path
    excludes: List[str] = field(default_factory=list)


@dataclass
class InstallPlan:
    version_id: str
    root: Path
    tasks: List[DownloadTask] = field(default_factory=list)
    natives: List[NativesJob] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @property
    def total_bytes(self) -> int:
        return sum(t.total for t in self.tasks)


def _lib_urls(entry: Dict[str, Any], sources: Sequence[JavaSource]) -> List[str]:
    url = entry.get("url") or ""
    if not url:
        return []
    return _dedupe([s.map(url) for s in sources])


def _dedupe(items: Iterable[str]) -> List[str]:
    seen: set = set()
    out: List[str] = []
    for item in items:
        if item and item not in seen:
            seen.add(item)
            out.append(item)
    return out


def build_plan(
    version_json: Dict[str, Any],
    root: Path,
    sources: Sequence[JavaSource],
    version_item: Optional[Dict[str, Any]] = None,
    with_assets: bool = True,
    with_libraries: bool = True,
    with_logging: bool = True,
) -> InstallPlan:
    version_id = version_json.get("id") or (version_item or {}).get("id") or "unknown"
    plan = InstallPlan(version_id=version_id, root=root)

    # 1) client.jar
    client = (version_json.get("downloads") or {}).get("client") or {}
    if client.get("url"):
        plan.tasks.append(
            DownloadTask(
                "client",
                f"{version_id}.jar",
                root / "versions" / version_id / f"{version_id}.jar",
                _lib_urls(client, sources),
                client.get("size"),
                client.get("sha1"),
            )
        )

    # 2) libraries + natives
    if with_libraries:
        for lib in version_json.get("libraries") or []:
            if not rules_allow(lib.get("rules")):
                continue
            if not arch_compatible(lib.get("name") or ""):
                continue
            downloads = lib.get("downloads") or {}
            artifact = downloads.get("artifact") or {}
            name = lib.get("name") or "library"
            if artifact.get("url"):
                rel = artifact.get("path") or _maven_path(name)
                plan.tasks.append(
                    DownloadTask(
                        "library",
                        name,
                        root / "libraries" / rel,
                        _lib_urls(artifact, sources),
                        artifact.get("size"),
                        artifact.get("sha1"),
                    )
                )
                if _is_native_lib(lib, rel):
                    plan.natives.append(
                        NativesJob(
                            jar=root / "libraries" / rel,
                            dest_dir=root / "versions" / version_id / "natives",
                            excludes=(lib.get("extract") or {}).get("exclude") or [],
                        )
                    )
            # 旧版 natives（classifiers）
            natives_map = lib.get("natives") or {}
            if natives_map:
                classifier = natives_map.get(OS_NAME)
                if classifier:
                    classifier = classifier.replace("${arch}", "64")
                    cls = (downloads.get("classifiers") or {}).get(classifier) or {}
                    if cls.get("url"):
                        rel = cls.get("path") or _maven_path(name, classifier)
                        plan.tasks.append(
                            DownloadTask(
                                "native",
                                f"{name}:{classifier}",
                                root / "libraries" / rel,
                                _lib_urls(cls, sources),
                                cls.get("size"),
                                cls.get("sha1"),
                            )
                        )
                        plan.natives.append(
                            NativesJob(
                                jar=root / "libraries" / rel,
                                dest_dir=root / "versions" / version_id / "natives",
                                excludes=(lib.get("extract") or {}).get("exclude") or [],
                            )
                        )

    # 3) asset index + objects
    asset_index = version_json.get("assetIndex") or {}
    if with_assets and asset_index.get("url"):
        plan.tasks.append(
            DownloadTask(
                "asset_index",
                f"assets/indexes/{asset_index.get('id')}.json",
                root / "assets" / "indexes" / f"{asset_index.get('id')}.json",
                _lib_urls(asset_index, sources),
                asset_index.get("size"),
                asset_index.get("sha1"),
            )
        )

    # 4) 日志配置
    if with_logging:
        logging_cfg = ((version_json.get("logging") or {}).get("client") or {}).get("file") or {}
        if logging_cfg.get("url"):
            plan.tasks.append(
                DownloadTask(
                    "logging",
                    logging_cfg.get("id") or "log_config",
                    root / "assets" / "log_configs" / (logging_cfg.get("id") or "client"),
                    _lib_urls(logging_cfg, sources),
                    logging_cfg.get("size"),
                    logging_cfg.get("sha1"),
                )
            )

    # 去重：旧版资源索引里多个文件名会指向同一个 hash，避免多线程抢同一个文件
    seen: set = set()
    unique: List[DownloadTask] = []
    for task in plan.tasks:
        key = str(task.dest).lower()
        if key in seen:
            continue
        seen.add(key)
        unique.append(task)
    plan.tasks = unique

    seen_jobs: set = set()
    jobs: List[NativesJob] = []
    for job in plan.natives:
        key = (str(job.jar).lower(), str(job.dest_dir).lower())
        if key in seen_jobs:
            continue
        seen_jobs.add(key)
        jobs.append(job)
    plan.natives = jobs
    return plan


def _maven_path(name: str, classifier: str = "") -> str:
    """group:artifact:version[:classifier][@ext] → maven 相对路径。"""
    ext = "jar"
    if "@" in name:
        name, ext = name.split("@", 1)
    parts = name.split(":")
    group = parts[0]
    artifact = parts[1] if len(parts) > 1 else "artifact"
    version = parts[2] if len(parts) > 2 else "0"
    cls = classifier or (parts[3] if len(parts) > 3 else "")
    fname = f"{artifact}-{version}" + (f"-{cls}" if cls else "") + f".{ext}"
    return "/".join(group.split(".") + [artifact, version, fname])


def _is_native_lib(lib: Dict[str, Any], rel_path: str) -> bool:
    if lib.get("natives"):
        return False
    name = (lib.get("name") or "").lower()
    rel = rel_path.lower()
    return ("natives-windows" in name or "natives-linux" in name or "natives-macos" in name
            or "natives-windows" in rel or "natives-linux" in rel or "natives-macos" in rel)


def assets_tasks(
    index: Dict[str, Any],
    root: Path,
    sources: Sequence[JavaSource],
) -> List[DownloadTask]:
    objects = index.get("objects") or {}
    base_url = "https://resources.download.minecraft.net"
    tasks: List[DownloadTask] = []
    seen: set = set()
    for _name, obj in objects.items():
        h = obj.get("hash")
        if not h or len(h) < 4 or h in seen:
            continue
        seen.add(h)
        rel = f"{h[:2]}/{h}"
        urls = _dedupe([s.map(f"{base_url}/{rel}") for s in sources])
        tasks.append(
            DownloadTask(
                "asset",
                rel,
                root / "assets" / "objects" / h[:2] / h,
                urls,
                obj.get("size"),
                h,
            )
        )
    return tasks


# --------------------------------------------------------------------- install
class JavaInstaller:
    def __init__(
        self,
        net: NetClient,
        cfg,
        log: Callable[[str, str], None],
        progress: Progress,
        cancel: Optional[Any] = None,
    ) -> None:
        self.net = net
        self.cfg = cfg
        self.log = log
        self.progress = progress
        self.cancel = cancel
        self._legacy_assets: Optional[Dict[str, Any]] = None

    def install(self, version_id: str, root: Path, sources: Sequence[JavaSource]) -> Dict[str, Any]:
        started = time.time()
        manifest = load_manifest(self.net, sources)
        item = version_by_id(manifest, version_id)
        self.log(f"版本 {version_id}（{VERSION_TYPE_LABEL.get(item.get('type'), item.get('type'))}），正在获取版本 JSON…")

        version_json = self._fetch_version_json(item, sources)
        vdir = root / "versions" / version_id
        vdir.mkdir(parents=True, exist_ok=True)
        (vdir / f"{version_id}.json").write_text(json.dumps(version_json, ensure_ascii=False, indent=2), "utf-8")

        plan = build_plan(
            version_json,
            root,
            sources,
            version_item=item,
            with_assets=bool(self.cfg.get("download_assets")),
            with_libraries=bool(self.cfg.get("download_libraries")),
            with_logging=bool(self.cfg.get("download_logging")),
        )

        # 资源索引里再展开出所有资源文件
        index_task = next((t for t in plan.tasks if t.kind == "asset_index"), None)
        asset_tasks: List[DownloadTask] = []
        if index_task is not None:
            self.progress.add_totals(1, index_task.total)
            self.net.download(
                index_task.urls, index_task.dest, index_task.size, index_task.sha1,
                progress=None, cancel=self.cancel, label=index_task.label,
            )
            try:
                index = json.loads(index_task.dest.read_text("utf-8"))
            except Exception as exc:  # noqa: BLE001
                raise DownloadError(f"资源索引读取失败：{exc}", str(index_task.dest))
            asset_tasks = assets_tasks(index, root, sources)
            plan.tasks = [t for t in plan.tasks if t.kind != "asset_index"] + asset_tasks
            self.log(
                f"资源索引 {index.get('id')}：{len(asset_tasks)} 个资源文件，共 "
                f"{human_size(sum(t.total for t in asset_tasks))}",
                "info",
            )
            self._legacy_assets = index

        self.progress.add_totals(len(plan.tasks), plan.total_bytes)
        self.log(
            f"共 {len(plan.tasks)} 个文件 / {human_size(plan.total_bytes)}，"
            f"使用 {self.net.threads} 线程下载…",
            "info",
        )

        def _work(task: DownloadTask) -> None:
            self.net.download(
                task.urls, task.dest, task.size, task.sha1,
                progress=self.progress, cancel=self.cancel, label=task.label,
            )

        failures = self.net.run_tasks(plan.tasks, _work, self.cancel)
        if self.cancel is not None and self.cancel.is_set():
            raise Cancelled()

        if failures:
            self.log(f"{len(failures)} 个文件下载失败，可重新下载（已完成的文件会自动跳过）。", "error")
            for task, err in failures[:8]:
                self.log(f"  × {task.label}: {err}", "error")
            raise DownloadError(f"{len(failures)} 个文件下载失败")

        # natives 解压
        for job in plan.natives:
            try:
                count = extract_natives(job.jar, job.dest_dir, job.excludes)
                if count:
                    self.log(f"解压 natives：{job.dest_dir.name}/{job.jar.name}（{count} 个文件）")
            except Exception as exc:  # noqa: BLE001
                self.log(f"解压 natives 失败：{job.jar.name} - {exc}", "warn")

        # 旧版资源虚拟化
        self._virtualize_assets(root, version_json)

        self._write_launcher_profiles(root, version_id, version_json)
        elapsed = time.time() - started
        self.log(f"安装完成：{vdir}（耗时 {elapsed:.1f} 秒）", "ok")
        return {
            "version_id": version_id,
            "dir": str(vdir),
            "files": len(plan.tasks),
            "bytes": plan.total_bytes,
            "elapsed": elapsed,
        }

    # ------------------------------------------------------------ internals
    def _fetch_version_json(self, item: Dict[str, Any], sources: Sequence[JavaSource]) -> Dict[str, Any]:
        url = item.get("url") or ""
        errors: List[str] = []
        for src in sources:
            try:
                return self.net.fetch_json(src.map(url))
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{src.label}: {exc}")
        raise DownloadError("；".join(errors) or "无法获取版本 JSON", url)

    def _virtualize_assets(self, root: Path, version_json: Dict[str, Any]) -> None:
        index = self._legacy_assets
        if not index:
            return
        objects = index.get("objects") or {}
        if index.get("map_to_resources"):
            target_root = root / "resources"
            mode = "map_to_resources"
        elif index.get("virtual"):
            target_root = root / "assets" / "virtual" / "legacy"
            mode = "virtual"
        else:
            return
        made = 0
        for name, obj in objects.items():
            h = obj.get("hash") or ""
            src = root / "assets" / "objects" / h[:2] / h
            if not src.exists():
                continue
            dst = target_root / name
            dst.parent.mkdir(parents=True, exist_ok=True)
            try:
                if not dst.exists():
                    try:
                        os.link(src, dst)
                    except OSError:
                        import shutil

                        shutil.copy2(src, dst)
                    made += 1
            except OSError:
                continue
        if made:
            self.log(f"旧版资源已虚拟化（{mode}）：{made} 个文件", "info")

    def _write_launcher_profiles(self, root: Path, version_id: str, version_json: Dict[str, Any]) -> None:
        path = root / "launcher_profiles.json"
        if path.exists():
            return
        data = {
            "profiles": {
                version_id: {
                    "name": version_id,
                    "type": "custom",
                    "lastVersionId": version_id,
                    "created": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime()),
                }
            },
            "settings": {"language": "zh_CN", "enableSnapshots": True},
            "version": 3,
        }
        try:
            path.write_text(json.dumps(data, ensure_ascii=False, indent=2), "utf-8")
        except OSError:
            pass


def extract_natives(jar: Path, dest_dir: Path, excludes: Sequence[str] = ()) -> int:
    """把 natives jar 里的动态库解压到 dest_dir。"""
    if not jar.exists():
        return 0
    dest_dir.mkdir(parents=True, exist_ok=True)
    count = 0
    skip_prefix = tuple(excludes or ()) + ("META-INF/",)
    with zipfile.ZipFile(jar) as zf:
        for info in zf.infolist():
            name = info.filename
            if info.is_dir() or name.startswith(skip_prefix):
                continue
            target = (dest_dir / name).resolve()
            try:
                if dest_dir.resolve() not in target.parents and target != dest_dir.resolve():
                    continue  # 防目录穿越
            except OSError:
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, open(target, "wb") as out:
                out.write(src.read())
            count += 1
    return count


def search_versions(manifest: Dict[str, Any], keyword: str = "", vtype: str = "all") -> List[Dict[str, Any]]:
    versions = manifest.get("versions", [])
    if vtype == "release":
        versions = [v for v in versions if v.get("type") == "release"]
    elif vtype == "snapshot":
        versions = [v for v in versions if v.get("type") == "snapshot"]
    elif vtype == "old":
        versions = [v for v in versions if v.get("type") in ("old_beta", "old_alpha")]
    elif vtype == "april":
        versions = [v for v in versions if v.get("type") == "april_fools"]
    if keyword:
        kw = keyword.lower()
        versions = [v for v in versions if kw in (v.get("id") or "").lower()]
    return versions


def release_time_text(item: Dict[str, Any]) -> str:
    raw = item.get("releaseTime") or item.get("time") or ""
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", raw)
    return f"{m.group(1)}-{m.group(2)}-{m.group(3)}" if m else raw[:10]


def version_dir(root: Path, version_id: str) -> Path:
    return root / "versions" / version_id


def installed_versions(root: Path) -> List[str]:
    base = root / "versions"
    if not base.exists():
        return []
    return sorted(p.name for p in base.iterdir() if p.is_dir())
