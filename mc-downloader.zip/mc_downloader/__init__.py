"""MC 下载器 —— Minecraft Java 版 / 安卓基岩版 下载工具。"""

__version__ = "1.1.0"
__all__ = ["__version__"]
