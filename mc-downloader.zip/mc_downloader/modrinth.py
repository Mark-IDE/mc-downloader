"""Modrinth 客户端：搜索 Mod、查版本、下载文件、解析依赖。

Modrinth 的公开 API 不需要 key，限制是每小时 300 次请求，足够个人使用。
"""

from __future__ import annotations

import json
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from .net import Cancelled, DownloadError, NetClient, Progress, human_size

BASE = "https://api.modrinth.com/v2"
USER_AGENT = "MCDownloader/1.0 (mc-version-downloader)"

SORTS = {
    "相关度": "relevance",
    "下载量": "downloads",
    "关注数": "follows",
    "最新发布": "newest",
    "最近更新": "updated",
}


@dataclass
class ModHit:
    project_id: str
    slug: str
    title: str
    description: str
    author: str
    downloads: int
    icon_url: str
    categories: List[str] = field(default_factory=list)
    versions: List[str] = field(default_factory=list)

    @property
    def download_text(self) -> str:
        n = self.downloads or 0
        if n >= 100_000_000:
            return f"{n / 100_000_000:.1f} 亿"
        if n >= 10_000:
            return f"{n / 10_000:.1f} 万"
        return str(n)


@dataclass
class ModFile:
    project_id: str
    version_id: str
    name: str
    version_number: str
    filename: str
    url: str
    size: int = 0
    sha1: str = ""
    sha512: str = ""
    loaders: List[str] = field(default_factory=list)
    game_versions: List[str] = field(default_factory=list)
    version_type: str = "release"
    dependencies: List[Dict[str, Any]] = field(default_factory=list)
    date: str = ""

    @property
    def size_text(self) -> str:
        return human_size(self.size) if self.size else "未知"

    @property
    def channel(self) -> str:
        return {"release": "正式", "beta": "测试", "alpha": "实验"}.get(self.version_type, self.version_type)


def _headers() -> Dict[str, str]:
    return {"User-Agent": USER_AGENT, "Accept": "application/json"}


def _encode(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"))


def search(
    net: NetClient,
    query: str = "",
    mc: str = "",
    loader: str = "",
    limit: int = 20,
    offset: int = 0,
    sort: str = "relevance",
    cancel=None,
) -> List[ModHit]:
    facets: List[List[str]] = [["project_type:mod"]]
    if mc:
        facets.append([f"versions:{mc}"])
    if loader:
        facets.append([f"categories:{loader}"])
    params = {
        "query": query or "",
        "limit": max(1, min(50, limit)),
        "offset": max(0, offset),
        "index": sort,
        "facets": _encode(facets),
    }
    url = f"{BASE}/search?" + urllib.parse.urlencode(params)
    data = net.fetch_json(url, cancel=cancel)
    out: List[ModHit] = []
    for hit in (data or {}).get("hits", []):
        out.append(
            ModHit(
                project_id=hit.get("project_id") or "",
                slug=hit.get("slug") or "",
                title=hit.get("title") or "",
                description=(hit.get("description") or "").strip(),
                author=hit.get("author") or "",
                downloads=int(hit.get("downloads") or 0),
                icon_url=hit.get("icon_url") or "",
                categories=list(hit.get("categories") or []),
                versions=list(hit.get("versions") or []),
            )
        )
    return out


def project_versions(
    net: NetClient,
    project: str,
    mc: str = "",
    loader: str = "",
    cancel=None,
) -> List[ModFile]:
    params: Dict[str, str] = {}
    if mc:
        params["game_versions"] = _encode([mc])
    if loader:
        params["loaders"] = _encode([loader])
    url = f"{BASE}/project/{urllib.parse.quote(project)}/version"
    if params:
        url += "?" + urllib.parse.urlencode(params)
    data = net.fetch_json(url, cancel=cancel)
    out: List[ModFile] = []
    for item in data or []:
        files = item.get("files") or []
        if not files:
            continue
        primary = next((f for f in files if f.get("primary")), files[0])
        hashes = primary.get("hashes") or {}
        out.append(
            ModFile(
                project_id=item.get("project_id") or "",
                version_id=item.get("id") or "",
                name=item.get("name") or "",
                version_number=item.get("version_number") or "",
                filename=primary.get("filename") or "mod.jar",
                url=primary.get("url") or "",
                size=int(primary.get("size") or 0),
                sha1=(hashes.get("sha1") or "").lower(),
                sha512=(hashes.get("sha512") or "").lower(),
                loaders=list(item.get("loaders") or []),
                game_versions=list(item.get("game_versions") or []),
                version_type=item.get("version_type") or "release",
                dependencies=list(item.get("dependencies") or []),
                date=(item.get("date_published") or "")[:10],
            )
        )
    return out


def pick_file(versions: List[ModFile], mc: str = "", loader: str = "") -> Optional[ModFile]:
    """优先选正式版，其次匹配 MC 版本/加载器。"""
    if not versions:
        return None
    order = {"release": 0, "beta": 1, "alpha": 2}

    def score(v: ModFile) -> tuple:
        matches_mc = 0 if (not mc or mc in v.game_versions) else 1
        matches_loader = 0 if (not loader or loader in v.loaders) else 1
        return (matches_mc, matches_loader, order.get(v.version_type, 3))

    return sorted(versions, key=score)[0]


def download_file(
    net: NetClient,
    mod_file: ModFile,
    dest_dir: Path,
    progress: Optional[Progress] = None,
    cancel=None,
    log=None,
) -> Path:
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / mod_file.filename
    if progress is not None:
        progress.add_totals(1, mod_file.size or 0)
    net.download(
        mod_file.url,
        dest,
        size=mod_file.size or None,
        sha1=mod_file.sha1 or None,
        progress=progress,
        cancel=cancel,
        label=mod_file.filename,
    )
    if log:
        log(f"已保存 {mod_file.filename}（{mod_file.size_text}）", "ok")
    return dest


def required_dependencies(mod_file: ModFile) -> List[Dict[str, Any]]:
    return [d for d in (mod_file.dependencies or []) if d.get("dependency_type") == "required"]


def resolve_with_dependencies(
    net: NetClient,
    mod_file: ModFile,
    mc: str = "",
    loader: str = "",
    cancel=None,
    max_depth: int = 3,
    seen_projects: Optional[set] = None,
    depth: int = 0,
) -> List[ModFile]:
    """返回 [主文件] + 递归解析出的必需依赖（按项目去重）。"""
    seen_projects = seen_projects or set()
    result = [mod_file]
    seen_projects.add(mod_file.project_id)
    if depth >= max_depth:
        return result
    for dep in required_dependencies(mod_file):
        project = dep.get("project_id")
        if not project or project in seen_projects:
            continue
        try:
            versions = project_versions(net, project, mc, loader, cancel=cancel)
        except Exception:  # noqa: BLE001
            continue
        chosen = None
        dep_version = dep.get("version_id")
        if dep_version:
            chosen = next((v for v in versions if v.version_id == dep_version), None)
        chosen = chosen or pick_file(versions, mc, loader)
        if not chosen:
            continue
        result.extend(
            resolve_with_dependencies(
                net, chosen, mc, loader, cancel=cancel,
                max_depth=max_depth, seen_projects=seen_projects, depth=depth + 1,
            )
        )
    return result


def project_url(slug: str) -> str:
    return f"https://modrinth.com/mod/{slug}"
