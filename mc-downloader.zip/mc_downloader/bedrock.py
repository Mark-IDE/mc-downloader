"""安卓基岩版（Bedrock）APK 下载。

官方并未公开 APK 直链，因此这里做成「可插拔下载源」：
  archive —— Internet Archive 的 mcpe-apk 存档（覆盖 0.x 至今的历史版本）
  json    —— 自建 JSON 清单源（企业/个人镜像，格式见 README）
  direct  —— 直接粘贴 APK 链接下载

任何源都统一转换成 ApkVersion，主流程只认它。
"""

from __future__ import annotations

import json
import re
import time
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from .config import CACHE_DIR
from .net import Cancelled, DownloadError, NetClient, Progress, human_size

APK_MAGIC = b"PK\x03\x04"


@dataclass
class ApkVersion:
    version: str
    filename: str
    url: str
    size: int = 0
    sha1: str = ""
    channel: str = "release"
    source: str = ""
    note: str = ""

    @property
    def size_text(self) -> str:
        return human_size(self.size) if self.size else "未知"

    @property
    def sort_key(self):
        nums = re.findall(r"\d+", self.version)
        return tuple(int(n) for n in nums[:6]) + (1 if self.channel == "release" else 0,)


def _version_key(text: str):
    nums = [int(n) for n in re.findall(r"\d+", text or "")[:6]]
    return tuple(nums) + (0,) * (6 - len(nums))


def parse_version_from_name(name: str) -> str:
    """从文件名里尽量抠出版本号。"""
    base = urllib.parse.unquote(name)
    patterns = [
        r"MCPE[-_ ]?\((?P<v>[^)]+)\)",
        r"[Mm]inecraft[-_ ]?(?:bedrock|pe)?[-_ ]?v?(?P<v>\d+(?:\.\d+){1,3})",
        r"v?(?P<v>\d+\.\d+(?:\.\d+){0,3})",
    ]
    for pat in patterns:
        m = re.search(pat, base)
        if m:
            ver = m.group("v").strip()
            ver = re.sub(r"^(v|V)", "", ver)
            return ver
    return Path(base).stem


def guess_channel(name: str) -> str:
    low = (name or "").lower()
    if "preview" in low:
        return "preview"
    if "beta" in low or "b$" in low:
        return "beta"
    return "release"


class ApkSource:
    key = "base"
    label = "源"
    note = ""

    def available(self) -> bool:
        return True

    def list_versions(self, net: NetClient, cancel: Optional[Any] = None) -> List[ApkVersion]:
        raise NotImplementedError


class ArchiveOrgSource(ApkSource):
    """Internet Archive 上的 Minecraft PE/Bedrock APK 存档。"""

    key = "archive"
    label = "Internet Archive 存档"
    note = "需要能访问 archive.org；收录 0.x~最新正式/测试版"
    identifiers = ("mcpe-apk",)
    base_download = "https://archive.org/download/{ident}/{name}"

    def list_versions(self, net: NetClient, cancel: Optional[Any] = None) -> List[ApkVersion]:
        out: List[ApkVersion] = []
        errors: List[str] = []
        for ident in self.identifiers:
            cache = CACHE_DIR / f"apk_archive_{ident}.json"
            meta = None
            try:
                if cache.exists() and time.time() - cache.stat().st_mtime < 6 * 3600:
                    meta = json.loads(cache.read_text("utf-8"))
            except Exception:  # noqa: BLE001
                meta = None
            if meta is None:
                try:
                    meta = net.fetch_json(f"https://archive.org/metadata/{ident}", cancel=cancel)
                    try:
                        cache.parent.mkdir(parents=True, exist_ok=True)
                        cache.write_text(json.dumps(meta, ensure_ascii=False), "utf-8")
                    except OSError:
                        pass
                except Exception as exc:  # noqa: BLE001
                    errors.append(f"{ident}: {exc}")
                    continue
            files = (meta or {}).get("files") or []
            for f in files:
                name = f.get("name") or ""
                if not name.lower().endswith(".apk"):
                    continue
                try:
                    size = int(f.get("size") or 0)
                except (TypeError, ValueError):
                    size = 0
                if size and size < 500_000:
                    continue
                version = parse_version_from_name(name)
                if not re.match(r"^\d", version):
                    continue
                out.append(
                    ApkVersion(
                        version=version,
                        filename=name,
                        url=self.base_download.format(ident=ident, name=urllib.parse.quote(name)),
                        size=size,
                        sha1=(f.get("sha1") or "").lower(),
                        channel=guess_channel(name),
                        source=self.label,
                        note=ident,
                    )
                )
        out.sort(key=lambda a: a.sort_key, reverse=True)
        if not out and errors:
            raise DownloadError("存档源不可用：" + "；".join(errors))
        return out


class JsonIndexSource(ApkSource):
    """自建 JSON 清单。

    支持两种写法：
      1) [{"version":"1.21.0","url":"https://.../a.apk","size":123,"sha1":"..."}]
      2) {"name":"我的源","versions":[ ... 同上 ... ]}
    """

    key = "json"
    label = "自定义 JSON 清单"

    def __init__(self, url: str = "") -> None:
        self.url = (url or "").strip()
        self.note = "在设置里填写清单地址（JSON）"

    def available(self) -> bool:
        return bool(self.url)

    def list_versions(self, net: NetClient, cancel: Optional[Any] = None) -> List[ApkVersion]:
        if not self.url:
            raise DownloadError("还没有配置 JSON 清单地址（设置 → 安卓）")
        data = net.fetch_json(self.url, cancel=cancel)
        items: List[Dict[str, Any]]
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            items = data.get("versions") or data.get("items") or []
        else:
            items = []
        out: List[ApkVersion] = []
        for it in items:
            if not isinstance(it, dict):
                continue
            url = it.get("url") or it.get("download") or it.get("link") or ""
            if not url:
                continue
            name = it.get("filename") or Path(urllib.parse.urlsplit(url).path).name or "minecraft.apk"
            version = str(it.get("version") or it.get("id") or parse_version_from_name(name))
            out.append(
                ApkVersion(
                    version=version,
                    filename=name,
                    url=url,
                    size=int(it.get("size") or 0),
                    sha1=(it.get("sha1") or "").lower(),
                    channel=str(it.get("channel") or it.get("type") or "release"),
                    source=self.label,
                )
            )
        out.sort(key=lambda a: a.sort_key, reverse=True)
        return out


class DirectSource(ApkSource):
    """直接粘贴链接下载。"""

    key = "direct"
    label = "直接链接"
    note = "粘贴 APK 直链即可下载"

    def list_versions(self, net: NetClient, cancel: Optional[Any] = None) -> List[ApkVersion]:
        return []

    def from_url(self, url: str, size: int = 0, sha1: str = "") -> ApkVersion:
        url = (url or "").strip()
        if not url.lower().startswith(("http://", "https://")):
            raise DownloadError("链接必须以 http(s):// 开头")
        name = Path(urllib.parse.urlsplit(url).path).name or "minecraft.apk"
        return ApkVersion(
            version=parse_version_from_name(name),
            filename=name,
            url=url,
            size=size,
            sha1=sha1,
            source=self.label,
        )


def make_apk_source(cfg) -> ApkSource:
    key = cfg.get("apk_source", "archive")
    if key == "json":
        return JsonIndexSource(cfg.get("apk_index_url") or "")
    if key == "direct":
        return DirectSource()
    return ArchiveOrgSource()


def download_apk(
    net: NetClient,
    apk: ApkVersion,
    dest_dir: Path,
    progress: Optional[Progress] = None,
    cancel: Optional[Any] = None,
    log=print,
) -> Path:
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[\\/:*?\"<>|]+", "_", apk.filename) or f"minecraft-{apk.version}.apk"
    dest = dest_dir / safe
    if progress is not None:
        progress.reset()
        progress.add_totals(1, apk.size or 0)
    log(f"开始下载 {apk.filename}（{apk.size_text}）", "info")
    net.download(
        apk.url,
        dest,
        size=apk.size or None,
        sha1=apk.sha1 or None,
        progress=progress,
        cancel=cancel,
        label=apk.filename,
    )
    # 简单校验是不是真的 APK
    try:
        with open(dest, "rb") as fh:
            head = fh.read(4)
        if head != APK_MAGIC:
            log("警告：下载到的文件不是标准 APK（可能是一个网页或压缩包），请检查链接。", "warn")
    except OSError:
        pass
    log(f"已保存：{dest}", "ok")
    return dest
