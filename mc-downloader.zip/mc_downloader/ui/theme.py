"""界面主题：颜色、字体、圆角控件。"""

from __future__ import annotations

import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk
from typing import Callable, Optional

# ------------------------------------------------------------------ 调色板
BG = "#F2F4F8"
CARD = "#FFFFFF"
CARD_ALT = "#FAFBFD"
SIDEBAR = "#FFFFFF"
ACCENT = "#2B7BE4"
ACCENT_DARK = "#1F63C4"
ACCENT_LIGHT = "#E9F1FD"
TEXT = "#1E2430"
TEXT_SOFT = "#4A5468"
MUTED = "#8891A4"
BORDER = "#E4E8EF"
BORDER_STRONG = "#D3DAE5"
OK = "#1E9E6A"
WARN = "#D98A16"
ERR = "#D93B41"
HEADER_BG = "#FFFFFF"
TRACK = "#E9EDF3"

FONT_FAMILY = "Microsoft YaHei UI"
FONT_FALLBACKS = ("Microsoft YaHei UI", "Microsoft YaHei", "微软雅黑", "Segoe UI", "Arial")

LOG_COLORS = {
    "info": TEXT_SOFT,
    "ok": OK,
    "warn": WARN,
    "error": ERR,
    "debug": MUTED,
    "title": TEXT,
}


def pick_font_family(root: tk.Misc) -> str:
    try:
        available = set(tkfont.families(root))
    except Exception:  # noqa: BLE001
        return "TkDefaultFont"
    for name in FONT_FALLBACKS:
        if name in available:
            return name
    return "TkDefaultFont"


class Fonts:
    def __init__(self, root: tk.Misc) -> None:
        family = pick_font_family(root)
        self.family = family
        self.h1 = (family, 17, "bold")
        self.h2 = (family, 13, "bold")
        self.h3 = (family, 11, "bold")
        self.body = (family, 10)
        self.small = (family, 9)
        self.tiny = (family, 8)
        self.mono = ("Consolas", 9)
        self.button = (family, 10, "bold")
        self.nav = (family, 11)


# ------------------------------------------------------------------ 样式
def setup_style(root: tk.Misc, fonts: Fonts) -> ttk.Style:
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    style.configure(".", background=CARD, foreground=TEXT, font=fonts.body, borderwidth=0)
    style.configure("TFrame", background=CARD)
    style.configure("Bg.TFrame", background=BG)
    style.configure("TLabel", background=CARD, foreground=TEXT, font=fonts.body)
    style.configure("Bg.TLabel", background=BG, foreground=TEXT)
    style.configure("Muted.TLabel", background=CARD, foreground=MUTED, font=fonts.small)
    style.configure("MutedBg.TLabel", background=BG, foreground=MUTED, font=fonts.small)
    style.configure("H2.TLabel", background=CARD, foreground=TEXT, font=fonts.h2)
    style.configure("H3.TLabel", background=CARD, foreground=TEXT, font=fonts.h3)

    # 输入框
    style.configure(
        "TEntry",
        fieldbackground=CARD_ALT,
        background=CARD_ALT,
        foreground=TEXT,
        bordercolor=BORDER_STRONG,
        lightcolor=BORDER,
        darkcolor=BORDER,
        insertcolor=TEXT,
        padding=6,
    )
    style.map("TEntry", bordercolor=[("focus", ACCENT)], lightcolor=[("focus", ACCENT)])
    style.configure("TSpinbox", fieldbackground=CARD_ALT, foreground=TEXT, bordercolor=BORDER_STRONG, arrowsize=12, padding=4)
    style.map("TSpinbox", bordercolor=[("focus", ACCENT)])

    # 下拉框
    style.configure(
        "TCombobox",
        fieldbackground=CARD_ALT,
        background=CARD_ALT,
        foreground=TEXT,
        bordercolor=BORDER_STRONG,
        lightcolor=BORDER,
        darkcolor=BORDER,
        arrowcolor=TEXT_SOFT,
        padding=5,
    )
    style.map(
        "TCombobox",
        fieldbackground=[("readonly", CARD_ALT)],
        bordercolor=[("focus", ACCENT)],
        selectbackground=[("readonly", CARD_ALT)],
        selectforeground=[("readonly", TEXT)],
    )

    # 复选框
    style.configure("TCheckbutton", background=CARD, foreground=TEXT, font=fonts.body, focuscolor=CARD)
    style.map(
        "TCheckbutton",
        background=[("active", CARD)],
        indicatorcolor=[("selected", ACCENT), ("!selected", CARD)],
    )

    # 表格
    style.configure(
        "Treeview",
        background=CARD,
        fieldbackground=CARD,
        foreground=TEXT,
        rowheight=28,
        font=fonts.body,
        borderwidth=0,
    )
    style.configure(
        "Treeview.Heading",
        background=CARD_ALT,
        foreground=TEXT_SOFT,
        font=fonts.small,
        relief="flat",
        padding=(8, 6),
    )
    style.map("Treeview.Heading", background=[("active", ACCENT_LIGHT)])
    style.map("Treeview", background=[("selected", ACCENT_LIGHT)], foreground=[("selected", TEXT)])
    style.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])

    # 进度条
    style.configure(
        "Accent.Horizontal.TProgressbar",
        troughcolor=TRACK,
        background=ACCENT,
        bordercolor=TRACK,
        lightcolor=ACCENT,
        darkcolor=ACCENT,
        thickness=8,
    )

    # 滚动条
    style.configure(
        "Vertical.TScrollbar",
        background=CARD_ALT,
        troughcolor=CARD,
        bordercolor=CARD,
        arrowcolor=MUTED,
        gripcount=0,
        arrowsize=10,
    )
    style.map("Vertical.TScrollbar", background=[("active", BORDER_STRONG)])

    # Notebook
    style.configure("TNotebook", background=BG, borderwidth=0, tabmargins=(0, 4, 0, 0))
    style.configure(
        "TNotebook.Tab",
        background=BG,
        foreground=TEXT_SOFT,
        padding=(18, 8),
        font=fonts.body,
        borderwidth=0,
    )
    style.map(
        "TNotebook.Tab",
        background=[("selected", CARD)],
        foreground=[("selected", ACCENT)],
        expand=[("selected", (0, 0, 0, 0))],
    )
    return style


# ------------------------------------------------------------------ 基础控件
def round_rect(canvas: tk.Canvas, x1: float, y1: float, x2: float, y2: float, r: float, **kwargs):
    """在 Canvas 上画圆角矩形（用平滑多边形近似）。"""
    r = min(r, (x2 - x1) / 2, (y2 - y1) / 2)
    points = [
        x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
        x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
        x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
    ]
    return canvas.create_polygon(points, smooth=True, splinesteps=24, **kwargs)


class Card(tk.Frame):
    """白底、细边框的卡片容器。"""

    def __init__(self, master: tk.Misc, padding: int = 14, bg: str = CARD, **kwargs):
        super().__init__(master, bg=bg, highlightbackground=BORDER, highlightcolor=BORDER,
                         highlightthickness=1, bd=0, **kwargs)
        self._padding = padding
        self.inner = tk.Frame(self, bg=bg)
        self.inner.pack(fill="both", expand=True, padx=padding, pady=padding)


class RoundedButton(tk.Canvas):
    """圆角按钮，支持主按钮/次要/危险三种配色与禁用态。"""

    KINDS = {
        "primary": (ACCENT, "#FFFFFF", ACCENT_DARK),
        "ghost": (CARD_ALT, TEXT, ACCENT_LIGHT),
        "danger": (ERR, "#FFFFFF", "#B32B30"),
        "soft": (ACCENT_LIGHT, ACCENT_DARK, "#D7E7FC"),
    }

    def __init__(
        self,
        master: tk.Misc,
        text: str,
        command: Optional[Callable[[], None]] = None,
        width: int = 200,
        height: int = 38,
        radius: int = 9,
        kind: str = "primary",
        font=None,
        parent_bg: Optional[str] = None,
    ) -> None:
        super().__init__(
            master,
            width=width,
            height=height,
            bg=parent_bg or master.cget("bg"),
            highlightthickness=0,
            bd=0,
            cursor="hand2",
        )
        self._text = text
        self._command = command
        self._radius = radius
        self._kind = kind
        self._font = font
        self._enabled = True
        self._hover = False
        self.bind("<Configure>", lambda e: self._render())
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._on_click)
        self._render()

    # --- 状态 -------------------------------------------------------
    def set_text(self, text: str) -> None:
        self._text = text
        self._render()

    def set_enabled(self, enabled: bool) -> None:
        self._enabled = bool(enabled)
        self.configure(cursor="hand2" if enabled else "arrow")
        self._render()

    # --- 事件 -------------------------------------------------------
    def _on_enter(self, _event=None) -> None:
        if self._enabled:
            self._hover = True
            self._render()

    def _on_leave(self, _event=None) -> None:
        self._hover = False
        self._render()

    def _on_click(self, _event=None) -> None:
        if self._enabled and self._command:
            self._command()

    # --- 绘制 -------------------------------------------------------
    def _render(self) -> None:
        self.delete("all")
        w = max(int(self.winfo_width()), int(self.cget("width")))
        h = max(int(self.winfo_height()), int(self.cget("height")))
        base, fg, hover = self.KINDS.get(self._kind, self.KINDS["primary"])
        fill = hover if self._hover and self._enabled else base
        if not self._enabled:
            fill = "#C9D2DF"
            fg = "#FFFFFF"
        round_rect(self, 1, 1, w - 1, h - 1, self._radius, fill=fill, outline="")
        self.create_text(
            w / 2,
            h / 2,
            text=self._text,
            fill=fg,
            font=self._font or ("Microsoft YaHei UI", 10, "bold"),
        )


class CheckBox(tk.Frame):
    """自绘复选框：圆角方块 + 对勾，避免 ttk 主题在 Windows 上的黑叉。"""

    def __init__(self, master: tk.Misc, text: str, variable: tk.Variable,
                 command: Optional[Callable[[], None]] = None, bg: str = CARD,
                 fg: str = TEXT, font=None):
        super().__init__(master, bg=bg, cursor="hand2")
        self.var = variable
        self.command = command
        self._bg = bg
        self._canvas = tk.Canvas(self, width=18, height=18, bg=bg, highlightthickness=0, bd=0)
        self._canvas.pack(side="left")
        self._label = tk.Label(self, text=text, bg=bg, fg=fg, font=font, cursor="hand2")
        self._label.pack(side="left", padx=(7, 0))
        for widget in (self, self._canvas, self._label):
            widget.bind("<Button-1>", self._toggle)
            widget.bind("<Enter>", self._on_enter)
            widget.bind("<Leave>", self._on_leave)
        try:
            self.var.trace_add("write", lambda *_: self._render())
        except Exception:  # noqa: BLE001
            pass
        self._render()

    def _toggle(self, _event=None) -> None:
        try:
            self.var.set(not bool(self.var.get()))
        except Exception:  # noqa: BLE001
            return
        if self.command:
            self.command()
        self._render()

    def _on_enter(self, _event=None) -> None:
        self._canvas.configure(bg=self._bg)

    def _on_leave(self, _event=None) -> None:
        self._canvas.configure(bg=self._bg)

    def _render(self) -> None:
        c = self._canvas
        c.delete("all")
        on = bool(self.var.get())
        fill = ACCENT if on else CARD_ALT
        outline = ACCENT if on else BORDER_STRONG
        round_rect(c, 1.5, 1.5, 16.5, 16.5, 4, fill=fill, outline=outline, width=1.2)
        if on:
            c.create_line(5.2, 9.4, 8.2, 12.3, 13.2, 5.8, fill="#FFFFFF", width=2,
                          capstyle="round", joinstyle="round")


class NavButton(tk.Frame):
    """左侧导航项：图标位 + 文字 + 选中高亮条。"""

    def __init__(self, master: tk.Misc, text: str, command: Callable[[], None], glyph: str = "•"):
        super().__init__(master, bg=SIDEBAR, cursor="hand2")
        self._command = command
        self._active = False
        self._hover = False

        self.bar = tk.Frame(self, bg=SIDEBAR, width=3)
        self.bar.pack(side="left", fill="y")

        self.icon = tk.Label(self, text=glyph, bg=SIDEBAR, fg=MUTED, font=("Segoe UI Symbol", 12), width=3)
        self.icon.pack(side="left", pady=9)

        self.label = tk.Label(self, text=text, bg=SIDEBAR, fg=TEXT_SOFT, font=("Microsoft YaHei UI", 10),
                              anchor="w")
        self.label.pack(side="left", fill="x", expand=True, pady=9)

        for widget in (self, self.icon, self.label, self.bar):
            widget.bind("<Button-1>", self._on_click)
            widget.bind("<Enter>", self._on_enter)
            widget.bind("<Leave>", self._on_leave)

    def _on_click(self, _event=None) -> None:
        self._command()

    def _on_enter(self, _event=None) -> None:
        self._hover = True
        self._paint()

    def _on_leave(self, _event=None) -> None:
        self._hover = False
        self._paint()

    def set_active(self, active: bool) -> None:
        self._active = active
        self._paint()

    def _paint(self) -> None:
        if self._active:
            bg, fg, bar = ACCENT_LIGHT, ACCENT_DARK, ACCENT
        elif self._hover:
            bg, fg, bar = "#F5F8FD", TEXT, SIDEBAR
        else:
            bg, fg, bar = SIDEBAR, TEXT_SOFT, SIDEBAR
        for widget in (self, self.icon, self.label):
            widget.configure(bg=bg)
        self.icon.configure(fg=fg if self._active else MUTED)
        self.label.configure(fg=fg, font=("Microsoft YaHei UI", 10, "bold" if self._active else "normal"))
        self.bar.configure(bg=bar)


class Tooltip:
    """轻量提示气泡。"""

    def __init__(self, widget: tk.Misc, text: str, delay: int = 450):
        self.widget = widget
        self.text = text
        self.delay = delay
        self._after_id = None
        self._tip: Optional[tk.Toplevel] = None
        widget.bind("<Enter>", self._schedule, add="+")
        widget.bind("<Leave>", self._hide, add="+")
        widget.bind("<ButtonPress>", self._hide, add="+")

    def _schedule(self, _event=None) -> None:
        self._after_id = self.widget.after(self.delay, self._show)

    def _show(self) -> None:
        if self._tip or not self.text:
            return
        try:
            x = self.widget.winfo_rootx() + 12
            y = self.widget.winfo_rooty() + self.widget.winfo_height() + 6
        except tk.TclError:
            return
        tip = tk.Toplevel(self.widget)
        tip.wm_overrideredirect(True)
        tip.wm_geometry(f"+{x}+{y}")
        tk.Label(tip, text=self.text, bg="#2A3140", fg="#FFFFFF", font=("Microsoft YaHei UI", 9),
                 padx=10, pady=6, justify="left").pack()
        self._tip = tip

    def _hide(self, _event=None) -> None:
        if self._after_id:
            try:
                self.widget.after_cancel(self._after_id)
            except tk.TclError:
                pass
            self._after_id = None
        if self._tip:
            self._tip.destroy()
            self._tip = None
