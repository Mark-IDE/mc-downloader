"""主窗口：顶栏 + 侧边导航 + 页面容器 + 下载状态面板。"""

from __future__ import annotations

import os
import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Any, Callable, Dict, List, Optional

from .. import __version__
from ..config import Config, ICON_PATH, LOG_DIR
from ..net import Cancelled, NetClient, Progress, fmt_eta, human_size, human_speed
from . import theme
from .theme import Card, Fonts, NavButton, RoundedButton, Tooltip, setup_style

NAV_ITEMS = [
    ("java", "PC · Java 版", "🖥"),
    ("mods", "模组 · Mod", "🧩"),
    ("android", "安卓 · 基岩版", "📱"),
    ("launcher", "安卓 · 启动器", "🚀"),
    ("settings", "设置", "⚙"),
    ("about", "关于", "ℹ"),
]


class Page(tk.Frame):
    name = "page"
    title = "页面"

    def __init__(self, app: "App") -> None:
        super().__init__(app.page_host, bg=theme.BG)
        self.app = app
        self.cfg = app.cfg
        self.build()

    def build(self) -> None:  # pragma: no cover - 由子类实现
        pass

    def on_show(self) -> None:
        pass

    def on_busy(self, busy: bool) -> None:
        pass

    def on_cancel(self) -> None:
        pass


class DownloadDock(tk.Frame):
    """底部：状态、进度、日志。"""

    def __init__(self, master: tk.Misc, app: "App") -> None:
        super().__init__(master, bg=theme.CARD, highlightbackground=theme.BORDER,
                         highlightcolor=theme.BORDER, highlightthickness=1, bd=0)
        self.app = app
        self.fonts = app.fonts
        self._log_visible = bool(app.cfg.get("log_visible"))
        self._build()

    # ------------------------------------------------------------ 构建
    def _build(self) -> None:
        wrap = tk.Frame(self, bg=theme.CARD)
        wrap.pack(fill="both", expand=True, padx=14, pady=10)

        top = tk.Frame(wrap, bg=theme.CARD)
        top.pack(fill="x")

        self.status_label = tk.Label(top, text="就绪", bg=theme.CARD, fg=theme.TEXT,
                                     font=self.fonts.h3, anchor="w")
        self.status_label.pack(side="left")

        self.detail_label = tk.Label(top, text="", bg=theme.CARD, fg=theme.MUTED,
                                     font=self.fonts.small, anchor="w")
        self.detail_label.pack(side="left", padx=(10, 0))

        self.log_toggle = RoundedButton(top, "日志 ▾", command=self.toggle_log, width=76, height=26,
                                        radius=7, kind="ghost", font=self.fonts.small,
                                        parent_bg=theme.CARD)
        self.log_toggle.pack(side="right")

        self.cancel_btn = RoundedButton(top, "取消", command=self.app.cancel_job, width=64, height=26,
                                        radius=7, kind="danger", font=self.fonts.small,
                                        parent_bg=theme.CARD)
        self.cancel_btn.pack(side="right", padx=(6, 6))
        self.cancel_btn.set_enabled(False)

        self.open_btn = RoundedButton(top, "打开目录", command=self._open_dir, width=86, height=26,
                                      radius=7, kind="ghost", font=self.fonts.small,
                                      parent_bg=theme.CARD)
        self.open_btn.pack(side="right", padx=(0, 6))

        bar_row = tk.Frame(wrap, bg=theme.CARD)
        bar_row.pack(fill="x", pady=(8, 0))
        self.bar = ttk.Progressbar(bar_row, style="Accent.Horizontal.TProgressbar",
                                   orient="horizontal", mode="determinate", maximum=1000)
        self.bar.pack(fill="x")

        info = tk.Frame(wrap, bg=theme.CARD)
        info.pack(fill="x", pady=(4, 0))
        self.percent_label = tk.Label(info, text="0.0%", bg=theme.CARD, fg=theme.ACCENT_DARK,
                                      font=self.fonts.small, anchor="w")
        self.percent_label.pack(side="left")
        self.size_label = tk.Label(info, text="", bg=theme.CARD, fg=theme.MUTED,
                                   font=self.fonts.small, anchor="w")
        self.size_label.pack(side="left", padx=(12, 0))
        self.speed_label = tk.Label(info, text="", bg=theme.CARD, fg=theme.MUTED,
                                    font=self.fonts.small, anchor="e")
        self.speed_label.pack(side="right")

        self.log_frame = tk.Frame(wrap, bg=theme.CARD)
        self.log_text = tk.Text(self.log_frame, height=5, bg="#FAFBFD", fg=theme.TEXT_SOFT,
                                font=self.fonts.mono, relief="flat", wrap="word",
                                highlightbackground=theme.BORDER, highlightthickness=1,
                                padx=8, pady=6, state="disabled")
        scroll = ttk.Scrollbar(self.log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scroll.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        for level, color in theme.LOG_COLORS.items():
            self.log_text.tag_configure(level, foreground=color)
        self.log_text.tag_configure("ok", foreground=theme.OK)
        self.log_text.tag_configure("time", foreground=theme.MUTED)

        self._last_dir = Path.home()
        self._apply_log_visibility(self._log_visible, initial=True)

    # ------------------------------------------------------------ 行为
    def _open_dir(self) -> None:
        target = self.app.current_download_dir()
        try:
            target.mkdir(parents=True, exist_ok=True)
            os.startfile(str(target))  # type: ignore[attr-defined]
        except Exception as exc:  # noqa: BLE001
            messagebox.showwarning("打开失败", f"无法打开目录：{exc}")

    def toggle_log(self) -> None:
        self._apply_log_visibility(not self._log_visible)

    def _apply_log_visibility(self, visible: bool, initial: bool = False) -> None:
        self._log_visible = visible
        if visible:
            self.log_frame.pack(fill="both", expand=True, pady=(8, 0))
            self.log_toggle.set_text("日志 ▴")
        else:
            self.log_frame.pack_forget()
            self.log_toggle.set_text("日志 ▾")
        if not initial:
            self.app.cfg["log_visible"] = visible
            self.app.cfg.save()

    def append_log(self, text: str, level: str = "info") -> None:
        self.log_text.configure(state="normal")
        self.log_text.insert("end", text + "\n", (level,))
        # 限制行数，避免长时间运行内存膨胀
        lines = int(self.log_text.index("end-1c").split(".")[0])
        if lines > 3000:
            self.log_text.delete("1.0", f"{lines - 2500}.0")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def set_status(self, text: str, kind: str = "info") -> None:
        color = {"info": theme.TEXT, "ok": theme.OK, "warn": theme.WARN, "error": theme.ERR}.get(kind, theme.TEXT)
        self.status_label.configure(text=text, fg=color)

    def set_detail(self, text: str) -> None:
        self.detail_label.configure(text=text)

    def set_busy(self, busy: bool) -> None:
        self.cancel_btn.set_enabled(busy)
        if not busy:
            self.bar.configure(value=0)

    def update_progress(self, snap: Dict[str, Any]) -> None:
        self.bar.configure(value=int(snap["percent"] * 10))
        self.percent_label.configure(text=f"{snap['percent']:.1f}%")
        self.size_label.configure(
            text=f"{human_size(snap['done_bytes'])} / {human_size(snap['total_bytes'])}"
            f"    文件 {snap['done_files']}/{snap['total_files']}"
        )
        eta = fmt_eta(snap.get("eta"))
        self.speed_label.configure(text=f"{human_speed(snap['speed'])}    剩余 {eta}")

    def clear(self) -> None:
        self.bar.configure(value=0)
        self.percent_label.configure(text="0.0%")
        self.size_label.configure(text="")
        self.speed_label.configure(text="")


class App(tk.Tk):
    def __init__(self, cfg: Config) -> None:
        super().__init__()
        self.cfg = cfg
        self.fonts = Fonts(self)
        self.style = setup_style(self, self.fonts)

        self.title("MC 下载器 · Minecraft Java / 基岩版")
        self.geometry(str(cfg.get("window_size") or "1200x820"))
        self.minsize(1024, 700)
        self.configure(bg=theme.BG)
        self._set_icon()

        self.queue: "queue.Queue[tuple]" = queue.Queue()
        self.jobs_in_flight = 0
        self.cancel_event: Optional[threading.Event] = None
        self.progress: Optional[Progress] = None
        self.busy = False
        self._pages: Dict[str, Page] = {}
        self._current_page: Optional[Page] = None

        self._build_header()
        self._build_body()
        self._build_pages()
        self._select_page("java")

        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(80, self._pump)
        self.after(200, self._tick)

        start_page = os.environ.get("MCDL_START_PAGE")
        if start_page in self._pages:
            self.after(500, lambda: self._select_page(start_page))

        # 截图/演示用：MCDL_TOPMOST=1 时把窗口顶到最前
        if os.environ.get("MCDL_TOPMOST"):
            try:
                self.attributes("-topmost", True)
                self.lift()
                self.focus_force()
            except tk.TclError:
                pass

    # ------------------------------------------------------------ 窗口结构
    def _set_icon(self) -> None:
        try:
            if ICON_PATH.exists():
                self._icon = tk.PhotoImage(file=str(ICON_PATH))
                self.iconphoto(True, self._icon)
        except Exception:  # noqa: BLE001
            pass

    def _build_header(self) -> None:
        header = tk.Frame(self, bg=theme.HEADER_BG, height=62)
        header.pack(fill="x", side="top")
        header.pack_propagate(False)
        tk.Frame(self, bg=theme.BORDER, height=1).pack(fill="x")

        left = tk.Frame(header, bg=theme.HEADER_BG)
        left.pack(side="left", padx=18)

        logo = tk.Canvas(left, width=30, height=30, bg=theme.HEADER_BG, highlightthickness=0)
        logo.pack(side="left", pady=16)
        theme.round_rect(logo, 2, 2, 28, 28, 7, fill=theme.ACCENT, outline="")
        logo.create_text(15, 16, text="MC", fill="#FFFFFF", font=("Microsoft YaHei UI", 9, "bold"))

        titles = tk.Frame(left, bg=theme.HEADER_BG)
        titles.pack(side="left", padx=(10, 0), pady=12)
        tk.Label(titles, text="MC 下载器", bg=theme.HEADER_BG, fg=theme.TEXT,
                 font=self.fonts.h2, anchor="w").pack(anchor="w")
        tk.Label(titles, text="Minecraft 各版本下载 · 参考 PCL 启动器", bg=theme.HEADER_BG,
                 fg=theme.MUTED, font=self.fonts.small, anchor="w").pack(anchor="w")

    def _build_body(self) -> None:
        body = tk.Frame(self, bg=theme.BG)
        body.pack(fill="both", expand=True)

        self.sidebar = tk.Frame(body, bg=theme.SIDEBAR, width=188)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)
        tk.Frame(body, bg=theme.BORDER, width=1).pack(side="left", fill="y")

        nav = tk.Frame(self.sidebar, bg=theme.SIDEBAR)
        nav.pack(fill="x", pady=(14, 0))
        self.nav_buttons: Dict[str, NavButton] = {}
        for key, label, glyph in NAV_ITEMS:
            btn = NavButton(nav, label, command=lambda k=key: self._select_page(k), glyph=glyph)
            btn.pack(fill="x", pady=1)
            self.nav_buttons[key] = btn

        footer = tk.Frame(self.sidebar, bg=theme.SIDEBAR)
        footer.pack(side="bottom", fill="x", pady=12, padx=14)
        self.source_hint = tk.Label(footer, text="", bg=theme.SIDEBAR, fg=theme.MUTED,
                                    font=self.fonts.tiny, anchor="w", justify="left")
        self.source_hint.pack(anchor="w")
        tk.Label(footer, text=f"v{__version__} · 仅供学习交流", bg=theme.SIDEBAR, fg=theme.MUTED,
                 font=self.fonts.tiny, anchor="w").pack(anchor="w", pady=(4, 0))

        self.content = tk.Frame(body, bg=theme.BG)
        self.content.pack(side="left", fill="both", expand=True)

        self.content.grid_rowconfigure(0, weight=1)
        self.content.grid_columnconfigure(0, weight=1)

        self.page_host = tk.Frame(self.content, bg=theme.BG)
        self.page_host.grid(row=0, column=0, sticky="nsew", padx=12, pady=(12, 6))
        self.page_host.rowconfigure(0, weight=1)
        self.page_host.columnconfigure(0, weight=1)

        self.dock = DownloadDock(self.content, self)
        self.dock.grid(row=1, column=0, sticky="ew", padx=12, pady=(0, 12))
        self.update_source_hint()

    def _build_pages(self) -> None:
        from .page_about import AboutPage
        from .page_android import AndroidPage, LauncherPage
        from .page_java import JavaPage
        from .page_mods import ModsPage
        from .page_settings import SettingsPage

        for cls in (JavaPage, ModsPage, AndroidPage, LauncherPage, SettingsPage, AboutPage):
            page = cls(self)
            page.grid(row=0, column=0, sticky="nsew")
            self._pages[page.name] = page

    def _select_page(self, key: str) -> None:
        page = self._pages.get(key)
        if page is None:
            return
        if self._current_page is page:
            return
        for btn_key, btn in self.nav_buttons.items():
            btn.set_active(btn_key == key)
        page.tkraise()
        self._current_page = page
        if getattr(page, "show_dock", True):
            self.dock.grid()
        else:
            self.dock.grid_remove()
        try:
            page.on_show()
        except Exception as exc:  # noqa: BLE001
            self.log(f"页面加载出错：{exc}", "error")

    # ------------------------------------------------------------ 下载任务
    def start_job(self, title: str, worker: Callable[[Progress, threading.Event], Any]) -> None:
        if self.busy:
            messagebox.showinfo("正在下载", "当前已有下载任务，请先完成或取消。")
            return
        self.busy = True
        self.dock.clear()
        self.dock.set_busy(True)
        self.dock.set_status(title, "info")
        self.cancel_event = threading.Event()
        self.progress = Progress()

        page = self._current_page
        if page is not None:
            page.on_busy(True)

        def _target() -> None:
            try:
                result = worker(self.progress, self.cancel_event)
                self.queue.put(("done", True, result))
            except Cancelled:
                self.queue.put(("done", False, "已取消下载"))
            except Exception as exc:  # noqa: BLE001
                self.queue.put(("done", False, str(exc)))

        threading.Thread(target=_target, name="job", daemon=True).start()

    def cancel_job(self) -> None:
        if self.cancel_event is not None and not self.cancel_event.is_set():
            self.cancel_event.set()
            self.dock.set_status("正在取消…", "warn")
            self.log("用户取消下载", "warn")
            if self._current_page is not None:
                self._current_page.on_cancel()

    def _finish_job(self, ok: bool, message: Any) -> None:
        self.busy = False
        self.dock.set_busy(False)
        page = self._current_page
        if page is not None:
            page.on_busy(False)
        if ok:
            self.dock.set_status("完成", "ok")
            snap = self.progress.snapshot() if self.progress else None
            if snap:
                self.dock.update_progress({**snap, "percent": 100.0})
            if isinstance(message, dict) and message.get("dir"):
                self.dock.set_detail(f"输出：{message['dir']}")
            self.dock.speed_label.configure(text="")
            self.log("任务完成", "ok")
        else:
            self.dock.set_status(str(message) or "失败", "error")
            self.log(f"任务结束：{message}", "error")

    # ------------------------------------------------------------ 日志与循环
    def log(self, text: str, level: str = "info") -> None:
        self.queue.put(("log", text, level))

    def set_status(self, text: str, kind: str = "info") -> None:
        self.queue.put(("status", text, kind))

    def ui_call(self, fn: Callable[[], None]) -> None:
        """让后台线程安全地在界面线程里执行一段代码。"""
        self.queue.put(("page", fn))

    def make_net(self) -> "NetClient":
        from ..net import NetClient

        return NetClient(
            threads=int(self.cfg.get("threads") or 16),
            retries=int(self.cfg.get("retries") or 3),
            timeout=int(self.cfg.get("timeout") or 20),
            verify_sha1=bool(self.cfg.get("verify_sha1")),
            allow_insecure_tls=bool(self.cfg.get("allow_insecure_tls")),
            proxy="",
            log=self.log,
        )

    def log_to_file(self, text: str) -> None:
        try:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            path = LOG_DIR / f"mcdl-{__import__('time').strftime('%Y%m%d')}.log"
            with open(path, "a", encoding="utf-8") as fh:
                fh.write(text + "\n")
        except OSError:
            pass

    def _pump(self) -> None:
        try:
            while True:
                kind, *rest = self.queue.get_nowait()
                if kind == "log":
                    text, level = rest
                    stamp = __import__("time").strftime("%H:%M:%S")
                    self.dock.append_log(f"[{stamp}] {text}", level)
                    self.log_to_file(f"[{stamp}] [{level}] {text}")
                elif kind == "status":
                    self.dock.set_status(rest[0], rest[1])
                elif kind == "detail":
                    self.dock.set_detail(rest[0])
                elif kind == "page":
                    rest[0]()
                elif kind == "done":
                    self._finish_job(rest[0], rest[1])
        except queue.Empty:
            pass
        self.after(80, self._pump)

    def _tick(self) -> None:
        if self.busy and self.progress is not None:
            snap = self.progress.snapshot()
            self.dock.update_progress(snap)
            if snap.get("current"):
                self.dock.set_detail(shorten(snap["current"], 64))
        self.after(200, self._tick)

    # ------------------------------------------------------------ 辅助
    def current_download_dir(self) -> Path:
        page = self._current_page
        if page is not None and hasattr(page, "download_dir"):
            try:
                return Path(page.download_dir())
            except Exception:  # noqa: BLE001
                pass
        return Path(self.cfg.get("java_dir"))

    def update_source_hint(self) -> None:
        labels = {"auto": "自动（镜像优先）", "official": "官方源", "bmcl": "Bang Bang 镜像", "custom": "自定义镜像"}
        text = labels.get(self.cfg.get("source"), "自动")
        self.source_hint.configure(text=f"下载源：{text}\n线程：{self.cfg.get('threads')}")

    def _on_close(self) -> None:
        if self.busy:
            if not messagebox.askyesno("退出", "仍有下载任务在进行，确定退出吗？"):
                return
            if self.cancel_event is not None:
                self.cancel_event.set()
        try:
            self.cfg["window_size"] = f"{self.winfo_width()}x{self.winfo_height()}"
            self.cfg.save()
        except Exception:  # noqa: BLE001
            pass
        self.destroy()


def shorten(text: str, limit: int = 60) -> str:
    text = str(text)
    return text if len(text) <= limit else "…" + text[-(limit - 1):]
