"""模组页面：加载器安装 / Mod 市场（Modrinth）/ 已装 Mod 管理。"""

from __future__ import annotations

import threading
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Any, Dict, List, Optional

from .. import javadl, modloaders, modrinth, mods
from ..net import human_size
from . import theme
from .app import Page
from .theme import Card, CheckBox, RoundedButton, Tooltip


def _label(parent: tk.Misc, text: str, **kw) -> tk.Label:
    return tk.Label(parent, text=text, bg=kw.pop("bg", theme.CARD), fg=kw.pop("fg", theme.TEXT_SOFT),
                    font=kw.pop("font", None), anchor="w", **kw)


class ModsPage(Page):
    name = "mods"
    show_dock = True

    # ------------------------------------------------------------ 构建
    def build(self) -> None:
        self._manifest: Optional[Dict[str, Any]] = None
        self._mc_versions: List[str] = []
        self._loader_rows: List[Any] = []
        self._hits: List[modrinth.ModHit] = []
        self._files: List[modrinth.ModFile] = []
        self._entries: List[mods.ModEntry] = []

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True)
        self.tab_loader = tk.Frame(self.notebook, bg=theme.BG)
        self.tab_market = tk.Frame(self.notebook, bg=theme.BG)
        self.tab_manage = tk.Frame(self.notebook, bg=theme.BG)
        self.notebook.add(self.tab_loader, text="  加载器安装  ")
        self.notebook.add(self.tab_market, text="  Mod 市场  ")
        self.notebook.add(self.tab_manage, text="  已装 Mod  ")

        self._build_loader_tab()
        self._build_market_tab()
        self._build_manage_tab()

    # ------------------------------------------------------------ 加载器
    def _build_loader_tab(self) -> None:
        fonts = self.app.fonts
        tab = self.tab_loader

        card = Card(tab, padding=14)
        card.pack(fill="x", pady=(8, 0))
        row = card.inner
        _label(row, "原版版本", font=fonts.small).pack(side="left")
        self.mc_var = tk.StringVar()
        self.mc_box = ttk.Combobox(row, textvariable=self.mc_var, state="readonly", width=12)
        self.mc_box.pack(side="left", padx=(6, 16))
        self.mc_box.bind("<<ComboboxSelected>>", lambda _e: self._load_loader_versions())

        _label(row, "加载器", font=fonts.small).pack(side="left")
        self.loader_var = tk.StringVar(value=modloaders.LOADERS["fabric"]["label"])
        self.loader_box = ttk.Combobox(
            row, textvariable=self.loader_var, state="readonly", width=14,
            values=[v["label"] for v in modloaders.LOADERS.values()],
        )
        self.loader_box.pack(side="left", padx=(6, 16))
        self.loader_box.bind("<<ComboboxSelected>>", lambda _e: self._load_loader_versions())

        _label(row, "加载器版本", font=fonts.small).pack(side="left")
        self.loader_ver_var = tk.StringVar()
        self.loader_ver_box = ttk.Combobox(row, textvariable=self.loader_ver_var, state="readonly", width=18)
        self.loader_ver_box.pack(side="left", padx=(6, 10))
        self.loader_ver_box.bind("<<ComboboxSelected>>", lambda _e: self._update_loader_hint())

        self.loader_refresh = RoundedButton(row, "刷新版本", command=self._load_loader_versions,
                                            width=92, height=28, kind="ghost", font=fonts.small,
                                            parent_bg=theme.CARD)
        self.loader_refresh.pack(side="right")

        info = Card(tab, padding=14)
        info.pack(fill="x", pady=(10, 0))
        box = info.inner
        self.loader_hint = _label(box, "选择版本与加载器后点「安装」", font=fonts.body,
                                  fg=theme.TEXT, justify="left", wraplength=760)
        self.loader_hint.pack(fill="x")

        _label(box, "安装目录（.minecraft）", font=fonts.small).pack(fill="x", pady=(10, 0))
        dir_row = tk.Frame(box, bg=theme.CARD)
        dir_row.pack(fill="x", pady=(4, 0))
        self.root_var = tk.StringVar(value=str(self.cfg.get("java_dir")))
        ttk.Entry(dir_row, textvariable=self.root_var).pack(side="left", fill="x", expand=True)
        RoundedButton(dir_row, "浏览…", command=self._pick_root, width=74, height=28, kind="ghost",
                      font=fonts.small, parent_bg=theme.CARD).pack(side="left", padx=(8, 0))

        java_row = tk.Frame(box, bg=theme.CARD)
        java_row.pack(fill="x", pady=(8, 0))
        self.java_label = _label(java_row, "", font=fonts.small, fg=theme.MUTED)
        self.java_label.pack(side="left")
        RoundedButton(java_row, "检测 Java", command=self._refresh_java, width=86, height=26,
                      kind="ghost", font=fonts.small, parent_bg=theme.CARD).pack(side="right")
        RoundedButton(java_row, "指定 java.exe…", command=self._pick_java, width=118, height=26,
                      kind="ghost", font=fonts.small, parent_bg=theme.CARD).pack(side="right", padx=(0, 6))

        actions = tk.Frame(tab, bg=theme.BG)
        actions.pack(fill="x", pady=(12, 0))
        self.install_btn = RoundedButton(actions, "安装加载器", command=self._install_loader, width=150,
                                         height=42, kind="primary", font=fonts.button, parent_bg=theme.BG)
        self.install_btn.pack(side="left")
        self.loader_status = _label(actions, "", font=fonts.small, fg=theme.MUTED, bg=theme.BG)
        self.loader_status.pack(side="left", padx=(12, 0))

        tip = Card(tab, padding=14)
        tip.pack(fill="x", pady=(12, 0))
        _label(tip.inner,
               "· Fabric / Quilt 是纯文件安装，装好即可用；缺原版会自动先下原版。\n"
               "· Forge / NeoForge 需要本机有 Java 17+（1.16 及更早需要 Java 8），程序会调用官方安装器。\n"
               "· 装好后在启动器里选 “<原版版本>-<加载器>-<版本>” 这样的条目启动。",
               font=fonts.small, fg=theme.MUTED, justify="left", wraplength=820).pack(fill="x")

    def _pick_root(self) -> None:
        path = filedialog.askdirectory(title="选择 .minecraft 目录", initialdir=self.root_var.get())
        if path:
            self.root_var.set(path)
            self.cfg["java_dir"] = path
            self.cfg.save()
            self._refresh_manage_versions()

    def _pick_java(self) -> None:
        path = filedialog.askopenfilename(
            title="选择 java.exe",
            filetypes=[("Java 可执行文件", "java.exe"), ("所有文件", "*.*")],
        )
        if path:
            self.cfg["java_path"] = path
            self.cfg.save()
            self._refresh_java()
            self.app.log(f"已指定 Java：{path}", "ok")

    def _refresh_java(self) -> None:
        java = modloaders.find_java(dict(self.cfg.data))
        if java:
            self.java_label.configure(text=f"Java：{java}", fg=theme.OK)
        else:
            self.java_label.configure(text="Java：未找到（Forge / NeoForge 需要）", fg=theme.WARN)

    def _loader_key(self) -> str:
        label = self.loader_var.get()
        for key, info in modloaders.LOADERS.items():
            if info["label"] == label:
                return key
        return "fabric"

    def _selected_mc(self) -> str:
        return self.mc_var.get().strip()

    def _loader_version(self) -> str:
        """从下拉框里取出纯版本号（去掉「(稳定)」这类标签）。"""
        idx = self.loader_ver_box.current()
        if 0 <= idx < len(self._loader_rows):
            return str(self._loader_rows[idx][0])
        return self.loader_ver_var.get().strip().split("  (")[0].strip()

    def _update_loader_hint(self) -> None:
        key = self._loader_key()
        mc = self._selected_mc()
        ver = self._loader_version()
        if not mc or not ver:
            return
        if key in ("fabric", "quilt"):
            vid = f"{key}-loader-{ver}-{mc}"
        else:
            vid = f"{mc}-{key}-{ver}"
        note = modloaders.LOADERS[key]["note"]
        self.loader_hint.configure(
            text=f"将安装为 versions/{vid}\n{modloaders.loader_label(key)} {ver} · Minecraft {mc} · {note}"
        )

    def _load_loader_versions(self) -> None:
        mc = self._selected_mc()
        key = self._loader_key()
        if not mc:
            return
        self.loader_status.configure(text="正在获取加载器版本…")
        self.loader_ver_box.configure(values=[])
        self.loader_ver_var.set("")

        def work() -> None:
            try:
                net = self.app.make_net()
                versions = modloaders.loader_versions(net, key, mc)
                self.app.ui_call(lambda: self._apply_loader_versions(versions))
            except Exception as exc:  # noqa: BLE001
                self.app.ui_call(lambda: self._loader_failed(exc))

        threading.Thread(target=work, daemon=True).start()

    def _apply_loader_versions(self, versions: List[Any]) -> None:
        self._loader_rows = versions
        labels = [f"{v}  ({tag})" if tag else v for v, tag in versions]
        self.loader_ver_box.configure(values=labels)
        if labels:
            self.loader_ver_box.current(0)
        self.loader_status.configure(text=f"共 {len(versions)} 个版本")
        self._update_loader_hint()

    def _loader_failed(self, exc: Exception) -> None:
        self.loader_status.configure(text="获取失败")
        self.app.log(f"加载器版本获取失败：{exc}", "error")

    def _install_loader(self) -> None:
        if self.app.busy:
            return
        mc = self._selected_mc()
        key = self._loader_key()
        ver = self._loader_version()
        if not mc or not ver:
            messagebox.showinfo("选择版本", "请先选择原版版本和加载器版本。")
            return
        root = Path(self.root_var.get().strip() or str(self.cfg.get("java_dir")))
        try:
            root.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            messagebox.showerror("目录不可用", str(exc))
            return
        if modloaders.needs_java(key) and not modloaders.find_java(dict(self.cfg.data)):
            if not messagebox.askyesno(
                "没有找到 Java",
                f"{modloaders.loader_label(key)} 需要 Java 才能安装。\n"
                "仍然继续吗？（会先把安装器下载下来，装好 Java 后重试即可）",
            ):
                return

        run_cfg = dict(self.cfg.data)

        def worker(progress, cancel):
            net = self.app.make_net()
            result = modloaders.install_loader(net, run_cfg, root, key, mc, ver,
                                               self.app.log, progress, cancel)
            self.app.ui_call(self._refresh_manage_versions)
            return result

        self.app.log(f"准备安装 {modloaders.loader_label(key)} {ver}（MC {mc}）→ {root}", "info")
        self.app.start_job(f"安装 {modloaders.loader_label(key)} {ver}", worker)

    # ------------------------------------------------------------ Mod 市场
    def _build_market_tab(self) -> None:
        fonts = self.app.fonts
        tab = self.tab_market

        card = Card(tab, padding=10)
        card.pack(fill="x", pady=(8, 0))
        row = card.inner
        _label(row, "搜索", font=fonts.small).pack(side="left")
        self.query_var = tk.StringVar()
        entry = ttk.Entry(row, textvariable=self.query_var, width=26)
        entry.pack(side="left", padx=(6, 14))
        entry.bind("<Return>", lambda _e: self._search_mods())

        _label(row, "MC 版本", font=fonts.small).pack(side="left")
        self.market_mc = ttk.Combobox(row, textvariable=self.mc_var, state="readonly", width=12)
        self.market_mc.pack(side="left", padx=(6, 14))

        _label(row, "加载器", font=fonts.small).pack(side="left")
        self.market_loader_var = tk.StringVar(value="fabric")
        self.market_loader = ttk.Combobox(
            row, textvariable=self.market_loader_var, state="readonly", width=10,
            values=["fabric", "quilt", "forge", "neoforge"],
        )
        self.market_loader.pack(side="left", padx=(6, 14))

        self.search_btn = RoundedButton(row, "搜索", command=self._search_mods, width=78, height=28,
                                        kind="primary", font=fonts.small, parent_bg=theme.CARD)
        self.search_btn.pack(side="left")
        self.market_status = _label(row, "", font=fonts.small, fg=theme.MUTED)
        self.market_status.pack(side="right")

        body = tk.Frame(tab, bg=theme.BG)
        body.pack(fill="both", expand=True, pady=(10, 0))
        body.grid_rowconfigure(0, weight=1)
        body.grid_columnconfigure(0, weight=1)

        list_card = Card(body, padding=8)
        list_card.grid(row=0, column=0, sticky="nsew")
        list_card.inner.grid_rowconfigure(0, weight=1)
        list_card.inner.grid_columnconfigure(0, weight=1)
        self.mod_tree = ttk.Treeview(list_card.inner, columns=("title", "author", "downloads"),
                                     show="headings", selectmode="browse")
        for col, (title, width, anchor) in {
            "title": ("Mod 名称", 260, "w"),
            "author": ("作者", 140, "w"),
            "downloads": ("下载量", 110, "e"),
        }.items():
            self.mod_tree.heading(col, text=title, anchor=anchor)
            self.mod_tree.column(col, width=width, anchor=anchor, stretch=(col == "title"))
        vsb = ttk.Scrollbar(list_card.inner, orient="vertical", command=self.mod_tree.yview)
        self.mod_tree.configure(yscrollcommand=vsb.set)
        self.mod_tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns", padx=(4, 0))
        self.mod_tree.tag_configure("even", background="#FAFBFD")
        self.mod_tree.bind("<<TreeviewSelect>>", self._on_mod_select)

        self.mod_empty = tk.Label(list_card.inner, text="输入关键字搜索 Mod（数据来自 Modrinth）",
                                  bg=theme.CARD, fg=theme.MUTED, font=fonts.small, justify="center")
        self.mod_empty.place(relx=0.5, rely=0.4, anchor="center")

        side = Card(body, padding=16)
        side.grid(row=0, column=1, sticky="ns", padx=(10, 0))
        side.configure(width=316)
        side.grid_propagate(False)
        box = side.inner
        _label(box, "Modrinth", font=fonts.small, fg=theme.MUTED).pack(fill="x")
        self.mod_title = tk.Label(box, text="未选择 Mod", bg=theme.CARD, fg=theme.TEXT,
                                  font=fonts.h3, anchor="w", justify="left", wraplength=280)
        self.mod_title.pack(fill="x", pady=(2, 4))
        self.mod_desc = tk.Label(box, text="", bg=theme.CARD, fg=theme.MUTED, font=fonts.small,
                                 anchor="w", justify="left", wraplength=280)
        self.mod_desc.pack(fill="x")
        self.mod_meta = _label(box, "", font=fonts.tiny, fg=theme.ACCENT_DARK)
        self.mod_meta.pack(fill="x", pady=(4, 0))

        tk.Frame(box, bg=theme.BORDER, height=1).pack(fill="x", pady=10)
        _label(box, "可用文件", font=fonts.small).pack(fill="x")
        self.file_var = tk.StringVar()
        self.file_box = ttk.Combobox(box, textvariable=self.file_var, state="readonly")
        self.file_box.pack(fill="x", pady=(4, 0))
        self.file_info = _label(box, "", font=fonts.tiny, fg=theme.MUTED)
        self.file_info.pack(fill="x", pady=(4, 0))

        self.deps_var = tk.BooleanVar(value=True)
        CheckBox(box, "同时下载必需的前置 Mod", self.deps_var, font=fonts.small).pack(anchor="w", pady=(8, 0))

        tk.Frame(box, bg=theme.BORDER, height=1).pack(fill="x", pady=10)
        self.market_dl_btn = RoundedButton(box, "下载到 mods 目录", command=self._download_mod, width=284,
                                           height=40, kind="primary", font=fonts.button,
                                           parent_bg=theme.CARD)
        self.market_dl_btn.pack(fill="x")
        self.market_dl_btn.set_enabled(False)
        RoundedButton(box, "在浏览器打开项目页", command=self._open_project, width=284, height=28,
                      kind="ghost", font=fonts.small, parent_bg=theme.CARD).pack(fill="x", pady=(6, 0))
        self.market_dir = _label(box, "", font=fonts.tiny, fg=theme.MUTED, justify="left", wraplength=280)
        self.market_dir.pack(fill="x", pady=(8, 0))

    def _open_project(self) -> None:
        idx = self.mod_tree.selection()
        if idx and self._hits:
            webbrowser.open(modrinth.project_url(self._hits[int(idx[0])].slug))

    def _search_mods(self) -> None:
        if self.app.busy:
            return
        query = self.query_var.get().strip()
        mc = self._selected_mc()
        loader = self.market_loader_var.get()
        if not query and not mc:
            messagebox.showinfo("搜索", "请输入关键字，或先选择一个 MC 版本。")
            return
        self.market_status.configure(text="正在搜索…")
        self.search_btn.set_enabled(False)
        self.mod_empty.configure(text="正在搜索…")

        def work() -> None:
            try:
                net = self.app.make_net()
                hits = modrinth.search(net, query, mc, loader, limit=30)
                self.app.ui_call(lambda: self._apply_hits(hits))
            except Exception as exc:  # noqa: BLE001
                self.app.ui_call(lambda: self._search_failed(exc))

        threading.Thread(target=work, daemon=True).start()

    def _apply_hits(self, hits: List[modrinth.ModHit]) -> None:
        self.search_btn.set_enabled(True)
        self._hits = hits
        self.mod_tree.delete(*self.mod_tree.get_children())
        for idx, hit in enumerate(hits):
            self.mod_tree.insert("", "end", iid=str(idx),
                                 values=(hit.title, hit.author, hit.download_text),
                                 tags=("even",) if idx % 2 else ())
        self.market_status.configure(text=f"共 {len(hits)} 个结果")
        self.mod_empty.configure(text="" if hits else "没有找到匹配的 Mod，换个关键字试试")
        if not hits:
            self.mod_empty.place(relx=0.5, rely=0.4, anchor="center")
        else:
            self.mod_empty.place_forget()

    def _search_failed(self, exc: Exception) -> None:
        self.search_btn.set_enabled(True)
        self.market_status.configure(text="搜索失败")
        self.mod_empty.configure(text="搜索失败，请检查网络")
        self.app.log(f"Modrinth 搜索失败：{exc}", "error")

    def _on_mod_select(self, _event=None) -> None:
        idx = self.mod_tree.selection()
        if not idx:
            return
        hit = self._hits[int(idx[0])]
        self.mod_title.configure(text=hit.title)
        self.mod_desc.configure(text=hit.description[:160])
        cats = "、".join([c for c in hit.categories if c in ("fabric", "forge", "neoforge", "quilt",
                                                            "optimization", "utility", "adventure")][:4])
        self.mod_meta.configure(text=f"{hit.author} · 下载 {hit.download_text} · {cats}")
        self.market_dl_btn.set_enabled(False)
        self.file_box.configure(values=[])
        self.file_var.set("")
        self.file_info.configure(text="正在获取版本…")

        mc = self._selected_mc()
        loader = self.market_loader_var.get()

        def work() -> None:
            try:
                net = self.app.make_net()
                files = modrinth.project_versions(net, hit.project_id, mc, loader)
                self.app.ui_call(lambda: self._apply_files(files))
            except Exception as exc:  # noqa: BLE001
                self.app.ui_call(lambda: self.file_info.configure(text=f"获取失败：{exc}"))

        threading.Thread(target=work, daemon=True).start()

    def _apply_files(self, files: List[modrinth.ModFile]) -> None:
        self._files = files
        labels = [f"{f.version_number} · {f.channel} · {f.size_text}" for f in files]
        self.file_box.configure(values=labels)
        if labels:
            self.file_box.current(0)
            self.market_dl_btn.set_enabled(True)
            self._update_file_info()
        else:
            self.file_info.configure(text="没有匹配当前版本/加载器的文件")

    def _update_file_info(self) -> None:
        idx = self.file_box.current()
        if 0 <= idx < len(self._files):
            f = self._files[idx]
            self.file_info.configure(text=f"{f.filename}\n{f.date} · {'/'.join(f.loaders)}")

    def _download_mod(self) -> None:
        if self.app.busy:
            return
        idx = self.file_box.current()
        if idx < 0 or idx >= len(self._files):
            messagebox.showinfo("选择文件", "请先选择要下载的文件版本。")
            return
        chosen = self._files[idx]
        root = Path(self.root_var.get().strip() or str(self.cfg.get("java_dir")))
        mods_dir = mods.resolve_mods_dir(root)
        mc = self._selected_mc()
        loader = self.market_loader_var.get()
        with_deps = self.deps_var.get()

        def worker(progress, cancel):
            net = self.app.make_net()
            if with_deps:
                batch = modrinth.resolve_with_dependencies(net, chosen, mc, loader, cancel=cancel)
            else:
                batch = [chosen]
            saved = []
            for item in batch:
                path = modrinth.download_file(net, item, mods_dir, progress, cancel, self.app.log)
                saved.append(str(path))
            return {"dir": str(mods_dir), "files": saved}

        self.app.log(f"下载 {chosen.filename} → {mods_dir}", "info")
        self.app.start_job(f"下载 {chosen.name or chosen.filename}", worker)
        self.market_dir.configure(text=f"保存到：{mods_dir}")

    # ------------------------------------------------------------ Mod 管理
    def _build_manage_tab(self) -> None:
        fonts = self.app.fonts
        tab = self.tab_manage

        card = Card(tab, padding=10)
        card.pack(fill="x", pady=(8, 0))
        row = card.inner
        _label(row, "版本", font=fonts.small).pack(side="left")
        self.manage_ver_var = tk.StringVar()
        self.manage_ver_box = ttk.Combobox(row, textvariable=self.manage_ver_var, state="readonly", width=30)
        self.manage_ver_box.pack(side="left", padx=(6, 10))
        self.manage_ver_box.bind("<<ComboboxSelected>>", lambda _e: self._refresh_mods())
        self.manage_refresh = RoundedButton(row, "刷新", command=self._refresh_mods, width=70, height=28,
                                            kind="ghost", font=fonts.small, parent_bg=theme.CARD)
        self.manage_refresh.pack(side="right")
        self.manage_dir = _label(row, "", font=fonts.tiny, fg=theme.MUTED)
        self.manage_dir.pack(side="right", padx=(0, 12))

        body = tk.Frame(tab, bg=theme.BG)
        body.pack(fill="both", expand=True, pady=(10, 0))
        list_card = Card(body, padding=8)
        list_card.pack(fill="both", expand=True)
        list_card.inner.grid_rowconfigure(0, weight=1)
        list_card.inner.grid_columnconfigure(0, weight=1)
        self.mod_list = ttk.Treeview(list_card.inner, columns=("file", "size", "status"),
                                     show="headings", selectmode="extended")
        for col, (title, width, anchor) in {
            "file": ("文件", 460, "w"),
            "size": ("大小", 110, "e"),
            "status": ("状态", 90, "w"),
        }.items():
            self.mod_list.heading(col, text=title, anchor=anchor)
            self.mod_list.column(col, width=width, anchor=anchor, stretch=(col == "file"))
        vsb = ttk.Scrollbar(list_card.inner, orient="vertical", command=self.mod_list.yview)
        self.mod_list.configure(yscrollcommand=vsb.set)
        self.mod_list.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns", padx=(4, 0))
        self.mod_list.tag_configure("off", foreground=theme.MUTED)

        actions = tk.Frame(tab, bg=theme.BG)
        actions.pack(fill="x", pady=(10, 0))
        RoundedButton(actions, "启用 / 禁用", command=self._toggle_mod, width=118, height=34,
                      kind="soft", font=fonts.small, parent_bg=theme.BG).pack(side="left")
        RoundedButton(actions, "删除选中", command=self._delete_mods, width=100, height=34,
                      kind="danger", font=fonts.small, parent_bg=theme.BG).pack(side="left", padx=(8, 0))
        RoundedButton(actions, "打开 mods 目录", command=self._open_mods_dir, width=126, height=34,
                      kind="ghost", font=fonts.small, parent_bg=theme.BG).pack(side="left", padx=(8, 0))
        self.manage_status = _label(actions, "", font=fonts.small, fg=theme.MUTED, bg=theme.BG)
        self.manage_status.pack(side="left", padx=(12, 0))

    def _refresh_manage_versions(self) -> None:
        root = Path(self.root_var.get().strip() or str(self.cfg.get("java_dir")))
        versions = javadl.installed_versions(root)
        self.manage_ver_box.configure(values=versions)
        if versions:
            current = self.manage_ver_var.get()
            if current not in versions:
                self.manage_ver_box.set(versions[0])
            self._refresh_mods()

    def _mods_dir(self) -> Path:
        root = Path(self.root_var.get().strip() or str(self.cfg.get("java_dir")))
        return mods.resolve_mods_dir(root, self.manage_ver_var.get().strip())

    def _refresh_mods(self) -> None:
        directory = self._mods_dir()
        self._entries = mods.list_mods(directory)
        self.mod_list.delete(*self.mod_list.get_children())
        for idx, entry in enumerate(self._entries):
            tags = () if entry.enabled else ("off",)
            self.mod_list.insert("", "end", iid=str(idx),
                                 values=(entry.name, entry.size_text, entry.status), tags=tags)
        self.manage_dir.configure(text=str(directory))
        self.manage_status.configure(text=f"{len(self._entries)} 个 Mod 文件")
        if directory.exists():
            self.market_dir.configure(text=f"保存到：{directory}")

    def _toggle_mod(self) -> None:
        selection = self.mod_list.selection()
        if not selection:
            return
        changed = 0
        for iid in selection:
            entry = self._entries[int(iid)]
            try:
                mods.set_enabled(entry, not entry.enabled)
                changed += 1
            except Exception as exc:  # noqa: BLE001
                self.app.log(f"操作失败：{exc}", "error")
        self.app.log(f"已切换 {changed} 个 Mod 的启用状态", "ok")
        self._refresh_mods()

    def _delete_mods(self) -> None:
        selection = self.mod_list.selection()
        if not selection:
            return
        if not messagebox.askyesno("删除", f"确定删除选中的 {len(selection)} 个 Mod 文件吗？"):
            return
        for iid in selection:
            entry = self._entries[int(iid)]
            try:
                mods.delete_entry(entry)
            except Exception as exc:  # noqa: BLE001
                self.app.log(f"删除失败：{exc}", "error")
        self._refresh_mods()

    def _open_mods_dir(self) -> None:
        directory = self._mods_dir()
        try:
            mods.open_folder(directory)
            self.app.log(f"已打开 {directory}", "info")
        except Exception as exc:  # noqa: BLE001
            self.app.log(f"打开失败：{exc}", "error")

    # ------------------------------------------------------------ 生命周期
    def on_show(self) -> None:
        self._refresh_java()
        if not self._mc_versions:
            self._load_mc_versions()
        else:
            self._refresh_manage_versions()

    def _load_mc_versions(self) -> None:
        self.loader_status.configure(text="正在获取版本列表…")

        def work() -> None:
            try:
                net = self.app.make_net()
                manifest = javadl.load_manifest(net, javadl.make_sources(dict(self.cfg.data)))
                versions = [v["id"] for v in manifest.get("versions", []) if v.get("type") == "release"]
                self.app.ui_call(lambda: self._apply_mc_versions(manifest, versions))
            except Exception as exc:  # noqa: BLE001
                self.app.ui_call(lambda: self.loader_status.configure(text=f"版本列表获取失败：{exc}"))

        threading.Thread(target=work, daemon=True).start()

    def _apply_mc_versions(self, manifest: Dict[str, Any], versions: List[str]) -> None:
        self._manifest = manifest
        self._mc_versions = versions
        self.mc_box.configure(values=versions)
        self.market_mc.configure(values=versions)
        if versions:
            self.mc_var.set(versions[0])
        self.loader_status.configure(text=f"共 {len(versions)} 个正式版可选")
        self._load_loader_versions()
        self._refresh_manage_versions()

    def on_busy(self, busy: bool) -> None:
        self.install_btn.set_enabled(not busy)
        self.search_btn.set_enabled(not busy)
        self.market_dl_btn.set_enabled(bool(self._files) and not busy)
