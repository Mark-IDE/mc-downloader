"""PC · Java 版页面：版本列表 + 安装选项 + 下载。"""

from __future__ import annotations

import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Any, Dict, List, Optional

from .. import javadl
from ..net import human_size
from . import theme
from .app import Page
from .theme import Card, CheckBox, RoundedButton, Tooltip

SOURCE_LABELS = {
    "auto": "自动（镜像优先）",
    "official": "官方源（Mojang）",
    "bmcl": "Bang Bang 镜像",
    "custom": "自定义镜像",
}
SOURCE_KEYS = {v: k for k, v in SOURCE_LABELS.items()}

TYPE_LABELS = {"全部": "all", "正式版": "release", "快照": "snapshot", "远古版": "old", "愚人节": "april"}


class JavaPage(Page):
    name = "java"
    show_dock = True

    def build(self) -> None:
        self._manifest: Optional[Dict[str, Any]] = None
        self._loaded = False
        self._items: Dict[str, Dict[str, Any]] = {}
        self._size_cache: Dict[str, int] = {}
        self._build_toolbar()
        self._build_body()

    # ------------------------------------------------------------ 顶部工具条
    def _build_toolbar(self) -> None:
        bar = Card(self, padding=10)
        bar.pack(fill="x")
        row = bar.inner
        label = dict(bg=theme.CARD, fg=theme.TEXT_SOFT, font=self.app.fonts.small)

        tk.Label(row, text="下载源", **label).pack(side="left")
        self.source_var = tk.StringVar(value=SOURCE_LABELS.get(self.cfg.get("source"), SOURCE_LABELS["auto"]))
        self.source_box = ttk.Combobox(row, textvariable=self.source_var, values=list(SOURCE_LABELS.values()),
                                       state="readonly", width=17)
        self.source_box.pack(side="left", padx=(6, 16))
        self.source_box.bind("<<ComboboxSelected>>", self._on_source_change)

        tk.Label(row, text="搜索", **label).pack(side="left")
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(row, textvariable=self.search_var, width=18)
        self.search_entry.pack(side="left", padx=(6, 16))
        self.search_entry.bind("<KeyRelease>", self._on_search)

        self.type_var = tk.StringVar(value="全部")
        self.type_box = ttk.Combobox(row, textvariable=self.type_var, values=list(TYPE_LABELS.keys()),
                                     state="readonly", width=8)
        self.type_box.pack(side="left")
        self.type_box.bind("<<ComboboxSelected>>", lambda _e: self._apply_filter())

        self.refresh_btn = RoundedButton(row, "刷新列表", command=self.reload, width=92, height=28,
                                         kind="ghost", font=self.app.fonts.small, parent_bg=theme.CARD)
        self.refresh_btn.pack(side="right")
        self.count_label = tk.Label(row, text="", bg=theme.CARD, fg=theme.MUTED, font=self.app.fonts.small)
        self.count_label.pack(side="right", padx=(0, 12))

    # ------------------------------------------------------------ 主体
    def _build_body(self) -> None:
        body = tk.Frame(self, bg=theme.BG)
        body.pack(fill="both", expand=True, pady=(10, 0))
        body.grid_rowconfigure(0, weight=1)
        body.grid_columnconfigure(0, weight=1)

        list_card = Card(body, padding=8)
        list_card.grid(row=0, column=0, sticky="nsew")
        list_card.inner.grid_rowconfigure(0, weight=1)
        list_card.inner.grid_columnconfigure(0, weight=1)

        columns = ("version", "type", "date", "state")
        self.tree = ttk.Treeview(list_card.inner, columns=columns, show="headings", selectmode="browse")
        for col, (title, width, stretch) in {
            "version": ("版本号", 190, True),
            "type": ("类型", 96, False),
            "date": ("发布时间", 108, False),
            "state": ("状态", 78, False),
        }.items():
            self.tree.heading(col, text=title, anchor="w")
            self.tree.column(col, width=width, anchor="w", stretch=stretch)
        vsb = ttk.Scrollbar(list_card.inner, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns", padx=(4, 0))
        self.tree.tag_configure("even", background="#FAFBFD")
        self.tree.tag_configure("installed", foreground=theme.MUTED)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        self.tree.bind("<Double-1>", lambda _e: self._start(False))

        self._build_side(body)

    def _build_side(self, parent: tk.Misc) -> None:
        card = Card(parent, padding=16)
        card.grid(row=0, column=1, sticky="ns", padx=(10, 0))
        card.configure(width=292)
        card.grid_propagate(False)
        box = card.inner
        fonts = self.app.fonts

        tk.Label(box, text="安装到本机", bg=theme.CARD, fg=theme.MUTED, font=fonts.small,
                 anchor="w").pack(fill="x")
        self.sel_label = tk.Label(box, text="未选择版本", bg=theme.CARD, fg=theme.TEXT, font=fonts.h1,
                                  anchor="w")
        self.sel_label.pack(fill="x", pady=(2, 4))
        self.sel_meta = tk.Label(box, text="从左侧列表选择一个版本", bg=theme.CARD, fg=theme.MUTED,
                                 font=fonts.small, anchor="w", justify="left", wraplength=250)
        self.sel_meta.pack(fill="x")
        self._meta_text = "从左侧列表选择一个版本"
        self._selected_vid = ""

        tk.Frame(box, bg=theme.BORDER, height=1).pack(fill="x", pady=10)

        tk.Label(box, text="安装目录", bg=theme.CARD, fg=theme.TEXT_SOFT, font=fonts.small,
                 anchor="w").pack(fill="x")
        path_row = tk.Frame(box, bg=theme.CARD)
        path_row.pack(fill="x", pady=(4, 0))
        self.dir_var = tk.StringVar(value=str(self.cfg.get("java_dir")))
        ttk.Entry(path_row, textvariable=self.dir_var, width=20).pack(side="left", fill="x", expand=True)
        RoundedButton(path_row, "…", command=self._pick_dir, width=30, height=28, kind="ghost",
                      font=fonts.small, parent_bg=theme.CARD).pack(side="left", padx=(6, 0))

        opts = tk.Frame(box, bg=theme.CARD)
        opts.pack(fill="x", pady=(10, 0))
        self.assets_var = tk.BooleanVar(value=bool(self.cfg.get("download_assets")))
        self.libs_var = tk.BooleanVar(value=bool(self.cfg.get("download_libraries")))
        self.sha1_var = tk.BooleanVar(value=bool(self.cfg.get("verify_sha1")))
        CheckBox(opts, "下载资源文件（assets）", self.assets_var,
                 command=lambda: self._save_opt("download_assets", self.assets_var),
                 font=self.app.fonts.body).pack(anchor="w")
        CheckBox(opts, "下载依赖库（libraries）", self.libs_var,
                 command=lambda: self._save_opt("download_libraries", self.libs_var),
                 font=self.app.fonts.body).pack(anchor="w")
        CheckBox(opts, "下载后校验 SHA1", self.sha1_var,
                 command=lambda: self._save_opt("verify_sha1", self.sha1_var),
                 font=self.app.fonts.body).pack(anchor="w")

        tk.Frame(box, bg=theme.BORDER, height=1).pack(fill="x", pady=10)

        self.start_btn = RoundedButton(box, "开始下载", command=lambda: self._start(False), width=252,
                                       height=42, kind="primary", font=fonts.button, parent_bg=theme.CARD)
        self.start_btn.pack(fill="x")
        self.start_btn.set_enabled(False)

        self.core_btn = RoundedButton(box, "仅下载核心（跳过资源）", command=lambda: self._start(True),
                                      width=252, height=32, kind="ghost", font=fonts.small,
                                      parent_bg=theme.CARD)
        self.core_btn.pack(fill="x", pady=(6, 0))
        self.core_btn.set_enabled(False)

        tk.Label(box, text="重复下载会自动跳过已完成文件", bg=theme.CARD, fg=theme.MUTED,
                 font=fonts.tiny, anchor="w").pack(fill="x", pady=(6, 0))

    # ------------------------------------------------------------ 数据加载
    def on_show(self) -> None:
        if not self._loaded:
            self._loaded = True
            self.reload()

    def reload(self) -> None:
        if self.app.busy:
            self.app.log("正在下载中，完成后再刷新列表。", "warn")
            return
        self.refresh_btn.set_enabled(False)
        self.count_label.configure(text="正在获取版本列表…")
        net = self.app.make_net()
        sources = javadl.make_sources(self.cfg)

        def work() -> None:
            try:
                manifest = javadl.load_manifest(net, sources)
                self.app.ui_call(lambda: self._apply_manifest(manifest))
            except Exception as exc:  # noqa: BLE001
                self.app.ui_call(lambda: self._manifest_failed(exc))

        threading.Thread(target=work, name="manifest", daemon=True).start()

    def _manifest_failed(self, exc: Exception) -> None:
        self.count_label.configure(text="获取失败")
        self.refresh_btn.set_enabled(True)
        self.app.log(f"版本列表获取失败：{exc}", "error")

    def _apply_manifest(self, manifest: Dict[str, Any]) -> None:
        self._manifest = manifest
        self.refresh_btn.set_enabled(True)
        self._apply_filter()
        latest = manifest.get("latest", {})
        self.app.log(f"版本清单加载完成：{len(manifest.get('versions', []))} 个版本，"
                     f"最新正式版 {latest.get('release')}", "ok")

    def _apply_filter(self) -> None:
        if not self._manifest:
            return
        keyword = self.search_var.get().strip()
        vtype = TYPE_LABELS.get(self.type_var.get(), "all")
        versions = javadl.search_versions(self._manifest, keyword, vtype)
        root_dir = Path(self.dir_var.get().strip() or ".")
        self.tree.delete(*self.tree.get_children())
        self._items.clear()
        installed = 0
        for idx, item in enumerate(versions[:2000]):
            vid = item.get("id", "")
            is_installed = (root_dir / "versions" / vid / f"{vid}.jar").exists()
            installed += 1 if is_installed else 0
            self._items[vid] = item
            tags = ["installed"] if is_installed else (["even"] if idx % 2 else [])
            self.tree.insert(
                "", "end", iid=vid,
                values=(vid, javadl.VERSION_TYPE_LABEL.get(item.get("type"), item.get("type")),
                        javadl.release_time_text(item), "已安装" if is_installed else ""),
                tags=tuple(tags),
            )
        self.count_label.configure(text=f"共 {len(versions)} 个版本 · 已安装 {installed} 个")
        self.tree.yview_moveto(0)

    def _refresh_installed_flags(self) -> None:
        self._apply_filter()

    # ------------------------------------------------------------ 交互
    def _on_search(self, _event=None) -> None:
        self.after(220, self._debounced_search)

    def _debounced_search(self) -> None:
        if getattr(self, "_search_job", None):
            try:
                self.after_cancel(self._search_job)
            except Exception:  # noqa: BLE001
                pass
        self._search_job = self.after(1, self._apply_filter)

    def _on_source_change(self, _event=None) -> None:
        key = SOURCE_KEYS.get(self.source_var.get(), "auto")
        self.cfg["source"] = key
        self.cfg.save()
        self.app.update_source_hint()
        self.app.log(f"下载源已切换为：{self.source_var.get()}", "info")
        self.reload()

    def _save_opt(self, key: str, var: tk.BooleanVar) -> None:
        self.cfg[key] = bool(var.get())
        self.cfg.save()

    def _pick_dir(self) -> None:
        path = filedialog.askdirectory(title="选择 Minecraft 安装目录",
                                       initialdir=self.dir_var.get() or str(Path.home()))
        if path:
            self.dir_var.set(path)
            self.cfg["java_dir"] = path
            self.cfg.save()
            self._apply_filter()

    def _on_select(self, _event=None) -> None:
        selection = self.tree.selection()
        if not selection:
            return
        vid = selection[0]
        item = self._items.get(vid, {})
        self.sel_label.configure(text=vid)
        self._selected_vid = vid
        self._meta_text = (f"{javadl.VERSION_TYPE_LABEL.get(item.get('type'), item.get('type'))} · "
                           f"{javadl.release_time_text(item)}")
        self._render_meta()
        self.start_btn.set_enabled(True)
        self.core_btn.set_enabled(True)
        self._estimate_size(vid, item)

    def _render_meta(self) -> None:
        size = self._size_cache.get(self._selected_vid)
        text = self._meta_text
        if size:
            text += f" · 预计下载 {human_size(size)}"
        self.sel_meta.configure(text=text, fg=theme.TEXT_SOFT if size else theme.MUTED)

    def _estimate_size(self, vid: str, item: Dict[str, Any]) -> None:
        if vid in self._size_cache:
            self._render_meta()
            return
        sources = javadl.make_sources(self.cfg)

        def work() -> None:
            try:
                net = self.app.make_net()
                vjson = net.fetch_json(sources[-1].map(item.get("url", "")))
                total = (vjson.get("downloads", {}).get("client", {}).get("size") or 0)
                total += (vjson.get("assetIndex", {}) or {}).get("totalSize") or 0
                for lib in vjson.get("libraries", []):
                    total += ((lib.get("downloads") or {}).get("artifact") or {}).get("size") or 0
                self._size_cache[vid] = total
                self.app.ui_call(self._render_meta)
            except Exception:  # noqa: BLE001
                pass

        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------ 下载
    def download_dir(self) -> str:
        return self.dir_var.get().strip() or str(self.cfg.get("java_dir"))

    def selected_version(self) -> Optional[str]:
        selection = self.tree.selection()
        return selection[0] if selection else None

    def _start(self, core_only: bool) -> None:
        if self.app.busy:
            return
        vid = self.selected_version()
        if not vid:
            messagebox.showinfo("选择版本", "请先在列表里选中一个版本。")
            return
        root = Path(self.download_dir())
        try:
            root.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            messagebox.showerror("目录不可用", f"无法创建目录：{exc}")
            return

        run_cfg = dict(self.cfg.data)
        run_cfg["download_assets"] = bool(self.assets_var.get()) and not core_only
        run_cfg["download_libraries"] = bool(self.libs_var.get())
        run_cfg["verify_sha1"] = bool(self.sha1_var.get())
        self.cfg["java_dir"] = str(root)
        self.cfg.save()
        sources = javadl.make_sources(run_cfg)

        def worker(progress, cancel):
            net = self.app.make_net()
            installer = javadl.JavaInstaller(net, run_cfg, self.app.log, progress, cancel)
            result = installer.install(vid, root, sources)
            self.app.ui_call(self._refresh_installed_flags)
            return result

        self.app.log(f"准备安装 {vid} → {root}", "info")
        self.app.start_job(f"正在下载 {vid}", worker)

    # ------------------------------------------------------------ 状态
    def on_busy(self, busy: bool) -> None:
        has_selection = bool(self.tree.selection())
        self.start_btn.set_enabled(not busy and has_selection)
        self.core_btn.set_enabled(not busy and has_selection)
        self.refresh_btn.set_enabled(not busy)
