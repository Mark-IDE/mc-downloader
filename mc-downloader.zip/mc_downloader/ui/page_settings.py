"""设置页。"""

from __future__ import annotations

import shutil
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from ..config import CACHE_DIR, CONFIG_PATH, DEFAULT_CONFIG
from ..net import human_size
from . import theme
from .app import Page
from .theme import Card, CheckBox, RoundedButton

SOURCE_LABELS = {
    "auto": "自动（镜像优先，失败回退官方）",
    "official": "官方源（Mojang）",
    "bmcl": "Bang Bang 镜像（国内加速）",
    "custom": "自定义镜像",
}
SOURCE_KEYS = {v: k for k, v in SOURCE_LABELS.items()}


class SettingsPage(Page):
    name = "settings"
    show_dock = False

    def build(self) -> None:
        fonts = self.app.fonts
        wrap = tk.Frame(self, bg=theme.BG)
        wrap.pack(fill="both", expand=True)

        card = Card(wrap, padding=18)
        card.pack(fill="x")
        box = card.inner

        tk.Label(box, text="下载设置", bg=theme.CARD, fg=theme.TEXT, font=fonts.h2,
                 anchor="w").pack(fill="x")
        tk.Label(box, text="修改后点击底部「保存设置」生效", bg=theme.CARD, fg=theme.MUTED,
                 font=fonts.small, anchor="w").pack(fill="x", pady=(2, 12))

        grid = tk.Frame(box, bg=theme.CARD)
        grid.pack(fill="x")
        grid.grid_columnconfigure(1, weight=1)

        self.source_var = tk.StringVar(value=SOURCE_LABELS.get(self.cfg.get("source"), SOURCE_LABELS["auto"]))
        self._row(grid, 0, "下载源")
        ttk.Combobox(grid, textvariable=self.source_var, values=list(SOURCE_LABELS.values()),
                     state="readonly", width=32).grid(row=0, column=1, sticky="w", pady=4)

        self.custom_var = tk.StringVar(value=str(self.cfg.get("custom_base") or ""))
        self._row(grid, 1, "自定义镜像地址")
        ttk.Entry(grid, textvariable=self.custom_var).grid(row=1, column=1, sticky="ew", pady=4)
        tk.Label(grid, text="例如 https://bmclapi2.bangbang93.com", bg=theme.CARD, fg=theme.MUTED,
                 font=fonts.tiny).grid(row=2, column=1, sticky="w")

        nums = tk.Frame(box, bg=theme.CARD)
        nums.pack(fill="x", pady=(12, 0))
        self.threads_var = tk.IntVar(value=int(self.cfg.get("threads") or 16))
        self.retries_var = tk.IntVar(value=int(self.cfg.get("retries") or 3))
        self.timeout_var = tk.IntVar(value=int(self.cfg.get("timeout") or 20))
        for label, var, lo, hi in (
            ("线程数", self.threads_var, 1, 64),
            ("重试次数", self.retries_var, 1, 10),
            ("超时（秒）", self.timeout_var, 5, 120),
        ):
            cell = tk.Frame(nums, bg=theme.CARD)
            cell.pack(side="left", padx=(0, 24))
            tk.Label(cell, text=label, bg=theme.CARD, fg=theme.TEXT_SOFT, font=fonts.small).pack(anchor="w")
            ttk.Spinbox(cell, from_=lo, to=hi, textvariable=var, width=8).pack(anchor="w", pady=(4, 0))

        self.sha1_var = tk.BooleanVar(value=bool(self.cfg.get("verify_sha1")))
        self.fallback_var = tk.BooleanVar(value=bool(self.cfg.get("fallback_official")))
        self.insecure_var = tk.BooleanVar(value=bool(self.cfg.get("allow_insecure_tls")))
        checks = tk.Frame(box, bg=theme.CARD)
        checks.pack(fill="x", pady=(14, 0))
        CheckBox(checks, "下载后校验 SHA1（推荐）", self.sha1_var, font=fonts.body).pack(anchor="w", pady=2)
        CheckBox(checks, "镜像失败时自动回退官方源", self.fallback_var, font=fonts.body).pack(anchor="w", pady=2)
        CheckBox(checks, "证书异常时允许降级（部分镜像证书链不完整）", self.insecure_var,
                 font=fonts.body).pack(anchor="w", pady=2)

        bottom = tk.Frame(wrap, bg=theme.BG)
        bottom.pack(fill="x", pady=(10, 0))
        bottom.grid_columnconfigure(0, weight=1, uniform="col")
        bottom.grid_columnconfigure(1, weight=1, uniform="col")

        # 目录
        card2 = Card(bottom, padding=18)
        card2.grid(row=0, column=0, sticky="nsew")
        box2 = card2.inner
        tk.Label(box2, text="目录", bg=theme.CARD, fg=theme.TEXT, font=fonts.h2,
                 anchor="w").pack(fill="x", pady=(0, 10))

        self.java_dir_var = tk.StringVar(value=str(self.cfg.get("java_dir")))
        self._path_row(box2, "Minecraft 安装目录", self.java_dir_var, "java_dir")
        self.apk_dir_var = tk.StringVar(value=str(self.cfg.get("apk_dir")))
        self._path_row(box2, "APK / 安装包目录", self.apk_dir_var, "apk_dir")
        self.java_path_var = tk.StringVar(value=str(self.cfg.get("java_path") or ""))
        self._file_row(box2, "Java 路径（Forge / NeoForge 用，可留空自动检测）", self.java_path_var)

        # 安卓
        card3 = Card(bottom, padding=18)
        card3.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        box3 = card3.inner
        tk.Label(box3, text="安卓 · 自定义清单源", bg=theme.CARD, fg=theme.TEXT, font=fonts.h2,
                 anchor="w").pack(fill="x", pady=(0, 8))
        self.index_var = tk.StringVar(value=str(self.cfg.get("apk_index_url") or ""))
        ttk.Entry(box3, textvariable=self.index_var).pack(fill="x")
        tk.Label(box3, text='JSON：数组或 {"versions": [...]}，每项形如\n'
                           '{"version":"1.21.0","url":"https://.../a.apk","size":123,"sha1":"..."}',
                 bg=theme.CARD, fg=theme.MUTED, font=fonts.tiny, anchor="w",
                 justify="left").pack(fill="x", pady=(4, 0))

        # 操作
        actions = tk.Frame(wrap, bg=theme.BG)
        actions.pack(fill="x", pady=(12, 0))
        RoundedButton(actions, "保存设置", command=self._save, width=132, height=40, kind="primary",
                      font=fonts.button, parent_bg=theme.BG).pack(side="left")
        RoundedButton(actions, "恢复默认", command=self._reset, width=110, height=40, kind="ghost",
                      font=fonts.body, parent_bg=theme.BG).pack(side="left", padx=(10, 0))
        RoundedButton(actions, "清空缓存", command=self._clear_cache, width=110, height=40, kind="ghost",
                      font=fonts.body, parent_bg=theme.BG).pack(side="left", padx=(10, 0))

        self.status = tk.Label(wrap, text=f"配置文件：{CONFIG_PATH}", bg=theme.BG, fg=theme.MUTED,
                               font=fonts.tiny, anchor="w")
        self.status.pack(fill="x", pady=(10, 0))

    def _row(self, grid: tk.Misc, row: int, text: str) -> None:
        tk.Label(grid, text=text, bg=theme.CARD, fg=theme.TEXT_SOFT, font=self.app.fonts.small,
                 anchor="w", width=14).grid(row=row, column=0, sticky="w", pady=4)

    def _path_row(self, parent: tk.Misc, label: str, var: tk.StringVar, key: str) -> None:
        fonts = self.app.fonts
        tk.Label(parent, text=label, bg=theme.CARD, fg=theme.TEXT_SOFT, font=fonts.small,
                 anchor="w").pack(fill="x", pady=(6, 0))
        row = tk.Frame(parent, bg=theme.CARD)
        row.pack(fill="x", pady=(4, 0))
        ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True)

        def pick() -> None:
            path = filedialog.askdirectory(title=f"选择{label}", initialdir=var.get() or str(Path.home()))
            if path:
                var.set(path)

        RoundedButton(row, "浏览…", command=pick, width=74, height=30, kind="ghost", font=fonts.small,
                      parent_bg=theme.CARD).pack(side="left", padx=(8, 0))

    # -------------------------------------------------------------- 动作
    def _file_row(self, parent: tk.Misc, label: str, var: tk.StringVar) -> None:
        fonts = self.app.fonts
        tk.Label(parent, text=label, bg=theme.CARD, fg=theme.TEXT_SOFT, font=fonts.small,
                 anchor="w").pack(fill="x", pady=(6, 0))
        row = tk.Frame(parent, bg=theme.CARD)
        row.pack(fill="x", pady=(4, 0))
        ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True)

        def pick() -> None:
            path = filedialog.askopenfilename(
                title="选择 java.exe",
                filetypes=[("Java", "java.exe"), ("所有文件", "*.*")],
            )
            if path:
                var.set(path)

        RoundedButton(row, "浏览…", command=pick, width=74, height=30, kind="ghost", font=fonts.small,
                      parent_bg=theme.CARD).pack(side="left", padx=(8, 0))

    def _int_of(self, var: tk.IntVar, default: int) -> int:
        try:
            return int(var.get())
        except (tk.TclError, ValueError):
            return default

    def _save(self) -> None:
        self.cfg["source"] = SOURCE_KEYS.get(self.source_var.get(), "auto")
        self.cfg["custom_base"] = self.custom_var.get().strip()
        self.cfg["threads"] = max(1, min(64, self._int_of(self.threads_var, 16)))
        self.cfg["retries"] = max(1, min(10, self._int_of(self.retries_var, 3)))
        self.cfg["timeout"] = max(5, min(120, self._int_of(self.timeout_var, 20)))
        self.cfg["verify_sha1"] = bool(self.sha1_var.get())
        self.cfg["fallback_official"] = bool(self.fallback_var.get())
        self.cfg["allow_insecure_tls"] = bool(self.insecure_var.get())
        self.cfg["java_dir"] = self.java_dir_var.get().strip() or str(DEFAULT_CONFIG["java_dir"])
        self.cfg["apk_dir"] = self.apk_dir_var.get().strip() or str(DEFAULT_CONFIG["apk_dir"])
        self.cfg["apk_index_url"] = self.index_var.get().strip()
        self.cfg["java_path"] = self.java_path_var.get().strip()
        self.cfg.save()
        self.app.update_source_hint()
        self.status.configure(text=f"已保存 ✔  {CONFIG_PATH}")
        self.app.log("设置已保存", "ok")

    def _reset(self) -> None:
        if not messagebox.askyesno("恢复默认", "确定把所有设置恢复为默认值吗？"):
            return
        for key, value in DEFAULT_CONFIG.items():
            self.cfg[key] = value
        self.cfg.save()
        self.source_var.set(SOURCE_LABELS["auto"])
        self.custom_var.set("")
        self.threads_var.set(int(DEFAULT_CONFIG["threads"]))
        self.retries_var.set(int(DEFAULT_CONFIG["retries"]))
        self.timeout_var.set(int(DEFAULT_CONFIG["timeout"]))
        self.sha1_var.set(bool(DEFAULT_CONFIG["verify_sha1"]))
        self.fallback_var.set(bool(DEFAULT_CONFIG["fallback_official"]))
        self.insecure_var.set(bool(DEFAULT_CONFIG["allow_insecure_tls"]))
        self.java_dir_var.set(str(DEFAULT_CONFIG["java_dir"]))
        self.apk_dir_var.set(str(DEFAULT_CONFIG["apk_dir"]))
        self.index_var.set("")
        self.app.update_source_hint()
        self.status.configure(text="已恢复默认设置")
        self.app.log("设置已恢复默认", "warn")

    def _clear_cache(self) -> None:
        try:
            size = sum(f.stat().st_size for f in CACHE_DIR.rglob("*") if f.is_file()) if CACHE_DIR.exists() else 0
            shutil.rmtree(CACHE_DIR, ignore_errors=True)
            self.status.configure(text=f"缓存已清空（释放 {human_size(size)}）")
            self.app.log(f"已清空缓存：{human_size(size)}", "ok")
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("清空失败", str(exc))
