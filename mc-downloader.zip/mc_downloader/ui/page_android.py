"""安卓相关页面：基岩版 APK 下载、Java 启动器（PojavLauncher）下载。"""

from __future__ import annotations

import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Any, Dict, List, Optional

from .. import bedrock, pojav
from ..net import human_size
from . import theme
from .app import Page
from .theme import Card, RoundedButton

APK_SOURCES = {
    "archive": "Internet Archive 存档",
    "json": "自定义 JSON 清单",
    "direct": "直接粘贴链接",
}
APK_SOURCE_KEYS = {v: k for k, v in APK_SOURCES.items()}


class _DownloadPage(Page):
    """带版本列表 + 右侧操作栏的通用页面骨架。"""

    show_dock = True

    def __init__(self, app) -> None:
        self._rows: List[Any] = []
        super().__init__(app)

    # 子类实现
    def columns(self):
        raise NotImplementedError

    def refresh_data(self) -> None:
        raise NotImplementedError

    def start_download(self) -> None:
        raise NotImplementedError

    # 通用构建
    def build(self) -> None:
        self._loaded = False
        self._build_toolbar()
        self._build_body()

    def _build_toolbar(self) -> None:
        self.toolbar = Card(self, padding=10)
        self.toolbar.pack(fill="x")
        self.tool_row = self.toolbar.inner
        self.build_toolbar(self.tool_row)

    def _build_body(self) -> None:
        body = tk.Frame(self, bg=theme.BG)
        body.pack(fill="both", expand=True, pady=(10, 0))
        body.grid_rowconfigure(0, weight=1)
        body.grid_columnconfigure(0, weight=1)

        self.list_card = Card(body, padding=8)
        self.list_card.grid(row=0, column=0, sticky="nsew")
        self.list_card.inner.grid_rowconfigure(0, weight=1)
        self.list_card.inner.grid_columnconfigure(0, weight=1)

        self.tree = ttk.Treeview(self.list_card.inner, columns=[c[0] for c in self.columns()],
                                 show="headings", selectmode="browse")
        for key, title, width, anchor in self.columns():
            self.tree.heading(key, text=title, anchor=anchor)
            self.tree.column(key, width=width, anchor=anchor, stretch=(key == self.columns()[0][0]))
        vsb = ttk.Scrollbar(self.list_card.inner, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns", padx=(4, 0))
        self.tree.tag_configure("even", background="#FAFBFD")
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        self.tree.bind("<Double-1>", lambda _e: self.start_download())

        self.empty_label = tk.Label(self.list_card.inner, text="", bg=theme.CARD, fg=theme.MUTED,
                                    font=self.app.fonts.small, justify="center")
        self.empty_label.place_forget()

        self.side = Card(body, padding=16)
        self.side.grid(row=0, column=1, sticky="ns", padx=(10, 0))
        self.side.configure(width=292)
        self.side.grid_propagate(False)
        self.build_side(self.side.inner)

    def build_toolbar(self, row: tk.Misc) -> None:
        pass

    def build_side(self, box: tk.Misc) -> None:
        pass

    def _on_select(self, _event=None) -> None:
        pass

    def set_empty(self, text: str) -> None:
        if not text:
            self.empty_label.place_forget()
            return
        self.empty_label.configure(text=text)
        self.empty_label.place(relx=0.5, rely=0.42, anchor="center")

    # 下载目录
    def download_dir(self) -> str:
        return self.dir_var.get().strip() or str(Path.home())

    def _pick_dir(self) -> None:
        path = filedialog.askdirectory(title="选择保存目录", initialdir=self.download_dir())
        if path:
            self.dir_var.set(path)
            self.cfg["apk_dir"] = path
            self.cfg.save()

    def _dir_row(self, box: tk.Misc, label: str = "保存目录") -> None:
        fonts = self.app.fonts
        tk.Label(box, text=label, bg=theme.CARD, fg=theme.TEXT_SOFT, font=fonts.small,
                 anchor="w").pack(fill="x")
        row = tk.Frame(box, bg=theme.CARD)
        row.pack(fill="x", pady=(4, 0))
        self.dir_var = tk.StringVar(value=str(self.cfg.get("apk_dir")))
        ttk.Entry(row, textvariable=self.dir_var, width=20).pack(side="left", fill="x", expand=True)
        RoundedButton(row, "…", command=self._pick_dir, width=30, height=28, kind="ghost",
                      font=fonts.small, parent_bg=theme.CARD).pack(side="left", padx=(6, 0))

    def on_show(self) -> None:
        if not self._loaded:
            self._loaded = True
            self.refresh_data()

    def on_busy(self, busy: bool) -> None:
        if hasattr(self, "dl_btn"):
            self.dl_btn.set_enabled(not busy)
        if hasattr(self, "refresh_btn"):
            self.refresh_btn.set_enabled(not busy)


class AndroidPage(_DownloadPage):
    name = "android"

    def columns(self):
        return [
            ("version", "版本", 150, "w"),
            ("channel", "通道", 90, "w"),
            ("size", "大小", 100, "w"),
            ("file", "文件名", 260, "w"),
        ]

    def build_toolbar(self, row: tk.Misc) -> None:
        fonts = self.app.fonts
        tk.Label(row, text="下载源", bg=theme.CARD, fg=theme.TEXT_SOFT, font=fonts.small).pack(side="left")
        self.source_var = tk.StringVar(value=APK_SOURCES.get(self.cfg.get("apk_source"), APK_SOURCES["archive"]))
        self.source_box = ttk.Combobox(row, textvariable=self.source_var, values=list(APK_SOURCES.values()),
                                       state="readonly", width=20)
        self.source_box.pack(side="left", padx=(6, 16))
        self.source_box.bind("<<ComboboxSelected>>", lambda _e: self._on_source_change())

        self.refresh_btn = RoundedButton(row, "刷新列表", command=self.refresh_data, width=92, height=28,
                                         kind="ghost", font=fonts.small, parent_bg=theme.CARD)
        self.refresh_btn.pack(side="right")
        self.status_label = tk.Label(row, text="", bg=theme.CARD, fg=theme.MUTED, font=fonts.small)
        self.status_label.pack(side="right", padx=(0, 12))

    def build_side(self, box: tk.Misc) -> None:
        fonts = self.app.fonts
        tk.Label(box, text="安卓 · 基岩版 APK", bg=theme.CARD, fg=theme.MUTED, font=fonts.small,
                 anchor="w").pack(fill="x")
        self.sel_label = tk.Label(box, text="未选择版本", bg=theme.CARD, fg=theme.TEXT, font=fonts.h2,
                                  anchor="w")
        self.sel_label.pack(fill="x", pady=(2, 4))
        self.sel_meta = tk.Label(box, text="从左侧列表选择版本，或切换到「直接粘贴链接」",
                                 bg=theme.CARD, fg=theme.MUTED, font=fonts.small, anchor="w",
                                 justify="left", wraplength=250)
        self.sel_meta.pack(fill="x")

        tk.Frame(box, bg=theme.BORDER, height=1).pack(fill="x", pady=12)
        self._dir_row(box, "保存目录")

        # 直接链接模式下的地址输入
        self.direct_frame = tk.Frame(box, bg=theme.CARD)
        tk.Label(self.direct_frame, text="APK 直链", bg=theme.CARD, fg=theme.TEXT_SOFT,
                 font=fonts.small, anchor="w").pack(fill="x", pady=(10, 0))
        self.url_var = tk.StringVar()
        ttk.Entry(self.direct_frame, textvariable=self.url_var).pack(fill="x", pady=(4, 8))
        self.direct_frame.pack_forget()

        self._dl_sep = tk.Frame(box, bg=theme.BORDER, height=1)
        self._dl_sep.pack(fill="x", pady=12)
        self.dl_btn = RoundedButton(box, "下载 APK", command=self.start_download, width=252, height=42,
                                    kind="primary", font=fonts.button, parent_bg=theme.CARD)
        self.dl_btn.pack(fill="x")
        self.dl_btn.set_enabled(False)

        RoundedButton(box, "在 Google Play 查看", command=self._open_play, width=252, height=30,
                      kind="ghost", font=fonts.small, parent_bg=theme.CARD).pack(fill="x", pady=(8, 0))

        tk.Label(box, text="安卓端安装前请允许「安装未知来源应用」。\n"
                           "官方未公开 APK 直链，本页从存档 / 自定义清单获取。",
                 bg=theme.CARD, fg=theme.MUTED, font=fonts.tiny, anchor="w", justify="left",
                 wraplength=250).pack(fill="x", pady=(10, 0))

    def _open_play(self) -> None:
        import webbrowser

        webbrowser.open("https://play.google.com/store/apps/details?id=com.mojang.minecraftpe")

    # -------------------------------------------------------------- 数据
    def _on_source_change(self) -> None:
        key = APK_SOURCE_KEYS.get(self.source_var.get(), "archive")
        self.cfg["apk_source"] = key
        self.cfg.save()
        self.refresh_data()

    def refresh_data(self) -> None:
        if self.app.busy:
            return
        self.tree.delete(*self.tree.get_children())
        self._rows.clear()
        self.dl_btn.set_enabled(False)
        self.source = bedrock.make_apk_source(self.cfg)

        if self.source.key == "direct":
            self.status_label.configure(text="直接链接模式")
            self.set_empty("直接链接模式：在右侧粘贴 APK 地址，再点「下载 APK」")
            self.direct_frame.pack(fill="x", after=self._dl_sep)
            self.sel_label.configure(text="直接下载")
            self.sel_meta.configure(text="粘贴 APK 直链即可，无需版本清单")
            self.dl_btn.set_enabled(True)
            self.app.log("已切换到「直接粘贴链接」模式：在右侧输入 APK 地址后下载。", "info")
            self.refresh_btn.set_enabled(True)
            return

        self.direct_frame.pack_forget()

        if not self.source.available():
            self.status_label.configure(text="未配置源")
            self.app.log("当前源尚未配置：请在「设置 → 安卓」里填写 JSON 清单地址。", "warn")
            self.refresh_btn.set_enabled(True)
            return

        self.status_label.configure(text="正在获取版本列表…")
        self.set_empty(f"正在从「{self.source.label}」获取列表…\n该源在部分网络下可能无法访问，可切换其他源")
        self.refresh_btn.set_enabled(False)

        def work() -> None:
            try:
                net = self.app.make_net()
                net.retries = min(2, net.retries)
                versions = self.source.list_versions(net, None)
                self.app.ui_call(lambda: self._apply(versions))
            except Exception as exc:  # noqa: BLE001
                self.app.ui_call(lambda: self._failed(exc))

        threading.Thread(target=work, daemon=True).start()

    def _apply(self, versions: List[bedrock.ApkVersion]) -> None:
        self.refresh_btn.set_enabled(True)
        self._rows = versions
        self.set_empty("" if versions else "该源没有返回任何 APK")
        for idx, apk in enumerate(versions):
            self.tree.insert("", "end", iid=str(idx),
                             values=(apk.version, apk.channel, apk.size_text, apk.filename),
                             tags=("even",) if idx % 2 else ())
        self.status_label.configure(text=f"共 {len(versions)} 个版本")
        self.app.log(f"{self.source.label}：获取到 {len(versions)} 个 APK 版本", "ok")

    def _failed(self, exc: Exception) -> None:
        self.refresh_btn.set_enabled(True)
        self.status_label.configure(text="获取失败")
        self.set_empty("获取失败：该源可能被网络屏蔽\n可切换到「自定义 JSON 清单」或「直接链接」")
        self.app.log(f"APK 列表获取失败：{exc}", "error")

    def _on_select(self, _event=None) -> None:
        selection = self.tree.selection()
        if not selection:
            return
        idx = int(selection[0])
        if idx >= len(self._rows):
            return
        apk = self._rows[idx]
        self.sel_label.configure(text=apk.version)
        self.sel_meta.configure(text=f"{apk.filename}\n{apk.size_text} · sha1 {(apk.sha1[:10] or '未知')}")
        self.dl_btn.set_enabled(True)

    def start_download(self) -> None:
        if self.app.busy:
            return
        if getattr(self, "source", None) is not None and self.source.key == "direct":
            url = self.url_var.get().strip()
            if not url:
                messagebox.showinfo("粘贴链接", "请先在右侧输入 APK 的下载地址。")
                return
            try:
                apk = bedrock.DirectSource().from_url(url)
            except Exception as exc:  # noqa: BLE001
                messagebox.showerror("链接无效", str(exc))
                return
        else:
            selection = self.tree.selection()
            if not selection or not self._rows:
                messagebox.showinfo("选择版本", "请先在列表里选择一个 APK。")
                return
            apk = self._rows[int(selection[0])]
        dest = Path(self.download_dir())

        def worker(progress, cancel):
            net = self.app.make_net()
            path = bedrock.download_apk(net, apk, dest, progress, cancel, self.app.log)
            return {"dir": str(path.parent)}

        self.app.start_job(f"正在下载 {apk.filename}", worker)


class LauncherPage(_DownloadPage):
    name = "launcher"

    def columns(self):
        return [
            ("file", "文件", 250, "w"),
            ("release", "版本标签", 130, "w"),
            ("date", "发布日期", 100, "w"),
            ("size", "大小", 100, "w"),
        ]

    def build_toolbar(self, row: tk.Misc) -> None:
        fonts = self.app.fonts
        tk.Label(row, text="组件", bg=theme.CARD, fg=theme.TEXT_SOFT, font=fonts.small).pack(side="left")
        self.repo_var = tk.StringVar(value="PojavLauncher（Java 版安卓启动器）")
        self.repo_box = ttk.Combobox(row, textvariable=self.repo_var,
                                     values=["PojavLauncher（Java 版安卓启动器）", "Java 运行时（JRE）"],
                                     state="readonly", width=30)
        self.repo_box.pack(side="left", padx=(6, 16))
        self.repo_box.bind("<<ComboboxSelected>>", lambda _e: self.refresh_data())

        self.refresh_btn = RoundedButton(row, "刷新列表", command=self.refresh_data, width=92, height=28,
                                         kind="ghost", font=fonts.small, parent_bg=theme.CARD)
        self.refresh_btn.pack(side="right")
        self.status_label = tk.Label(row, text="", bg=theme.CARD, fg=theme.MUTED, font=fonts.small)
        self.status_label.pack(side="right", padx=(0, 12))

    def build_side(self, box: tk.Misc) -> None:
        fonts = self.app.fonts
        tk.Label(box, text="安卓 · Java 版运行环境", bg=theme.CARD, fg=theme.MUTED, font=fonts.small,
                 anchor="w").pack(fill="x")
        self.sel_label = tk.Label(box, text="未选择文件", bg=theme.CARD, fg=theme.TEXT, font=fonts.h3,
                                  anchor="w", wraplength=250, justify="left")
        self.sel_label.pack(fill="x", pady=(2, 4))
        self.sel_meta = tk.Label(box, text="PojavLauncher 可在安卓上运行 Java 版 Minecraft",
                                 bg=theme.CARD, fg=theme.MUTED, font=fonts.small, anchor="w",
                                 justify="left", wraplength=250)
        self.sel_meta.pack(fill="x")

        tk.Frame(box, bg=theme.BORDER, height=1).pack(fill="x", pady=12)
        self._dir_row(box, "保存目录")

        tk.Frame(box, bg=theme.BORDER, height=1).pack(fill="x", pady=12)
        self.dl_btn = RoundedButton(box, "下载所选文件", command=self.start_download, width=252, height=42,
                                    kind="primary", font=fonts.button, parent_bg=theme.CARD)
        self.dl_btn.pack(fill="x")
        self.dl_btn.set_enabled(False)

        tk.Label(box, text="PojavLauncher 使用 Java 版游戏文件；\n"
                           "可在「PC · Java 版」里下载好版本后拷贝到手机。",
                 bg=theme.CARD, fg=theme.MUTED, font=fonts.tiny, anchor="w", justify="left",
                 wraplength=250).pack(fill="x", pady=(10, 0))

    def _repo_key(self) -> str:
        return "jre" if "JRE" in self.repo_var.get() else "pojav"

    def refresh_data(self) -> None:
        if self.app.busy:
            return
        self.tree.delete(*self.tree.get_children())
        self._rows.clear()
        self.dl_btn.set_enabled(False)
        key = self._repo_key()
        self.status_label.configure(text="正在获取 GitHub Releases…")
        self.set_empty("正在从 GitHub 获取列表…")
        self.refresh_btn.set_enabled(False)

        def work() -> None:
            try:
                net = self.app.make_net()
                assets = pojav.list_assets(net, key, 6)
                self.app.ui_call(lambda: self._apply(assets))
            except Exception as exc:  # noqa: BLE001
                self.app.ui_call(lambda: self._failed(exc))

        threading.Thread(target=work, daemon=True).start()

    def _apply(self, assets: List[pojav.GhAsset]) -> None:
        self.refresh_btn.set_enabled(True)
        self._rows = assets
        self.set_empty("" if assets else "没有找到可下载的文件")
        for idx, asset in enumerate(assets):
            self.tree.insert("", "end", iid=str(idx),
                             values=(asset.name, asset.release, asset.date, asset.size_text),
                             tags=("even",) if idx % 2 else ())
        self.status_label.configure(text=f"共 {len(assets)} 个文件")
        self.app.log(f"GitHub：获取到 {len(assets)} 个文件", "ok")

    def _failed(self, exc: Exception) -> None:
        self.refresh_btn.set_enabled(True)
        self.status_label.configure(text="获取失败")
        self.set_empty("GitHub 访问失败，稍后再试")
        self.app.log(f"GitHub 列表获取失败：{exc}", "error")

    def _on_select(self, _event=None) -> None:
        selection = self.tree.selection()
        if not selection:
            return
        asset = self._rows[int(selection[0])]
        self.sel_label.configure(text=asset.name)
        self.sel_meta.configure(text=f"{asset.size_text} · {asset.release} · {asset.date}")
        self.dl_btn.set_enabled(True)

    def start_download(self) -> None:
        if self.app.busy:
            return
        selection = self.tree.selection()
        if not selection:
            messagebox.showinfo("选择文件", "请先在列表里选择一个文件。")
            return
        asset = self._rows[int(selection[0])]
        dest_dir = Path(self.download_dir())

        def worker(progress, cancel):
            net = self.app.make_net()
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest = dest_dir / asset.name
            progress.reset()
            progress.add_totals(1, asset.size or 0)
            net.download([asset.url], dest, size=asset.size or None, progress=progress,
                         cancel=cancel, label=asset.name)
            self.app.log(f"已保存：{dest}", "ok")
            return {"dir": str(dest_dir)}

        self.app.start_job(f"正在下载 {asset.name}", worker)
