"""关于页。"""

from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from ..config import APP_DIR, LOG_DIR
from . import theme
from .app import Page
from .theme import Card

ABOUT_TEXT = """MC 下载器  v1.1.0

一个参考 PCL 启动器（Plain Craft Launcher）设计思路的 Minecraft 版本下载工具，
同时支持 PC 端 Java 版与安卓端安装包的下载。

【PC · Java 版】
  · 从 Mojang 官方版本清单读取全部版本（正式版 / 快照 / 远古版 / 愚人节）
  · 一键安装 client.jar、依赖库（含 natives 解压）、资源文件、日志配置
  · 支持 Bang Bang 镜像加速，镜像失败自动回退官方源
  · 多线程下载 + 断点续传 + SHA1 校验，已完成的文件再次下载自动跳过
  · 生成的目录结构可被 PCL / HMCL / 官方启动器直接识别

【模组 · 加载器 / Mod】
  · 加载器：Fabric / Quilt / Forge / NeoForge，版本列表自动拉取
  · Mod 市场：Modrinth 搜索，按 MC 版本 + 加载器过滤，可自动带上必需的前置 Mod
  · Mod 管理：列出已装 Mod、启用 / 禁用、删除、打开 mods 目录
  · Forge / NeoForge 使用官方安装器，需要本机 Java（会自动检测，也可手动指定）

【安卓 · 基岩版】
  · 通过「Internet Archive 存档 / 自定义 JSON 清单 / 直接链接」获取 APK
  · 下载前可查看版本号、通道与大小，支持断点续传

【安卓 · 启动器】
  · 从 GitHub Releases 获取 PojavLauncher（Java 版安卓启动器）与配套 JRE

【命令行】
  python main.py list                    列出全部版本
  python main.py install 1.20.1          下载安装指定版本
  python main.py loader install --mc 1.20.1 --type fabric   装加载器
  python main.py mod search sodium --mc 1.20.1 --loader fabric
  python main.py mod install sodium --mc 1.20.1 --loader fabric
  python main.py apk list                列出安卓 APK
  python main.py launcher list           列出安卓启动器
  python main.py selftest                自检

【免责声明】
  · 本工具只负责「下载与整理文件」，不提供任何游戏破解、账号或联网绕过功能。
  · Minecraft 是 Mojang Studios / Microsoft 的商标与版权作品，请通过官方渠道购买正版。
  · Mod 来自 Modrinth 上作者公开发布的版本，请遵守各 Mod 的许可协议。
  · 安卓 APK 来源于第三方存档，使用前请自行确认来源可信；建议优先在 Google Play 购买安装。
  · 本程序仅供学习交流使用。

【参考与致谢】
  · PCL / PCL2（龙腾猫跃）—— 界面布局与下载流程的灵感来源
  · BMCLAPI（bangbang93）—— 国内镜像加速
  · Modrinth —— 开放的 Mod 平台 API
  · Fabric / Quilt / Forge / NeoForge 团队 —— 加载器与官方安装器
  · PojavLauncher 团队 —— 安卓端 Java 版运行环境
"""


class AboutPage(Page):
    name = "about"
    show_dock = False

    def build(self) -> None:
        fonts = self.app.fonts
        card = Card(self, padding=16)
        card.pack(fill="both", expand=True)
        box = card.inner

        tk.Label(box, text="关于", bg=theme.CARD, fg=theme.TEXT, font=fonts.h2, anchor="w").pack(fill="x")

        footer = tk.Label(box, text=f"程序目录：{APP_DIR}    日志目录：{LOG_DIR}", bg=theme.CARD,
                          fg=theme.MUTED, font=fonts.tiny, anchor="w")
        footer.pack(side="bottom", fill="x", pady=(8, 0))

        body = tk.Frame(box, bg=theme.CARD)
        body.pack(fill="both", expand=True, pady=(6, 0))
        text = tk.Text(body, bg=theme.CARD, fg=theme.TEXT_SOFT, font=fonts.body, relief="flat",
                       wrap="word", padx=2, pady=4, height=24, spacing1=2, spacing3=2)
        scroll = ttk.Scrollbar(body, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        text.insert("1.0", ABOUT_TEXT)
        text.configure(state="disabled")
