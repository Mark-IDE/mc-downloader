"""安卓上的 Java 版运行环境：PojavLauncher + 运行时。

这两样都在 GitHub Releases 上公开分发，可以稳定列出与下载。
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import CACHE_DIR
from .net import Cancelled, DownloadError, NetClient, Progress, human_size

GH_API = "https://api.github.com/repos/{repo}/releases"

REPOS: Dict[str, Dict[str, str]] = {
    "pojav": {
        "repo": "PojavLauncherTeam/PojavLauncher",
        "label": "PojavLauncher（Java 版安卓启动器）",
        "note": "安装后可在手机上运行 Java 版 Minecraft",
    },
    "jre": {
        "repo": "PojavLauncherTeam/android-openjdk-build-multiarch",
        "label": "Java 运行时（JRE，按架构）",
        "note": "PojavLauncher 里手动指定 JRE 时使用",
    },
}


@dataclass
class GhAsset:
    name: str
    url: str
    size: int
    release: str
    date: str
    source: str = ""
    kind: str = "apk"

    @property
    def size_text(self) -> str:
        return human_size(self.size) if self.size else "未知"

    def matches(self, arch: str = "") -> bool:
        if not arch:
            return True
        return arch.lower() in self.name.lower()


def list_assets(net: NetClient, key: str = "pojav", limit: int = 12,
                cancel: Optional[Any] = None) -> List[GhAsset]:
    info = REPOS.get(key)
    if not info:
        raise DownloadError(f"未知仓库：{key}")
    repo = info["repo"]
    cache = CACHE_DIR / f"gh_{key}.json"
    data = None
    try:
        if cache.exists() and time.time() - cache.stat().st_mtime < 12 * 3600:
            data = json.loads(cache.read_text("utf-8"))
    except Exception:  # noqa: BLE001
        data = None
    if data is None:
        url = GH_API.format(repo=repo) + f"?per_page={max(1, limit)}"
        try:
            data = net.fetch_json(url, cancel=cancel)
        except DownloadError as exc:
            raise DownloadError(f"GitHub 访问失败：{exc}") from exc
        try:
            cache.parent.mkdir(parents=True, exist_ok=True)
            cache.write_text(json.dumps(data, ensure_ascii=False), "utf-8")
        except OSError:
            pass
    if not isinstance(data, list):
        raise DownloadError("GitHub 返回内容异常（可能触发了限流，请稍后重试）")

    out: List[GhAsset] = []
    for rel in data[:limit]:
        tag = rel.get("tag_name") or rel.get("name") or ""
        date = (rel.get("published_at") or "")[:10]
        for asset in rel.get("assets") or []:
            name = asset.get("name") or ""
            url = asset.get("browser_download_url") or ""
            if not url:
                continue
            low = name.lower()
            if not (low.endswith(".apk") or low.endswith(".zip") or low.endswith(".tar.xz")
                    or low.endswith(".jar") or low.endswith(".xz")):
                continue
            kind = "apk" if low.endswith(".apk") else "jre"
            out.append(
                GhAsset(
                    name=name,
                    url=url,
                    size=int(asset.get("size") or 0),
                    release=tag,
                    date=date,
                    source=info["label"],
                    kind=kind,
                )
            )
    return out
