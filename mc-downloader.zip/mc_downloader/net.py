"""HTTP 下载引擎：多线程、断点续传、SHA1 校验、镜像回退、TLS 降级。

只用标准库，避免用户额外装依赖。
"""

from __future__ import annotations

import hashlib
import json
import random
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import deque
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Union

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) MCDownloader/1.0"
)
CHUNK = 256 * 1024


class Cancelled(Exception):
    """用户主动取消。"""


class DownloadError(Exception):
    def __init__(self, message: str, url: str = ""):
        super().__init__(message)
        self.url = url

    def __str__(self) -> str:  # noqa: D105
        base = super().__str__()
        return f"{base}" if not self.url else f"{base} ({short_url(self.url)})"


def short_url(url: str, limit: int = 72) -> str:
    url = url or ""
    return url if len(url) <= limit else url[: limit - 3] + "..."


def human_size(num: float) -> str:
    num = float(num or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if num < 1024 or unit == "TB":
            return f"{num:.0f} {unit}" if unit == "B" else f"{num:.2f} {unit}"
        num /= 1024
    return f"{num:.2f} TB"


def human_speed(bps: float) -> str:
    if not bps or bps < 1:
        return "--"
    return human_size(bps) + "/s"


def fmt_eta(seconds: Optional[float]) -> str:
    if seconds is None or seconds <= 0 or seconds > 86400 * 3:
        return "--"
    seconds = int(seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}小时{m}分"
    if m:
        return f"{m}分{s}秒"
    return f"{s}秒"


def sha1_file(path: Path, cancel: Optional[threading.Event] = None, chunk: int = 1024 * 1024) -> str:
    h = hashlib.sha1()
    with open(path, "rb") as f:
        while True:
            if cancel is not None and cancel.is_set():
                raise Cancelled()
            block = f.read(chunk)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def md5_file(path: Path, chunk: int = 1024 * 1024) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        while True:
            block = f.read(chunk)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


class Progress:
    """线程安全的总体进度（文件数 + 字节数 + 速度 + 当前文件）。"""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._total_files = 0
        self._done_files = 0
        self._total_bytes = 0
        self._done_bytes = 0
        self._current = ""
        self._samples: deque = deque(maxlen=240)
        self._started = time.time()

    def reset(self) -> None:
        with self._lock:
            self._total_files = 0
            self._done_files = 0
            self._total_bytes = 0
            self._done_bytes = 0
            self._current = ""
            self._samples.clear()
            self._started = time.time()

    def add_totals(self, files: int, total_bytes: int) -> None:
        with self._lock:
            self._total_files += files
            self._total_bytes += max(0, total_bytes)

    def add_bytes(self, n: int) -> None:
        now = time.time()
        with self._lock:
            self._done_bytes = max(self._done_bytes, self._done_bytes + n)
            self._samples.append((now, self._done_bytes))

    def skip_file(self, size: int) -> None:
        now = time.time()
        with self._lock:
            self._done_files += 1
            self._done_bytes = max(self._done_bytes, self._done_bytes + max(0, size))
            self._samples.append((now, self._done_bytes))

    def finish_file(self) -> None:
        with self._lock:
            self._done_files += 1

    def set_current(self, text: str) -> None:
        with self._lock:
            self._current = text

    def _speed(self) -> float:
        if len(self._samples) < 2:
            return 0.0
        span = self._samples[-1][0] - self._samples[0][0]
        if span < 0.35:
            return 0.0
        return max(0.0, (self._samples[-1][1] - self._samples[0][1]) / span)

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            total_b = self._total_bytes
            done_b = self._done_bytes
            speed = self._speed()
            percent = (done_b / total_b * 100.0) if total_b > 0 else (
                100.0 if self._total_files and self._done_files >= self._total_files else 0.0
            )
            eta = None
            if speed > 0 and total_b > done_b:
                eta = (total_b - done_b) / speed
            return {
                "total_files": self._total_files,
                "done_files": self._done_files,
                "total_bytes": total_b,
                "done_bytes": done_b,
                "speed": speed,
                "eta": eta,
                "percent": max(0.0, min(100.0, percent)),
                "current": self._current,
            }


class NetClient:
    """带重试、续传、校验的下载器。

    download() 支持传入候选 URL 列表：镜像全部失败时自动回退到官方源。
    """

    def __init__(
        self,
        threads: int = 16,
        retries: int = 3,
        timeout: int = 20,
        verify_sha1: bool = True,
        allow_insecure_tls: bool = True,
        proxy: str = "",
        log: Optional[Callable[[str, str], None]] = None,
    ) -> None:
        self.threads = max(1, min(64, int(threads or 16)))
        self.retries = max(1, min(10, int(retries or 3)))
        self.timeout = max(5, int(timeout or 20))
        self.verify_sha1 = bool(verify_sha1)
        self.allow_insecure_tls = bool(allow_insecure_tls)
        self.proxy = (proxy or "").strip()
        self.log = log or (lambda msg, level="info": None)
        self._openers: Dict[bool, urllib.request.OpenerDirector] = {}
        self._lock = threading.Lock()
        self._warned_insecure = False
        self._noted_hosts: set = set()

    # ---------------------------------------------------------------- openers
    def _opener(self, insecure: bool) -> urllib.request.OpenerDirector:
        with self._lock:
            op = self._openers.get(insecure)
            if op is not None:
                return op
            handlers = []
            if self.proxy:
                handlers.append(urllib.request.ProxyHandler({"http": self.proxy, "https": self.proxy}))
            ctx = ssl.create_default_context()
            if insecure:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
            handlers.append(urllib.request.HTTPSHandler(context=ctx))
            op = urllib.request.build_opener(*handlers)
            op.addheaders = [("User-Agent", USER_AGENT), ("Accept", "*/*")]
            self._openers[insecure] = op
            return op

    def _open(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None,
        insecure: bool = False,
    ):
        req = urllib.request.Request(url, headers=headers or {})
        return self._opener(insecure).open(req, timeout=timeout or self.timeout)

    def _open_with_tls_fallback(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None,
    ):
        try:
            return self._open(url, headers, timeout, insecure=False)
        except urllib.error.URLError as exc:
            reason = getattr(exc, "reason", exc)
            if isinstance(reason, ssl.SSLError) and self.allow_insecure_tls:
                if not self._warned_insecure:
                    self._warned_insecure = True
                    self.log("检测到证书校验失败，已对该站点降级为「不校验证书」重试（可在设置中关闭）。", "warn")
                return self._open(url, headers, timeout, insecure=True)
            raise

    # ---------------------------------------------------------------- helpers
    def fetch_bytes(
        self,
        url: str,
        limit: Optional[int] = None,
        cancel: Optional[threading.Event] = None,
        retries: Optional[int] = None,
    ) -> bytes:
        attempts = max(1, retries or self.retries)
        last: Optional[Exception] = None
        for attempt in range(1, attempts + 1):
            if cancel is not None and cancel.is_set():
                raise Cancelled()
            try:
                with self._open_with_tls_fallback(url) as resp:
                    data = resp.read(limit) if limit else resp.read()
                return data
            except Cancelled:
                raise
            except urllib.error.HTTPError as exc:
                last = exc
                if exc.code in (403, 404, 410):
                    break
            except Exception as exc:  # noqa: BLE001
                last = exc
            if attempt < attempts:
                time.sleep(0.5 * attempt + random.random() * 0.3)
        raise DownloadError(f"请求失败：{last}", url)

    def fetch_json(self, url: str, cancel: Optional[threading.Event] = None, retries: Optional[int] = None) -> Any:
        raw = self.fetch_bytes(url, cancel=cancel, retries=retries)
        try:
            return json.loads(raw.decode("utf-8-sig"))
        except Exception as exc:  # noqa: BLE001
            raise DownloadError(f"解析 JSON 失败：{exc}", url)

    # ---------------------------------------------------------------- download
    def download(
        self,
        urls: Union[str, Sequence[str]],
        dest: Path,
        size: Optional[int] = None,
        sha1: Optional[str] = None,
        progress: Optional[Progress] = None,
        cancel: Optional[threading.Event] = None,
        label: str = "",
        overwrite: bool = False,
    ) -> str:
        """下载到 dest，返回 "ok" 或 "skip"。urls 为候选列表，按顺序尝试。"""
        if isinstance(urls, str):
            candidates: List[str] = [urls]
        else:
            candidates = [u for u in urls if u]
        dest = Path(dest)
        if not candidates:
            raise DownloadError("没有可用的下载地址")

        # 已存在且完整 → 跳过
        if dest.exists() and not overwrite:
            ok = self._check_existing(dest, size, sha1)
            if ok:
                if progress is not None:
                    progress.skip_file(dest.stat().st_size)
                return "skip"
            try:
                dest.unlink()
            except OSError:
                pass

        dest.parent.mkdir(parents=True, exist_ok=True)
        part = dest.with_name(dest.name + ".part")
        if progress is not None and label:
            progress.set_current(label)

        last_error: Optional[Exception] = None
        for attempt in range(1, self.retries + 1):
            for idx, url in enumerate(candidates):
                if cancel is not None and cancel.is_set():
                    raise Cancelled()
                try:
                    self._download_one(url, part, size, progress, cancel)
                    if sha1 and self.verify_sha1:
                        got = sha1_file(part, cancel)
                        if got.lower() != sha1.lower():
                            try:
                                part.unlink()
                            except OSError:
                                pass
                            raise DownloadError(f"SHA1 不匹配（{got[:10]} ≠ {sha1[:10]}）", url)
                    try:
                        if dest.exists():
                            dest.unlink()
                    except OSError:
                        pass
                    part.replace(dest)
                    if progress is not None:
                        progress.finish_file()
                    if idx > 0:
                        self._note_fallback(url, attempt)
                    return "ok"
                except Cancelled:
                    raise
                except Exception as exc:  # noqa: BLE001
                    last_error = exc
                    if attempt == self.retries and idx == len(candidates) - 1:
                        self.log(f"下载失败：{label or dest.name}（{exc}）", "warn")
            if attempt < self.retries:
                time.sleep(min(4.0, 0.8 * attempt) + random.random() * 0.4)

        try:
            if part.exists():
                part.unlink()
        except OSError:
            pass
        raise DownloadError(str(last_error or "未知错误"), candidates[0])

    def _note_fallback(self, url: str, attempt: int) -> None:
        host = urllib.parse.urlsplit(url).hostname or url
        with self._lock:
            if host in self._noted_hosts:
                return
            self._noted_hosts.add(host)
        self.log(f"主下载源不可用，已自动回退到备用源（{host}）。", "warn")

    def _check_existing(self, dest: Path, size: Optional[int], sha1: Optional[str]) -> bool:
        try:
            actual = dest.stat().st_size
        except OSError:
            return False
        if actual <= 0:
            return False
        if size is not None and size > 0 and actual != size:
            return False
        if sha1 and self.verify_sha1:
            try:
                return sha1_file(dest).lower() == sha1.lower()
            except Exception:  # noqa: BLE001
                return False
        return size is not None or not sha1

    def _download_one(
        self,
        url: str,
        part: Path,
        size: Optional[int],
        progress: Optional[Progress],
        cancel: Optional[threading.Event],
    ) -> None:
        pos = part.stat().st_size if part.exists() else 0
        if size is not None and size > 0:
            if pos == size:
                return
            if pos > size:
                part.unlink()
                pos = 0
        headers: Dict[str, str] = {}
        if pos:
            headers["Range"] = f"bytes={pos}-"

        with self._open_with_tls_fallback(url, headers) as resp:
            status = getattr(resp, "status", None) or resp.getcode()
            if pos and status == 200:
                pos = 0  # 服务器不支持 Range，从头下载
            elif pos and status not in (206, 200):
                pos = 0
            # 未知大小时用 Content-Length 补全总进度
            if progress is not None and (size is None or size <= 0) and pos == 0:
                try:
                    length = resp.headers.get("Content-Length")
                    if length and length.isdigit():
                        progress.add_totals(0, int(length))
                except Exception:  # noqa: BLE001
                    pass
            mode = "ab" if pos else "wb"
            with open(part, mode) as fh:
                while True:
                    if cancel is not None and cancel.is_set():
                        raise Cancelled()
                    chunk = resp.read(CHUNK)
                    if not chunk:
                        break
                    fh.write(chunk)
                    if progress is not None:
                        progress.add_bytes(len(chunk))
        if size is not None and size > 0:
            got = part.stat().st_size
            if got < size:
                raise DownloadError(f"连接中断：{human_size(got)}/{human_size(size)}", url)

    # ---------------------------------------------------------------- parallel
    def run_tasks(
        self,
        tasks: Iterable[Any],
        worker: Callable[[Any], None],
        cancel: Optional[threading.Event] = None,
    ) -> List[Any]:
        """并发执行任务列表，返回失败项列表 [(task, error)]。"""
        from concurrent.futures import ThreadPoolExecutor, wait

        failures: List[Any] = []
        lock = threading.Lock()
        task_list = list(tasks)

        def _run(task: Any) -> None:
            if cancel is not None and cancel.is_set():
                return
            try:
                worker(task)
            except Cancelled:
                return
            except Exception as exc:  # noqa: BLE001
                with lock:
                    failures.append((task, exc))

        pool = ThreadPoolExecutor(max_workers=self.threads, thread_name_prefix="dl")
        try:
            futures = [pool.submit(_run, t) for t in task_list]
            wait(futures)
        except KeyboardInterrupt:
            cancel and cancel.set()
            raise
        finally:
            pool.shutdown(wait=True, cancel_futures=True)
        return failures
