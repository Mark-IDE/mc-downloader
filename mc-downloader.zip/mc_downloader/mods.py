"""本地 Mod 管理：列出、启用/禁用、删除。"""

from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

DISABLED_SUFFIX = ".disabled"


@dataclass
class ModEntry:
    path: Path
    size: int
    enabled: bool

    @property
    def name(self) -> str:
        name = self.path.name
        return name[: -len(DISABLED_SUFFIX)] if name.endswith(DISABLED_SUFFIX) else name

    @property
    def size_text(self) -> str:
        size = float(self.size or 0)
        for unit in ("B", "KB", "MB", "GB"):
            if size < 1024 or unit == "GB":
                return f"{size:.0f} {unit}" if unit == "B" else f"{size:.2f} {unit}"
            size /= 1024
        return f"{size:.2f} GB"

    @property
    def status(self) -> str:
        return "已启用" if self.enabled else "已禁用"


def default_mods_dir(root: Path, version_id: str = "", isolated: bool = False) -> Path:
    """版本隔离时用 versions/<id>/mods，否则用共享的 mods/。"""
    root = Path(root)
    if isolated and version_id:
        d = root / "versions" / version_id / "mods"
        if d.exists():
            return d
    return root / "mods"


def resolve_mods_dir(root: Path, version_id: str = "") -> Path:
    """优先选已存在的版本隔离目录，其次共享目录。"""
    root = Path(root)
    if version_id:
        isolated = root / "versions" / version_id / "mods"
        if isolated.exists():
            return isolated
    return root / "mods"


def list_mods(directory: Path) -> List[ModEntry]:
    directory = Path(directory)
    if not directory.exists():
        return []
    out: List[ModEntry] = []
    for p in sorted(directory.iterdir(), key=lambda x: x.name.lower()):
        if not p.is_file():
            continue
        low = p.name.lower()
        if low.endswith(".jar"):
            out.append(ModEntry(p, p.stat().st_size, True))
        elif low.endswith(".jar" + DISABLED_SUFFIX):
            out.append(ModEntry(p, p.stat().st_size, False))
    return out


def set_enabled(entry: ModEntry, enabled: bool) -> Optional[Path]:
    """改扩展名实现启用/禁用（.jar ↔ .jar.disabled）。"""
    p = entry.path
    if enabled and p.name.lower().endswith(DISABLED_SUFFIX):
        target = p.with_name(p.name[: -len(DISABLED_SUFFIX)])
    elif not enabled and not p.name.lower().endswith(DISABLED_SUFFIX):
        target = p.with_name(p.name + DISABLED_SUFFIX)
    else:
        return p
    if target.exists():
        raise FileExistsError(f"目标文件已存在：{target.name}")
    p.rename(target)
    return target


def delete_entry(entry: ModEntry) -> None:
    entry.path.unlink(missing_ok=True)


def open_folder(path: Path) -> None:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    try:
        os.startfile(str(path))  # type: ignore[attr-defined]
    except Exception:  # noqa: BLE001
        pass
